package Dirpasswd;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  htpasswd関連ライブラリ
#     Program Name   :  Dirpasswd.pl
#     Create Date    :  2010.11.30
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.30 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ Dirpasswd.pl version 1.5.1 を元に
#                       リニューアル新規作成
#-----------------------------------------------------------------------------#
#  [1] add_user ディレクトリパスワード追加
#      $file_nm....パスワードファイルのパス
#      $user.......ユーザ名
#      $passwd.....パスワード
#      戻り値......1:正常終了 0:異常終了
#
#      ＊ファイルが存在しない場合、新規作成
#-----------------------------------------------------------------------------#
#  [2] upd_user ディレクトリパスワード更新
#      $file_nm....パスワードファイルのパス
#      $user.......ユーザ名
#      $passwd.....パスワード
#      戻り値......1:正常終了  0:異常終了
#
#      ＊ユーザが存在しない場合、追加。ファイルが存在しない場合新規作成
#-----------------------------------------------------------------------------#
#  [3] del_user ディレクトリパスワード削除
#      $file_nm....パスワードファイルのパス
#      $user.......ユーザ名
#      戻り値......1:正常終了  0:異常終了
#-----------------------------------------------------------------------------#
#  [4] find_user ユーザ検索
#      $file_nm....パスワードファイルのパス
#      $user.......ユーザ名
#      戻り値......1:合致 0:合致しない -1:異常終了
#-----------------------------------------------------------------------------#
#  [5] get_user  パスワードファイルの行からユーザ名を取得
#      $line.......パスワードファイルの行データ
#      戻り値......ユーザ名
#-----------------------------------------------------------------------------#
#  [6] get_password 暗号化パスワードを取得
#      $pw.........パスワード
#      $salt.......salt
#      $rtn........戻り値。暗号化した文字列
#-----------------------------------------------------------------------------#
use utf8;
use Encode;

my $version = "1.0.0";
my $library_name = 'Dirpasswd.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#------------------------------------------------------------------------------
#   add_user : ディレクトリパスワード追加
#------------------------------------------------------------------------------
sub add_user {
	my ( $file_nm, $user, $passwd ) = @_;
	my ( $cpw );

	if ( length( $user ) > 0 && length( $passwd ) > 0 ){
		$file_nm = &passwd_path($file_nm);
		$cpw = &Dirpasswd::get_password($passwd);
		if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }
		if ( ! (open( TFP, ">>$file_nm" ) ) ){
			&passwd_file_unlock("$file_nm.lk");
			return(0);
		}
		else {
			print TFP Encode::encode('utf8', "$user:$cpw\n");
			close TFP;
			&passwd_file_unlock("$file_nm.lk");
			return(1);
		}
	}
	else { return(0); }
}

#------------------------------------------------------------------------------
#     upd_user : ディレクトリパスワード更新
#------------------------------------------------------------------------------
sub upd_user {
	my ( $file_nm, $user, $passwd ) = @_;
	my ( $tmp_file, $i, $cpw, $find, $c, $w );

	if ( length( $user ) == 0 || length( $passwd ) == 0 ){ return(0); }

	$file_nm = &passwd_path( $file_nm );
	$tmp_file = $file_nm . '.tmp';

	if ( &passwd_file_lock( "$file_nm.lk",15 ) ){ return(0); }

	if ( ! ( open(TFP, ">>$tmp_file" ) ) ){        # Temporary file open 
		&passwd_file_unlock( "$file_nm.lk" );
		return(0);
	}

	if ( ! ( open(READ, "$file_nm" ) ) ){
		close TFP;
		unlink( $tmp_file );

		if ( ! ( open(TFP, ">$file_nm" ) ) ){
			&passwd_file_unlock( "$file_nm.lk" );
			return(0);
		}
		else { 
			$cpw = &Dirpasswd::get_password( $passwd );
			print TFP Encode::encode('utf8', "$user:$cpw\n");
			close TFP;
			&passwd_file_unlock( "$file_nm.lk" );
			return(1);
		}
	}
	else { 
		undef $find; 
		while (<READ>) {
			$_ = Encode::decode('utf8', "$_");
			$c = substr($_,0,1);
			if ( ($c eq '#') || $c eq '') {
				print TFP Encode::encode('utf8', "$_");
				next;
			}
			$w = &Dirpasswd::get_user($_);
			if ( $user ne $w ){
				print TFP Encode::encode('utf8', "$_");
				next;
			} else {
				$cpw = &Dirpasswd::get_password($passwd);
				print TFP Encode::encode('utf8', "$user:$cpw\n");
				$find = 1;
			}
		}
		if ( ! $find ){
			$cpw = &Dirpasswd::get_password( $passwd );
			print TFP Encode::encode('utf8', "$user:$cpw\n");
		}
		close READ;
		close TFP;

		unlink( $file_nm );
		rename( $tmp_file,$file_nm );
		&passwd_file_unlock( "$file_nm.lk" );
		return( 1 );
	}
}

#------------------------------------------------------------------------------
#     del_user : ディレクトリパスワード削除
#------------------------------------------------------------------------------
sub del_user {
	my ( $file_nm, $user  ) = @_;
	my ( $tmp_file, $i, $cpw, $find, $c, $w );

	if ( length( $user ) == 0 ){ return(0); }

	$file_nm = &passwd_path( $file_nm );
	$tmp_file = $file_nm . '.tmp';

	if ( &passwd_file_lock( "$file_nm.lk",15 ) ){ return(0); }

	if ( ! ( open(TFP, ">>$tmp_file" ) ) ){
		&passwd_file_unlock( "$file_nm.lk" );
		return(0);
	}
	else {
		if ( ! ( open(READ, "$file_nm" ) ) ){
			close TFP;
			unlink( $tmp_file );
			return(0);
		}
		else {
			undef $find;
			while (<READ>) {
				$_ = Encode::decode('utf8', "$_");
				$c = substr($_,0,1);
				if ( ( $c eq '#' ) || $c eq '' ){
					print TFP Encode::encode('utf8', "$_");
					next;
				}
				$w = &Dirpasswd::get_user($_);
				if ( $user ne $w ){
					print TFP Encode::encode('utf8', "$_");
					next;
				} else {
					#----delete-----#
					$find = 1;
				}
			}
			if ( ! $find ){
				close READ;
				close TFP;
				unlink( $tmp_file );
				&passwd_file_unlock( "$file_nm.lk" );
				return( 0 );
			}
			else {
				close READ;
				close TFP;
				unlink( $file_nm );
				rename( $tmp_file,$file_nm );
				&passwd_file_unlock( "$file_nm.lk" );
				return( 1 );
			}
		}
	}
}

#------------------------------------------------------------------------------
#   find_user : ユーザ検索
#------------------------------------------------------------------------------
sub find_user {
	my ($file_nm, $user) = @_;
	my ($find, $c, $w);

	if ( length( $user ) == 0 ){ return(0); }

	if ( ! ( open(READ,"$file_nm") ) ){ return(-1); }

	while (<READ>){
		$c = substr($_,0,1);
		if ( ($c eq '#') || !($c) ){
			next;
		}
		$_ = Encode::decode('utf8', "$_");
		$w = &Dirpasswd::get_user($_);
		if ( $user eq $w ) {
			$find = 1;
			last;
		}
	}
	close READ;

	if ( !$find ){ return(0); }

	return(1);
}

#------------------------------------------------------------------------------
#   get_user : パスワードファイルの行からユーザ名を取得
#------------------------------------------------------------------------------
sub get_user {
	my ($line) = @_;
	my (@data);

	@data = split(/:/,$line);

	if ($#data != 1) {
		'';
	} else {
		$data[0];
	}
}

#-----------------------------------------------------------------------------#
#   find_user_check : ユーザ検索（パスワードチェック有り）
#-----------------------------------------------------------------------------#
#   input(1)  : パスワードファイルパス
#   input(2)  : ユーザ名
#   input(3)  : パスワード
#-----------------------------------------------------------------------------#
#   output(1) : 0・・・アンマッチ  1・・・マッチ
#-----------------------------------------------------------------------------#
sub find_user_check {
	my ($file_nm, $user, $pass) = @_;
	my ($find, $c, $w, $x, $xx, $salt);

	if ( length( $user ) == 0 || length( $pass ) == 0 ){ return(0); }

	if ( ! ( open(READ,"$file_nm") ) ){ return(-1); }

	while (<READ>){
		chomp;
		$c = substr($_,0,1);
		if ( ($c eq '#') || !($c) ){
			next;
		}
		$_ = Encode::decode('utf8', "$_");
		( $w, $x ) = &Dirpasswd::get_user_check($_);
		$salt = substr($x,0,2);
		$xx = &Dirpasswd::get_password($pass,$salt);
		if ( $user eq $w && $x eq $xx ) {
			$find = 1;
			last;
		}
	}
	close READ;

	if ( !$find ){ return(0); }

	return(1);
}

#-----------------------------------------------------------------------------#
#   get_user_check : ユーザ名とパスワードを取得
#-----------------------------------------------------------------------------#
#   input(1)  : 1レコードのデータ
#-----------------------------------------------------------------------------#
#   output(1) : ユーザ名
#   output(2) : パスワード
#-----------------------------------------------------------------------------#
sub get_user_check {
	my ($line) = @_;
	my (@data);

	@data = split(/:/,$line);

	if ($#data != 1) {
		return('');
	} else {
		return($data[0],$data[1]);
	}
}

#------------------------------------------------------------------------------
#   get_password : パスワードを暗号化
#------------------------------------------------------------------------------
sub get_password {
	my ($pw,$s) = @_;
	my ($salt, @itoa64, $v, $n, $arr_no, $rtn);
	@itoa64 = ('.','/','0','1','2','3','4','5','6','7','8','9',
			   'A','B','C','D','E','F','G','H','I','J','K','L','M',
			   'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
			   'a','b','c','d','e','f','g','h','i','j','k','l','M',
			   'n','o','p','q','r','s','t','u','v','w','x','y','z');

	if ( length($s) == 2 ) {
		$salt = $s;
	} else {
		$v = int(rand()*100000);
		$n = 2;
		while (--$n >= 0) {
			$arr_no = $v & hex("3F");
			$salt .= $itoa64[$arr_no];
			$v >>= 6;
		}
	}

	$rtn = crypt($pw, $salt);
	return($rtn);
}

#------------------------------------------------------------------------------
#   passwd_file_lock : 専用 ファイルロック
#------------------------------------------------------------------------------
sub passwd_file_lock {
	my ($lock_file)   = $_[0];
	my ($in_alarm_interval)   = $_[1];

	my @dirs = split('/',$lock_file);
	my $file_name = pop( @dirs );
	my $file_dir  = join('/',@dirs);
	my $real_name = ".filelock_${file_name}";

	if ( -d $file_dir && -r $file_dir && -w $file_dir ){

		if ( ! -r "$file_dir/$real_name" ){
			`/bin/touch $file_dir/$real_name`;
			unlink( $lock_file );
		}
		my $alarm_interval = 5;
		if ( $in_alarm_interval =~ /^[0-9]+$/ && $in_alarm_interval > 0 ){
			$alarm_interval = $in_alarm_interval;
		}
		my $maxlock_sec = 600;

		while( ! symlink( $real_name,$lock_file ) ) {
			if ( --$alarm_interval <= 0 ){
				return( -1 );
			}
			else {
				my $timestmp = &DbmDirpasswd_timestmp( $lock_file );
				if ( $maxlock_sec > 0
						&& ( time - $timestmp > $maxlock_sec ) ){
					passwd_file_unlock( $lock_file );
					$alarm_interval = $in_alarm_interval;
				}
				else { sleep( 1 ); }
			}
		}
		return( 0 );
	}
	else { return ( -1 ); }
}

#------------------------------------------------------------------------------
#   passwd_file_unlock : Dirpasswd.pl専用 ファイルアンロック
#------------------------------------------------------------------------------
sub passwd_file_unlock {
	my ($unun) = unlink($_[0]);
	return($unun);
}

#------------------------------------------------------------------------------
#   passwd_path : Dirpasswd.pl専用 ファイルパスチェック
#------------------------------------------------------------------------------
sub passwd_path ($) {
	my ( $in ) = shift;

	$in =~ s/[^a-zA-Z0-9-_\.\/]//g;
	$in =~ s/\.\.+//g;
	return( $in );
}

1;
