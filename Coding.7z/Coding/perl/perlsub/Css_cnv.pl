package Css_cnv;
#----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  クロスサイトスクリプティング対処文字変換パッケージ
#     Program Name   :  Css_cnv.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#----------------------------------------------------------------------------#
#     version 1.0.0  : 2010.11.11 (YU)     New Create
#----------------------------------------------------------------------------#
#
#     新MG用ライブラリ version 1.0.1 を元にリニューアル新規作成
#
#     仕様概要
#             クロスサイトスクリプティング対処文字変換
#             を行います。
#
#     動作環境
#             [1] Linux環境専用
#
#     パッケージ使用方法
#
#             [1] 共通文字列変換(CSS対応処理版)
#                 $rtn = &Css_cnv::string( $scala,\%mode);
#
#             [2] 共通文字列変換ハッシュ版(CSS対応処理版)
#                 &Css_cnv::hash( \%in,\%mode);
#
#     返り値の説明
#             %in  -> nameをkeyとした連想配列
#
#     処理制御パラメータの説明(\%modeリファレンス)
#
#             %mode  -> nameをkeyとした連想配列
#             文字列変換処理を行ないたくない文字を指定可能
#
#             指定方法
#
#              $mode{"\x26"} = "off" ;   #行ないたくない文字（未変換）は'off'指定
#
#              $mode{"\x26"} = '&amp;' ; #違う文字に変換したい場合(下記の文字のみ)
#              (\x26,\x3C,\x3E,\x09,\x22,\x27,\x2A,\x2C,\x3F,\x5C,\x60,\x7C,\x7E)
#
#             ※ディフォルトで制御文字
#                     [\x01-\x08]
#                     [\x0B-\x0C]
#                     [\x0E-\x1F]
#                     は、削除します。
#               CSS対処の為、< > & ３つについては、必ず変換すること
#
#     注意事項
#             このライブラリでバイナリデータを変換しないように注意する
#             (WWWDecode:autoなどで画像データがある場合はスキップします。)
#----------------------------------------------------------------------------#
use utf8;
use strict;

my $version = "1.0.0";
my $library_name = 'Css_cnv.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#----------------------------------------------------------------------------#
#     string : 文字列変換
#----------------------------------------------------------------------------#
sub string {

	my ( $d ,$mode) = @_ ;
	my ($ot) ;

	undef $ot ;

	$d =~ s/[\x01-\x08]|[\x0B-\x0C]|[\x0E-\x1F]//g ;

	#------ CSS対象専用のsw --------#
	if(defined $mode->{"\x26"}){
		if($mode->{"\x26"} ne 'off'){
			$d =~ s/\x26/$mode->{"\x26"}/g ;
		}
	}else{
		$d =~ s/\x26/＆/g ;
	}

	if(defined $mode->{"\x3C"}){
		if($mode->{"\x3C"} ne 'off'){
			$d =~ s/\x3C/$mode->{"\x3C"}/g ;
		}
	}else{
		$d =~ s/\x3C/＜/g ;
	}

	if(defined $mode->{"\x3E"}){
		if($mode->{"\x3E"} ne 'off'){
			$d =~ s/\x3E/$mode->{"\x3E"}/g ;
		}
	}else{
		$d =~ s/\x3E/＞/g ;
	}

	if(defined $mode->{"\x09"}){
		if($mode->{"\x09"} ne 'off'){
			$d =~ s/\x09/$mode->{"\x09"}/g ;
		}
	}else{
		$d =~ s/\x09/ /g ;
	}

	if(defined $mode->{"\x22"}){
		if($mode->{"\x22"} ne 'off'){
			$d =~ s/\x22/$mode->{"\x22"}/g ;
		}
	}else{
		$d =~ s/\x22/”/g ;
	}

	if(defined $mode->{"\x27"}){
		if($mode->{"\x27"} ne 'off'){
			$d =~ s/\x27/$mode->{"\x27"}/g ;
		}
	}else{
		$d =~ s/\x27/’/g ;
	}

	if(defined $mode->{"\x2A"}){
		if($mode->{"\x2A"} ne 'off'){
			$d =~ s/\x2A/$mode->{"\x2A"}/g ;
		}
	}else{
		$d =~ s/\x2A/＊/g ;
	}

	if(defined $mode->{"\x2C"}){
		if($mode->{"\x2C"} ne 'off'){
			$d =~ s/\x2C/$mode->{"\x2C"}/g ;
		}
	}else{
		$d =~ s/\x2C/，/g ;
	}

	if(defined $mode->{"\x3F"}){
		if($mode->{"\x3F"} ne 'off'){
			$d =~ s/\x3F/$mode->{"\x3F"}/g ;
		}
	}else{
		$d =~ s/\x3F/？/g ;
	}

	if(defined $mode->{"\x5C"}){
		if($mode->{"\x5C"} ne 'off'){
			$d =~ s/\x5C/$mode->{"\x5C"}/g ;
		}
	}else{
		$d =~ s/\x5C/￥/g ;
	}

	if(defined $mode->{"\x60"}){
		if($mode->{"\x60"} ne 'off'){
			$d =~ s/\x60/$mode->{"\x60"}/g ;
		}
	}else{
		$d =~ s/\x60/｀/g ;
	}

	if(defined $mode->{"\x7C"}){
		if($mode->{"\x7C"} ne 'off'){
			$d =~ s/\x7C/$mode->{"\x7C"}/g ;
		}
	}else{
		$d =~ s/\x7C/｜/g ;
	}

	if(defined $mode->{"\x7E"}){
		if($mode->{"\x7E"} ne 'off'){
			$d =~ s/\x7E/$mode->{"\x7E"}/g ;
		}
	}else{
		$d =~ s/\x7E/～/g ;
	}

	return( $d );
}
#----------------------------------------------------------------------------#
#     hash : ハッシュ変換
#----------------------------------------------------------------------------#
sub hash {
	my ( $in ,$mode) = @_;
	my ( $n,$v );

	my %image_name;
    my %image_type;
	my @keys = sort keys %$in;
	foreach my $n ( @keys ) {
		if ( defined $in->{$n.'_name'} && defined $in->{$n.'_type'} ) {
			$image_name{$n.'_name'} = $n;
			$image_type{$n.'_type'} = $n;
		} elsif ( $image_name{$n} ne '' && $in->{$n} ) {
		} elsif ( $image_type{$n} ne '' && $in->{$n} ) {
		} else {
			$v = &string( $in->{$n},$mode );
			$in->{$n} = $v;
		}
	}
}

1;
