package CgiError;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  CGI エラー制御ライブラリ
#     Program Name   :  CgiError.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#-----------------------------------------------------------------------------#
#
#     新MG用ライブラリ version 2.O.2 を元にリニューアル新規作成
#
#     仕様概要
#             CGI エラー制御ライブラリ
#
#     動作環境
#             [1] Linux環境専用
#
#  <仕様概要>
#
#     このパッケージはCGIやバッチプログラムで検出されるエラーの対処を
#     ライブラリ化したものです。すべてのプログラムで必ず利用します。
#     エラーには、プログラムが処理の続行が不可能な場合の「異常終了」と、
#     入力情報等の不足による「ユーザエラー」があります。
#     「異常終了」の場合には、エラー情報が「監視メール」により専用のサーバ
#     に取り込まれ、監視がされます。
#     「ユーザエラー」は、通常仕様により明示的にエラー画面等が指示されますが、
#     その指示がない場合に利用します。
#
#    「異常終了」には、ユーザ画面上に異常画面を表示し、exitする「abend」
#     と、メインに処理を戻し、対応を行うことができる「abend_return」の2種類
#     が用意されています。
#
#     +---------------+-------+------+------------------------------+--------+
#     |   関数        |  CGI  |バッチ| 呼出し後の処理               | 監視ML |
#     +---------------+-------+------+------------------------------+--------+
#     |  abend        |   ○  |  ×  | エラー画面を表示し強制終了   |   ○   |
#     |  abend_return |   ○  |  ○  | メインに戻る為対応必要       |   ○   |
#     |  warning      |   ○  |  ○  | メインに戻る為対応必要       |   ○   |
#     |  normal_error |   ○  |  ×  | 画面表示を行い強制終了       |   ×　 |
#     +---------------+-------+------+------------------------------+--------+
#
#     「abend_return」「warning」は、エラー情報を監視MLにメールしてメインに
#      処理を戻すので呼出し後の処理を品目プログラムで行う必要があります。
#
#     「abend」関数、「normal_error」関数により表示される画面は、システム種別
#      (WWW,i-mode,JSKY,ez-web)を自動判別し、適切な画面を表示します。
#      (V1.3.1,V1.5.1対応)
#
#     「監視用のMLのアドレス」、「abend時のエラー画面」は、CgiError設定ファイル
#      により変更することが可能です。
#
#      CgiError設定ファイルパス ＝ /WWW/[品目ディレクトリ名]/data/CgiError/
#      +---------------------------+-----------------------------------------------+
#      | ファイル名                |  説明                                         |
#      +---------------------------+-----------------------------------------------+
#      | CgiError.conf             |  監視用MLの送信先アドレス設定ファイル         |
#      | web_error.base (UTF-8)    |  WEBの場合の異常終了画面(abend関数時利用)     |
#      | imode_error.base (SJIS)   |  i-modeの場合の異常終了画面(abend関数時利用)  |
#      | vodafone_error.base (SJIS)|  vodafoneの場合の異常終了画面(abend関数時利用)|
#      | ez_error.base (SJIS)      |  ez-webの場合の異常終了画面(abend関数時利用)  |
#      +---------------------------+-----------------------------------------------+
#    　 ※アドレス設定ファイルはEUC、エラー画面雛形はSJIS固定。 (V1.E.1対応)
#
#  <パッケージ関数使用方法>
#
#  [1] 通常のエラー処理 ( &CgiError::normal_error )
#      エラー画面を表示し、強制終了（exit）します。
#      入力項目のエラー等、ユーザエラーの際に利用します。
#      （仕様で明示的にエラー対処が指示されている場合にはそれに従う）
#
#      &CgiError::normal_error( 'エラー内容' );
#
#      ※エラー内容を配列で与えると、1行毎に改行して表示されます。
#
#  [2] 異常終了処理１  ( &CgiError::abend )
#      プログラムが処理続行不可能なエラーを検出した際に呼び出します。
#      この関数が呼び出されると、エラー内容が監視メールとして送信され、
#      異常終了の画面を表示し、強制終了（exit）します。
#
#      &CgiError::abend( 'エラー内容' );
#
#      ※エラー内容は「WEBアプリケーションエラー規約」に基づき指定する。
#
#  [3] 異常終了処理２ ( &CgiError::abend_return )
#      上記「abend」と処理は同一だが、強制終了はせず、メインに制御を返します。
#      異常を検出した後、処理をメインで行う必要のあるときに利用します。
#      ※バッチプログラムの場合には必ずこちらの関数を利用します。
#
#      &CgiError::abend_return( 'エラー内容' );
#
#      ※エラー内容は「WEBアプリケーションエラー規約」に基づき指定する。
#
#  [4] ワーニングエラー処理 ( &CgiError::warning )
#      システム的に以後の処理が不可能な場合のAbendとちがい、ワーニングは
#      設計時に決められた状況に応じて発行します。ワーニング内容は監視メールと
#      して送信され、他のABEND時の内容と同様にアプリケーション監視システム
#      で内容を確認し、対応が行われます。
#      また、abend_return同様に、この関数の呼出し後は、呼び出し元（メイン）
#      に処理が返ってくるので、その後の対応を行う必要があります。
#
#      &CgiError::warning( 'レベル','エラー内容' );
#
#      ※レベルは「A」「B」「C」で指定可能。
#      ※レベルの設定やエラー内容は「WEBアプリケーションエラー規約」に基づき
#        指定する。
#
#  [4] アベンド画面返却 ( &CgiError::abend_html )
#      システム種別(WWW,i-mode,JSKY,ez-web)を自動判別し、適切なアベンド画面
#      を表示します。もし、専用のアベンド画面（/WWW/[品目名]/http/）
#      が用意されている場合には、その画面を返却します。
#      この関数は、画面を返却するのみで、エラー対応はしません。通常、「abend」
#      関数の内部処理として利用しますが、「abend_return」を利用した場合に、
#      最後に呼び出す処理として利用します。
#
#-----------------------------------------------------------------------------#
use IO::Handle;
use utf8;
use Unicode::Japanese;
use Encode;

my $version = "1.0.0";
my $library_name = 'CgiError.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#-----------------------------------------------------------------------------#
#    sub normal_error : エラー画面を表示するのみ。(exitする)
#-----------------------------------------------------------------------------#
#    input  : (1) エラーメッセージ
#-----------------------------------------------------------------------------#
sub normal_error (){
	my( @err ) = @_;

	my $sysname = &sysname();
	my $head = '';
	my $html = '';

	if ( $sysname eq 'IMODE'  || $sysname eq 'PIMODE'
		 || $sysname eq 'SKY' || $sysname eq 'PSKY'
		 || $sysname eq 'WAP' || $sysname eq 'PWAP'     ){
		$head .= "Content-Type: text/html; charset=SJIS\n";
		$html .= "<html><head><title>エラーが検出されました";
		$html .= "</title></head>\n";
		$html .= "<body>\n";
		$html .= "<hr>下記エラーが検出されました<hr>\n";
		$html .=  "■エラーメッセージ<br>";
		foreach my $a(@err){
			utf8::upgrade($a);
			$a = &string_change( $a );
			$html .= $a."<br>\n"; 
		}
		$html .= "<hr>\n";
		$html .= "</body></html>";

		my $html2 = Encode::encode('utf8', $html);
		my $len = length($html2);
		$head .= "Content-length: $len\n\n";
		$head = Unicode::Japanese->new($head,'utf8')->sjis;
		$html = Unicode::Japanese->new($html,'utf8')->sjis;

		print $head;
		print $html;
		exit;
	}
	else {
		$head .= "Content-Type: text/html; charset=UTF-8\n";
		$html .= "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n";
		$html .= "<html><head><title>CGI Error</title></head>\n";
		$html .= "<body bgcolor=white>\n";
		$html .= "<hr>\n";
		$html .= "<font size=+2><b>下記エラーが検出されました</b></font>\n";
		$html .= "<hr><br>\n";
		$html .=  "■エラーメッセージ<br>";
		$html .=  "<blockquote>\n";
		foreach my $a(@err){
			utf8::upgrade($a);
			$a = &string_change( $a );
			$html .= $a."<br>\n";
		}
		$html .= "</blockquote>\n";
		$html .= "<hr><br>\n";
		$html .= "<form><input type=button value=\"戻る\" onClick='history.back()'>";
		$html .= "</form>\n<br><br><br>\n";
		$html .= "</body></html>";

		$html = Encode::encode('utf8', $html);
		my $len = length($html);
		$head .= "Content-length: $len\n\n";
		$head = Encode::encode('utf8', $head);
		print $head;
		print $html;
		exit;
	}
}

#-----------------------------------------------------------------------------#
#    sub abend_html : アベンド画面の返却
#-----------------------------------------------------------------------------#
#    input  : エラーメッセージ（制作環境時のみ表示します）
#-----------------------------------------------------------------------------#
#    output : アベンド画面(ヘッダ含めて返却）
#-----------------------------------------------------------------------------#
sub abend_html(){
	my @err = @_; 

	my $head = '';
	my $html = '';
	my $abend_html;


	# --- 品目情報取得
	my (@getpwuid, $hinmei, $home_dir);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	my ( $env_sw ) = &test_server();

	my $err_base = '/WWW/' . $hinmei.'/http/';

	my $sysname = &sysname();
	if ( $sysname eq 'IMODE'  || $sysname eq 'PIMODE'
		 || $sysname eq 'SKY' || $sysname eq 'PSKY'     ){
		$head .= "Content-Type: text/html; charset=SJIS\n";

		if( $sysname eq 'IMODE' || $sysname eq 'PIMODE' ) {
			$err_base .= 'imode_error.base';
		} else {
			$err_base .= 'vodafone_error.base';
		}

		if( -s $err_base ) {
			my $IN = new IO::Handle;
			if( open($IN, $err_base) ) {
				while(<$IN>) {
					$html .= $_;
				}
				close $IN;
			}
			$html = Unicode::Japanese->new($html,'sjis')->getu;
		}
		if( $html eq '' ) {
			$html .= "<html><head><title>";
			$html .= "Error : Process Interrupted.";
			$html .= "</title></head>\n";
			$html .= "<body><hr>\n";
			$html .= "The error occurred and processing was interrupted";
			$html .= "</center><hr>\n";
			$html .= "エラーが発生し処理が中断されました。\n";

			if ( $env_sw == 0
				){
				$html .= "<br><br><br><br><br>\n";
				$html .= "■プログラムからのメッセージ（製作環境、";
				$html .= "検証環境のみ表示）<hr>";
				foreach my $err(@err){
					utf8::upgrade($err);
					$err = &string_change( $err );
					$html .= "$err<br>";
				}
				$html .= "<hr>\n";
			}
			$html .= "</body></html>\n";
		}
		my $html2 = Encode::encode('utf8', $html);
		my $len = length($html2);
		$head .= "Content-length: $len\n\n";

		$abend_html = join('',$head,$html);
		$abend_html = Unicode::Japanese->new($abend_html,'utf8')->sjis;

	}
	elsif ( $sysname eq 'WAP' || $sysname eq 'PWAP' ){
		$err_base .= 'ez_error.base';
		if( -s $err_base ) {
			my $IN = new IO::Handle;
			if( open($IN, $err_base) ) {
				while(<$IN>) {
					$html .= $_;
				}
				close $IN;
			}
			$html = Unicode::Japanese->new($html,'sjis')->getu;
		}

		if ( $html =~ /<HDML\s+.*>/i ){
			$head .= "Content-Type: text/x-hdml;charset=Shift_JIS\n";
		}
		else {
			$head .= "Content-type: text/html; charset=SHIFT_JIS\n";
			if ( $html eq '' ) {
				$html .= "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n";
				$html .= "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML Basic 1.0//EN\"";
				$html .= "  \"http://www.w3.org/TR/xhtml-basic/xhtml-basic10.dtd\">\n";
				$html .= "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ja\">\n";
				$html .= "<head>\n<title>";
				$html .= "Error : Process Interrupted.";
				$html .= "</title></head>\n";
				$html .= "<body><hr />\n";
				$html .= "The error occurred and processing was interrupted";
				$html .= "<hr />\n";
				$html .= "エラーが発生し処理が中断されました。\n";
				if ( $env_sw == 0
					){
					$html .= "<br /><br /><br /><br /><br />\n";
					$html .= "■プログラムからのメッセージ（製作環境、";
					$html .= "検証環境のみ表示）<hr />";
					foreach my $err(@err){
						utf8::upgrade($err);
						$err = &string_change( $err );
						$html .= "$err<br />";
					}
					$html .= "<hr />\n";
				}
				$html .= "</body></html>\n";
			}
		}

		my $html2 = Encode::encode('utf8', $html);
		my $len = length($html2);
		$head .= "Content-length: $len\n\n";
		$abend_html = join('',$head,$html);
		$abend_html = Unicode::Japanese->new($abend_html,'utf8')->sjis;

	}
	else {
		$head .= "Content-Type: text/html; charset=UTF-8\n";

		$err_base .= 'web_error.base';
		if( -s $err_base ) {
			my $IN = new IO::Handle;
			if( open($IN, $err_base) ) {
				binmode($IN, ":utf8");
				while(<$IN>) {
					my $line = $_;
					$html .= $line;
				}
				close $IN;
			}
		}
		if( $html eq '' ) {
			$html .= "<html>\n<head>";
			$html .= "<title>Error : Process Interrupted.</title>";
			$html .= "</head><body bgcolor=white>\n<center>\n";
			$html .= "<table border=0 cellpadding=5 cellspacing=0><tr>";
			$html .= "<td align=center>\n";
			$html .= "<table border=1 cellpadding=0 cellspacing=0 ";
			$html .= "bordercolor=black><tr>\n";
			$html .= "<td width=50 height=50 bgcolor=yellow ";
			$html .= "align=center valign=center>\n";
			$html .= "<font size=+3><b>!</b></font></td></tr></table>\n";
			$html .= "</td></tr><tr>\n";
			$html .= "<td align=center><br><b>\n";
			$html .= "The error occurred and processing was ";
			$html .= "interrupted.<br>\n";
			$html .= "エラーが発生し処理が中断されました。</b>\n";
			$html .= "</td></tr>\n";

			if ( $env_sw == 0 ){
				$html .= "<tr><td><br></td></tr>\n";
				$html .= "<tr><td align=center>";
				$html .= "<table border=1 cellpadding=5 cellspacing=0>\n";
				$html .= "<tr><td bgcolor=#dddddd>";
				$html .= "<b>--　プログラムからのメッセージ（製作環境、";
				$html .= "検証環境のみ表示）--</b>";
				$html .= "</td></tr>\n";
				foreach my $err(@err){
					utf8::upgrade($err);
					$err = &string_change( $err );
					$html .= "<tr><td align=center>$err</td></tr>"; 
				}
				$html .= "</table>\n";
				$html .= "</td></tr>\n";
			}
			$html .= "</table><br>\n";
			$html .= "</body></html>\n";

			my $html2 = Encode::encode('utf8', $html);
			my $len = length($html2);
			$head .= "Content-length: $len\n\n";
			$abend_html = join('',$head,$html);
			$abend_html = Encode::encode('utf8', $abend_html);

		}
	}
	return( $abend_html );
}

#-----------------------------------------------------------------------------#
#    sub abend : プログラムにて検出された処理続行不能なエラー (dieする）
#-----------------------------------------------------------------------------#
#    input  : (1) エラーメッセージ
#-----------------------------------------------------------------------------#
sub abend(){
	my( @err ) = @_;

	my $s_error  = $?;
	my $p_error  = $!;
	my $error_today = &error_today_get;
	my $error_time  = &error_time_get;

	my $abend_html = &abend_html( @err );
	print $abend_html;

	&error_mailsend( 'CgiError','A',
				$error_today,$error_time,$p_error,$s_error,@err );
	die &error_rec_get( 'CgiError','A',
				$error_today,$error_time,$p_error,$s_error );
}

#-----------------------------------------------------------------------------#
#    sub abend_return : プログラムにて検出された処理続行不能なエラー (return）
#-----------------------------------------------------------------------------#
#    input  : (1) エラーメッセージ
#-----------------------------------------------------------------------------#
sub abend_return(){
	my ( @err ) = @_;

	my $s_error  = $?;
	my $p_error  = $!;

	my $error_today = &error_today_get;
	my $error_time  = &error_time_get;

	&error_mailsend( 'CgiError','A',
				$error_today,$error_time,$p_error,$s_error,@err );

	warn &error_rec_get( 'CgiError','A',
				$error_today,$error_time,$p_error,$s_error );

	return;
}

#-----------------------------------------------------------------------------#
#    sub warning : 設計時に明示的に指示されるワーニング
#-----------------------------------------------------------------------------#
#    input  : (1) エラーレベル(A,B,C)
#    input  : (1) エラーメッセージ
#-----------------------------------------------------------------------------#
sub warning(){
	my ( $level,@err ) = @_;

	if ( $level =~ /^(A|B|C)$/i  ){ $level = uc( $level ); }
	else  {
		@err = ( $level,@err );
		$level = 'A';
	}

	my $s_error  = $?;
	my $p_error  = $!;
	my $error_today = &error_today_get;
	my $error_time  = &error_time_get;

	&error_mailsend( 'Warning',$level,
				$error_today,$error_time,$p_error,$s_error,@err );
	warn &error_rec_get( 'Warning',$level,
				$error_today,$error_time,$p_error,$s_error );

	return;
}

#-----------------------------------------------------------------------------#
#    sub error_rec_get : エラーログに表示する内容を返す
#-----------------------------------------------------------------------------#
#    input  : (1) エラータイプ（CgiError or Warning)
#    input  : (2) エラーレベル（CgiErrorは固定でA、ワーニングは可変）
#    input  : (3) 現在の日付（9999/99/99）
#    input  : (4) 現在の時間（99:99:99）
#    input  : (5) 現在のerrnoの値
#    input  : (6) 最後にコマンド実行したものが返したステータス
#-----------------------------------------------------------------------------#
#    output : (1) エラーログに表示する内容
#-----------------------------------------------------------------------------#
sub error_rec_get(){
	my ( $type,$level,$today,$time,$p_error,$s_error ) = @_;

	my $script_name = '';
	if ( length( $ENV{'SCRIPT_FILENAME'} ) > 0 ){
		$script_name = $ENV{'SCRIPT_FILENAME'};
	}
	else {
		$script_name = $0;
	}

	my $rec = '';
	$rec  = "$type($level): [$today $time]\t";
	$rec .= $script_name;
	$rec .= "\t";
	$rec .= "\$\!=$p_error";
	$rec .= "\t";
	$rec .= "\$\?=$s_error";

	return( $rec );
}

#-----------------------------------------------------------------------------#
#    sub error_mailsend : エラー内容メール送信
#-----------------------------------------------------------------------------#
#    input  : (1) エラータイプ（'CgiError' or 'Warning')
#    input  : (2) エラーレベル（CgiErrorは固定でA、ワーニングは可変
#    input  : (3) 現在の日付（9999/99/99）
#    input  : (4) 現在の時間（99:99:99）
#    input  : (5) 現在のerrnoの値
#    input  : (6) 最後にコマンド実行したものが返したステータス
#    input  : (7) エラーメッセージ
#-----------------------------------------------------------------------------#
sub error_mailsend(){
	my ( $type,$level,$today,$time,$p_error,$s_error,@error ) = @_;
	my ( $error_to, $conf_file, $mail_str );

	# --- 品目情報取得
	my (@getpwuid, $hinmei, $home_dir);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	my $mail  = '/usr/lib/sendmail';
	$error_to = 'cgi_err@ml.mediagalaxy.ne.jp';

	my $to = '';
	my ( $env_sw ) = &test_server();
	if ( $env_sw == 0 ){ return; }
	else {

		#---- 送信先設定ファイルパス ----#
		$conf_file = "/WWW/$hinmei/data/CgiError/CgiError.conf";
		if( -s $conf_file ) {
			if( open(IN, $conf_file) ) {
				binmode(IN, ":utf8");
				while(<IN>) {
					$_ = s/　/ /g;

					next if substr($_, 0, 1) eq '#';
					s/[\s\r\n]+$//g;
					next if substr($_, 0, 3) ne 'TO=';
					$to = substr($_, 3);
				}
				close IN;
			}
		}
		if( $to eq '' ) { 
			$to = $error_to;
		}
	}

	# ホストドメインとスクリプト名の取得（バッチの場合考慮）
	my $host_name = '';
	if ( length( $ENV{'HTTP_HOST'} ) > 0 ){
		$host_name = $ENV{'HTTP_HOST'};
	}
	else {
		chomp( $host_name = `hostname`);
	}
	my $script_name = '';
	if ( length( $ENV{'SCRIPT_FILENAME'} ) > 0 ){
		$script_name = $ENV{'SCRIPT_FILENAME'};
	}
	else {
		$script_name = $0;
	}

	my  $subject =
		"CgiError [$host_name $script_name $today $time]";

	if ( open (MMM,"\| $mail -f $error_to -t -oi") ){
		print MMM "Mime-Version: 1.0\n";
		print MMM "Content-type: text/plain; charset=\"ISO-2022-JP\"\n";
		print MMM "To: $to\n";
		print MMM "Subject: ".$subject."\n";

		print MMM "X-ERROR-TYPE: $type\n";
		print MMM "X-ERROR-LEVEL: $level\n";
		print MMM "X-ERROR-SERVER: $host_name\n";
		my $dir_name = $hinmei;
		print MMM "X-ERROR-DIR_NAME: $dir_name\n";
		print MMM "X-ERROR-PATH: $script_name\n";
		print MMM "X-ERROR-DATE: $today\n";
		print MMM "X-ERROR-TIME: $time\n";
		print MMM "\n";
		$mail_str .= join('',
						  "-" x 78,"\n","\t$subject\n",
						  "-" x 78,"\n\n" );
		foreach my $err(@error){
			$mail_str .= "\t$err\n";
		}
		$mail_str .= join('',
						  "\n","-" x 78,"\n","\tPerl ENV\n",
						  "-" x 78,"\n\n" );
		$mail_str .= "\t\$\!=$p_error\n";
		$mail_str .= "\t\$\?=$s_error\n";
		$mail_str .= join('',
						  "\n","-" x 78,"\n","\tENVROMENT\n",
						  "-" x 78,"\n\n");
		while( my ($a,$b) = each %ENV ){
			$mail_str .= "\t$a : $b\n";
		}
		$mail_str .= join('',
						  "\n","-" x 78,"\n",
						  "\tDISK LIST\n","-" x 78,"\n\n" );
		my $df = `/bin/df -k`;
		$mail_str .= "$df\n";
		$mail_str .= join('',
						  "\n","-"x 78,"\n","\tUPTIME LIST\n",
						  "-" x 78,"\n\n" );

		my $up = '';
		if( -s "/bin/uptime" )             { $up = `/bin/uptime`; }
		elsif( -s "/usr/bin/uptime" )      { $up = `/usr/bin/uptime`; }
		elsif( -s "/usr/local/bin/uptime" ){ $up = `/usr/local/bin/uptime`; }
		else {
			my $uptime_path = `which uptime`;
			if( -s $uptime_path ){ $up = `$uptime_path`; }
		}

		$mail_str .= "$up\n";
		$mail_str .= join('',
						  "\n", "-" x 78, "\n",
						  "\tSTDIN DATA\n", "-" x 78, "\n\n" );
		my $stdin = '';
		read(STDIN,$stdin,$ENV{'CONTENT_LENGTH'});
		$mail_str .= "$stdin\n";
		$mail_str = Unicode::Japanese->new($mail_str,'utf8')->jis;

		print MMM $mail_str;

		close MMM;
	}
}

#-----------------------------------------------------------------------------#
#    sub error_today_get : エラーサブルーチン専用日付返却サブルーチン
#-----------------------------------------------------------------------------#
#    output : (1) 現在の日付（9999/99/99）
#-----------------------------------------------------------------------------#
sub error_today_get(){
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

	$mon++;
	$mday = "0$mday" if ($mday < 10);
	$mon  = "0$mon" if ($mon < 10);
	$year += 1900;

	return( "$year/$mon/$mday" );
}

#-----------------------------------------------------------------------------#
#    sub error_time_get : エラーサブルーチン専用時間返却サブルーチン
#-----------------------------------------------------------------------------#
#    output : (1) 現在の時間（99:99:99）
#-----------------------------------------------------------------------------#
sub error_time_get(){
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

	$hour = "0$hour" if ($hour < 10);
	$min  = "0$min"  if ($min  < 10);
	$sec  = "0$sec"  if ($sec  < 10);

	return( "$hour:$min:$sec");
}

#-----------------------------------------------------------------------------#
#    sub test_server: テストサーバの見分け
#-----------------------------------------------------------------------------#
#    output : (1) 開発 or 検証 … 0 ／ 本番 … 1
#    output : (2) 品目ディレクトリ
#-----------------------------------------------------------------------------#
sub test_server {

	# --- 品目情報取得
	my (@getpwuid, $hinmei, $home_dir);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	#----- 環境の把握 --------------------------------------------------------#
	my $env_sw = 1;   # デフォルト本番環境

	# 検証環境
	if ( substr($hinmei,3,1) == 2) {
		$env_sw = 0;
	# 開発環境
	}elsif ( substr($hinmei,3,1) == 3) {
		$env_sw = 0;
	}
	return( $env_sw );
}

#-----------------------------------------------------------------------------#
#    sub sysname : システム名（ WWW,IMODE,SKY,WAP ) を返却する
#-----------------------------------------------------------------------------#
#    output : (1) システム名
#-----------------------------------------------------------------------------#
sub sysname {
	my $sysname = '';

	if ( $ENV{'DOCUMENT_ROOT'} ){
		if ( length( $ENV{'HTTP_DOCOMO_OK'} ) > 0
			|| $ENV{'HTTP_USER_AGENT'} =~ /^DoCoMo/
			){
			$sysname = 'IMODE';
		}
		elsif ( length( $ENV{'HTTP_JPHONE_OK'} ) > 0
				|| length( $ENV{'HTTP_X_JPHONE_COLOR'} ) > 0
				|| length( $ENV{'HTTP_X_JPHONE_MSNAME'} ) > 0
				|| $ENV{'HTTP_USER_AGENT'} =~ /^J-PHONE/
				|| $ENV{'HTTP_USER_AGENT'} =~ /^MOT-/
				|| $ENV{'HTTP_USER_AGENT'} =~ /^Vodafone/
				|| $ENV{'HTTP_USER_AGENT'} =~ /^SoftBank/
			  ){
			$sysname = 'SKY';
		}
		elsif ( length( $ENV{'HTTP_EZ_OK'} ) > 0
				|| length( $ENV{'HTTP_X_UP_SUBNO'} ) > 0
				|| length( $ENV{'HTTP_X_UP_DEVCAP_ISCOLOR'} ) > 0
				|| length( $ENV{'HTTP_X_UP_DEVCAP_SCREENCHARS'} ) > 0
				|| $ENV{HTTP_USER_AGENT} =~ /^UP\.Browser/
				|| $ENV{HTTP_USER_AGENT} =~ /^KDDI-/
			  ){
			$sysname = 'WAP';
		}
	}
	return ( $sysname );
}

#----------------------------------------------------------------------------#
#     string_change : 文字列変換
#----------------------------------------------------------------------------#
sub string_change {

	my ( $d ) = @_ ; 

	$d =~ s/&/&amp;/g ;
	$d =~ s/"/&quot;/g ;
	$d =~ s/'/&#39;/g ;
	$d =~ s/</&lt;/g ;
	$d =~ s/>/&gt;/g ;

	#--- IEの&nbsp;（半角スペース）未変換バグ対応 ---------------------------#
	$d =~ s/&amp;nbsp;/ /g ;

	return( $d ); 

}
1;
