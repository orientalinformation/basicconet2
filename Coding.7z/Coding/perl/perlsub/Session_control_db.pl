package Session_control_db;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  セッションコンテナ制御ライブラリ DB版
#     Program Name   :  Session_control_db.pl
#     Create Date    :  2010.11.30
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.30 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#    comment         : セッション制御ライブラリ DB版
#                      セッション管理手法については共有文書をご参照ください。
#                      PHPのライブラリと完全互換しています。
#
#    注意事項
#        DBD::MySQL のバージョンが 4（以上） で、db_connect時のオプション
#        mysql_enable_utf8=>1 でコネクトしたdbhであることが使用条件です。
#
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ Session_control_db.pl version 1.2.4
#                       を元にリニューアル新規作成
#-----------------------------------------------------------------------------#
# [1] session_start : セッションスタート
#
#     ($rtn,$s_id) = &Session_control_db::session_start($dbh,$s_name,$term);
#
# [Input]
#     $dbh........DBハンドル
#     $s_name.....セッション名
#     $term.......有効期限
# [Output]
#     $rtn........結果(1:正常,0:異常終了,-1:有効期限指定エラー,-2:Session ID発行エラー)
#　   $s_id.......セッションID
#-----------------------------------------------------------------------------#
# [2] session_check : セッションチェック
#
#     $rtn = &Session_control_db::session_check($dbh,$s_name,$s_id);
#
# [Input]
#     $dbh........DBハンドル
#     $s_name.....セッション名
#     $s_id.......セッションID
# [Output]
#     $rtn........結果(1:OK,0:有効期限切れ,-1:不正なSessionID,-2:コンテナが存在しない,-3:異常終了)
#-----------------------------------------------------------------------------#
# [3] container_get : コンテナからのデータ取得
#
#     ($rtn,$data) = &Session_control_db::container_get($dbh,$s_name,$s_id,$term);
#
# [Input]
#     $dbh........DBハンドル
#     $s_name.....セッション名
#     $s_id.......セッションID
#     $term.......有効期限
# [Output]
#     $rtn........結果(1:正常,0:有効期限切れ,-1:不正なSession ID,-2:コンテナ不在,-3:異常終了)
#     $data.......セッション情報（スカラー）
#-----------------------------------------------------------------------------#
# [4] container_set : コンテナデータの設定
#
#     $rtn = &Session_control_db::container_set($dbh,$s_name,$s_id,$d_area,$term);
#
# [Input]
#     $dbh........DBハンドル
#     $s_name.....セッション名
#     $s_id.......セッションID
#     $d_area.....セッション情報（スカラー）
#     $term.......有効期限
# [Output]
#     $rtn........結果(1:OK,0:有効期限切れ,-1:不正なSession ID,-2:Container不在,-3:その他エラー)
#-----------------------------------------------------------------------------#
# [5] scalar2hash : スカラ値をハッシュに変換
#
#     %hash = &Session_control_db::scalar2hash($scalar);
#
# [Input]
#     $scalar.....スカラーデータ
# [Output]
#     %hash.......ハッシュデータ
#-----------------------------------------------------------------------------#
# [6] hash2scalar : ハッシュをスカラ値に変換
#
#     $scalar = &Session_control_db::hash2scalar(%hash);
#
# [Input]
#     %hash.......ハッシュデータ
# [Output]
#     $scalar.....スカラーデータ
#-----------------------------------------------------------------------------#
# [7] session_change : Session ID変更
#
#     ($rtn,$new_s_id) = &Session_control_db::session_change($dbh,$s_name,$s_id);
#
# [Input]
#     $dbh........DBハンドル
#     $s_name.....セッション名
#     $s_id.......変更前セッションID
# [Output]
#     $rtn........結果(1:OK,0:有効期限切れ,-1:不正なSession ID,-2:Container不在,-3:Session ID発行エラー,-4:環境整備ミス)
#     $new_s_id...変更後セッションID
#-----------------------------------------------------------------------------#
# [8] session_end : Session 終了
#
#     $rtn = &Session_control_db::session_end($dbh,$s_name,$s_id);
#
# [Input]
#     $dbh........DBハンドル
#     $s_name.....セッション名
#     $s_id.......セッションID
# [Output]
#     $rtn........結果(1:OK,0:異常終了,-1:不正なSession ID,-2:Container不在)
#-----------------------------------------------------------------------------#

use utf8;
use Encode;
use DBD::mysql;
use Date::Calc qw( check_date Add_Delta_DHMS );
use Time::Local;

my $version = "1.0.0";
my $library_name = 'Session_control_db.pl';

&initial_setting();

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#    sub init : Initial Setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	#---- XSS対策 ----#
	my @env = qw(
				 SCRIPT_FILENAME HTTP_USER_AGENT HTTP_X_JPHONE_COLOR
				 HTTP_X_UP_SUBNO REMOTE_ADDR SERVER_ADDR UNIQUE_ID
				);

	foreach ( @env ) {
		$ENV{$_} =~ s/\</\&lt\;/g;
		$ENV{$_} =~ s/\>/\&gt\;/g;
		$ENV{$_} =~ s/\"/\&quot\;/g;
		$ENV{$_} =~ s/\'/\&\#39\;/g;
	}

	my @getpwuid = getpwuid($>);
	my $hinmei = $getpwuid[0];

	if($hinmei ne ''){
		$hin_dir = $hinmei;
	} else {
		print "Content-type:text/plain;charset=UTF-8\n\n";
		print Encode::encode('utf8', "Can't execute Session_control_db.pl!!\n");		exit;
	}

	$s_length = 33; # Session ID's Length

	@fields = qw(
		session_id start_date last_reference_date last_update_date
		delete_date get_cnt set_cnt data_code remote_addr user_agent data_area
	); # Container's Data Fields

	#---- Check carrier ----#
	$table_flg = '_w';
	if( $ENV{'HTTP_USER_AGENT'} =~ /^DoCoMo/ ) {
		$table_flg = '_i';
	}elsif($ENV{HTTP_USER_AGENT} =~ /^J-PHONE/ 
		   || $ENV{HTTP_USER_AGENT} =~ /^Vodafone/ 
		   || $ENV{HTTP_USER_AGENT} =~ /^MOT-/ 
		   || $ENV{HTTP_USER_AGENT} =~ /^SoftBank/ 
		  ){
		$table_flg = '_j';
	}elsif($ENV{HTTP_USER_AGENT} =~ /^UP\.Browser/
		   || $ENV{HTTP_USER_AGENT} =~ /^KDDI-/){
		$table_flg = '_e';
	}

	#---- 乱数の種を作成 ----#
	srand(time ^ ($$ + ($$ << 15)));

	#---- HTTP_USER_AGENT の頭から 1000 文字 を取得 ----#
	$http_user_agent = substr( $ENV{HTTP_USER_AGENT}, 0, 1000 );
}

#-----------------------------------------------------------------------------#
#    sub session_start : Session管理Start!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:正常,0:異常終了,-1:有効期限指定エラー,-2:Session ID発行エラー)
#　  output : (2) Session ID
#-----------------------------------------------------------------------------#
sub session_start {
	my( $dbh, $s_name, $term ) = @_;
	my $now = &now();

	#---- Check Param ----#
	#-- Session Name --#
	if( $s_name eq '' )  { return(0); }

	#-- Term --#
	my $s_term = &setTerm($now, $now, $now, $term);
	if( $now > $s_term )  { return(-1); }

	#---- Make Session ID ----#
	my $s_id = &makeSessionID();
	if( &blength($s_id) != $s_length )  { return(-2); }

	#---- 日付→timestamp値変換 ----#
	$now = &chg_timestamp($now, 1);
	$s_term = &chg_timestamp($s_term, 1);

	#---- Make Session Container ----#
	my $sql = "insert into $s_name$table_flg set ";
	$sql .= "session_id = " . $dbh->quote($s_id) . ",";
	$sql .= 'start_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_reference_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_update_date = ' . $dbh->quote($now) . ",";
	$sql .= 'delete_date = ' . $dbh->quote($s_term) . ",";
	$sql .= 'get_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'set_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'data_code = ' . $dbh->quote('utf8') . ",";
	$sql .= 'remote_addr = ' . $dbh->quote($ENV{'REMOTE_ADDR'}) . ",";
	$sql .= 'user_agent = ' . $dbh->quote($http_user_agent) . ",";
	$sql .= 'data_area = ' . $dbh->quote('');

	my $sth = &db_access($dbh, $sql) || return(0);
	$sth->finish;

	return( 1, $s_id );
}

#-----------------------------------------------------------------------------#
#    sub session_check : Session Check!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:OK,0:有効期限切れ,-1:不正なSessionID,-2:コンテナが存在しない,-3:異常終了)
#-----------------------------------------------------------------------------#
sub session_check {
	my( $dbh, $s_name, $s_id ) = @_;
	my $now = &now();

	#---- Check Session ID ----#
	if( $s_id eq '' || ( $s_id ne '' && &blength($s_id) != $s_length ) ) {
		return(-1);
	}

	#---- Search Session Container ----#
	my( $rtn, $rs ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn == 0 )                                     { return(-3); }
	if( $rs eq '' )                                     { return(-2); }
	#---- 有効期限のチェック ----#
	if( $now > $$rs{'delete_date'} )                    { return(0); }

	return(1);
}

#-----------------------------------------------------------------------------#
#    sub container_get : Get Container Data!!
#-----------------------------------------------------------------------------#
#    input  : (1) DBハンドル
#    input  : (2) セッション名
#    input  : (3) セッションID
#    input  : (4) 有効期限
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:正常,0:有効期限切れ,-1:不正なSession ID,-2:コンテナ不在,-3:異常終了)
#    output : (2) Container Data(Scalar)
#-----------------------------------------------------------------------------#
sub container_get {
	my( $dbh, $s_name, $s_id, $term ) = @_;
	my $now = &now();

	#---- Check Session ----#
	my $chk = &session_check($dbh, $s_name, $s_id);
	if( $chk != 1 )  { return($chk); } # Error

	#---- Get Session Data ----#
	my( $rtn, $data ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn == 0 )    { return(-3); } # Abend
	if( $data eq '' )  { return(-2); } # Not Found

	#---- Set Attribute ----#
	$$data{'last_reference_date'} = $now;

	#---- 有効期限を計算 ----#
	my $s_term = &setTerm($$data{'start_date'}, $$data{'last_reference_date'}, $$data{'last_update_date'}, $term);
	if( $now > $s_term )  { return(0); } # Time is Over.

	$$data{'delete_date'} = $s_term;

	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data, '1', '0');
	if( $s_rtn == -1 )  { return(-3); } # Abend
	if( $s_rtn == 0 )   { return(-2); } # Not Found

	return( 1, $$data{'data_area'} );
}

#-----------------------------------------------------------------------------#
#    sub container_set : Set Container Data
#-----------------------------------------------------------------------------#
#    input  : (1) DBハンドル
#    input  : (2) セッション名
#    input  : (3) セッションID
#    input  : (4) データ(スカラ値)
#    input  : (5) 有効期限
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:OK,0:有効期限切れ,-1:不正なSession ID,-2:Container不在,-3:その他エラー)
#-----------------------------------------------------------------------------#
sub container_set {
	my( $dbh, $s_name, $s_id, $d_area, $term ) = @_;
	my $now = &now();

	#---- Check Session ----#
	my $chk = &session_check($dbh, $s_name, $s_id);
	if( $chk != 1 )  { return($chk); }

	my( $rtn, $data ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn != 1 )    { return(-3); } # Abend
	if( $data eq '' )  { return(-2); } # Not Found

	#---- Set Attribute ----#
	$$data{'last_reference_date'} = $now;
	$$data{'last_update_date'} = $now;
	$$data{'data_code'} = 'utf8';
	$$data{'data_area'} = $d_area;

	#---- 有効期限を計算 ----#
	my $s_term = &setTerm($$data{'start_date'}, $$data{'last_reference_date'}, $$data{'last_update_date'}, $term);
	if( $now > $s_term )  { return(0); } # Time is over.

	$$data{'delete_date'} = $s_term;

	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data, '0', '1');
	if( $s_rtn == -1 )  { return(-3); } # Abend
	if( $s_rtn == 0 )   { return(-2); } # Not Found

	return(1);
}

#-----------------------------------------------------------------------------#
#    sub scalar2hash : Scalar To Hash
#-----------------------------------------------------------------------------#
#    input  : (1) Scalar
#-----------------------------------------------------------------------------#
#    output : (1) Hash
#-----------------------------------------------------------------------------#
sub scalar2hash {
	my( $scalar ) = @_;
	my %hash;

	foreach my $row ( split(/\n/, $scalar ) ) {
		$row =~ /^([^=]*)=([^\n]*)/;
		my ($n, $v) = ($1, $2);
		$v =~ s/\r/\n/g;
		if( $n =~ /^([^\n]*)\[([^\n]*)\]/ ) {         # Array
			$hash{$1}->[$2] = $v;
		} elsif( $n =~ /^([^\n]*)\{([^\n]*)\}/ ) {    # Hash
			$hash{$1}->{$2} = $v;
		} else {
			$hash{$n} = $v;
		}
	}

	return(%hash);
}

#-----------------------------------------------------------------------------#
#    sub hash2scalar : Hash To Scalar
#-----------------------------------------------------------------------------#
#    input  : (1) Hash
#-----------------------------------------------------------------------------#
#    output : (1) Scalar
#-----------------------------------------------------------------------------#
sub hash2scalar {
	my( %hash ) = @_;
	my $scalar;

	while( my( $n, $v ) = each(%hash) ) {
		if( $v =~ /^ARRAY\([^\0]*\)/ ) {
			for( my $i = 0; $i < (@$v); $i ++ ) {
				$v->[$i] =~ s/\r\n/\r/g;
				$v->[$i] =~ s/\n/\r/g;
				$scalar .= "$n\[$i\]=$v->[$i]\n";
			}
		} elsif( $v =~ /^HASH\([^\0]*\)/ ) {
			while( my( $nn, $vv ) = each(%$v) ) {
				$vv =~ s/\r\n/\r/g;
				$vv =~ s/\n/\r/g;
				$scalar .= "$n\{$nn\}=$vv\n";
			}
		} else {
			$v =~ s/\r\n/\r/g;
			$v =~ s/\n/\r/g;
			$scalar .= "$n=$v\n";
		}
	}

	return($scalar);
}

#-----------------------------------------------------------------------------#
#    sub session_change : Change Session ID
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Old Session ID
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:OK,0:有効期限切れ,-1:不正なSession ID,-2:Container不在,-3:Session ID発行エラー,-4:環境整備ミス)
#    output : (2) New Session ID
#-----------------------------------------------------------------------------#
sub session_change {
	my( $dbh, $s_name, $s_id ) = @_;

	my $chk = &session_check($dbh, $s_name, $s_id);
	if( $chk != 1 )  { return($chk); }

	my( $rtn, $data ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn == 0 )    { return(-4); } # Abend
	if( $data eq '' )  { return(-2); } # Not Found

	my $new_s_id = &makeSessionID();
	if( &blength($new_s_id) != $s_length )  { return(-3); }

	$$data{'session_id'} = $new_s_id;

	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data);
	if( $s_rtn == -1 )  { return(-4); } # Abend
	if( $s_rtn == 0 )   { return(-2); } # Not Found

	return( 1, $new_s_id );
}

#-----------------------------------------------------------------------------#
#    sub session_end : Session End
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:OK,0:異常終了,-1:不正なSession ID,-2:Container不在)
#-----------------------------------------------------------------------------#
sub session_end {
	my( $dbh, $s_name, $s_id ) = @_;
	my $now = &now();

	if( &blength($s_id) != $s_length )  { return(-1); }

	my $sql = "delete from $s_name$table_flg ";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &db_access( $dbh, $sql ) || return(0);
	if( $sth->rows == 0 )  { $rtn = -2; }
	else                   { $rtn = 1; }
	$sth->finish;

	return($rtn);
}

#-----------------------------------------------------------------------------#
#    Local Subroutines
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
#    sub getSessionData : Get Session Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) Result(1:OK,0:NG)
#    output : (2) ResultSet
#-----------------------------------------------------------------------------#
sub getSessionData {
	my( $dbh, $s_name, $s_id ) = @_;

	#---- データを取得 ----#
	my $sql = "select " . join(',',@fields) . " from $s_name$table_flg";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &db_access($dbh, $sql) || return(0);
	my $rs = $sth->fetchrow_hashref;
	$sth->finish;

	#---- timestamp値変換→日付 ----#
	if( $rs ) {
		$rs->{'start_date'} = &chg_timestamp($rs->{'start_date'}, 2);
		$rs->{'last_update_date'} = &chg_timestamp($rs->{'last_update_date'}, 2);
		$rs->{'last_reference_date'} = &chg_timestamp($rs->{'last_reference_date'}, 2);
		$rs->{'delete_date'} = &chg_timestamp($rs->{'delete_date'}, 2);
	}

	return(1, $rs);
}

#-----------------------------------------------------------------------------#
#    sub setSessionData : Set Session Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#    input  : (4) Data
#    input  : (5) Get Count Up Flag
#    input  : (6) Set Count Up Flag
#-----------------------------------------------------------------------------#
#    output : (1) Result(1:OK,0:Can't Set,-1:Abend)
#-----------------------------------------------------------------------------#
sub setSessionData {
	my( $dbh, $s_name, $s_id, $data, $g_cnt, $s_cnt ) = @_;

	#---- 日付→timestamp値変換 ----#
	$data->{'start_date'} = &chg_timestamp($data->{'start_date'}, 1);
	$data->{'last_update_date'} = &chg_timestamp($data->{'last_update_date'}, 1);
	$data->{'last_reference_date'} = &chg_timestamp($data->{'last_reference_date'}, 1);
	$data->{'delete_date'} = &chg_timestamp($data->{'delete_date'}, 1);

	#---- データを更新 ----#
	my $sql = "update $s_name$table_flg set ";
	foreach( @fields ) {
		if( $_ eq 'get_cnt' ) {
			if( $g_cnt eq '1' ) {
				$sql .= " $_ = $_ + 1,";
			}
		}
		elsif( $_ eq 'set_cnt' ) {
			if( $s_cnt eq '1' ) {
				$sql .= " $_ = $_ + 1,";
			}
		}
		else {
			$sql .= " $_ = " . $dbh->quote($$data{$_}) . ",";
		}
	}
	chop($sql);
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &db_access($dbh, $sql) || return(-1);
	if( $sth->rows == 0 )  { $rtn = 0; }
	else                   { $rtn = 1; }
	$sth->finish;

	return($rtn);
}

#-----------------------------------------------------------------------------#
#    sub makeSessionID : Make Session ID
#-----------------------------------------------------------------------------#
#    output : (1) Session ID
#-----------------------------------------------------------------------------#
sub makeSessionID {

	my $s_id;
	$s_id .= sprintf("%02d", int(rand(100)));
	$s_id .= sprintf("%02d", int(rand(100)));
	$s_id .= sprintf("%02d", int(rand(100)));
	foreach( split(/\./,$ENV{'SERVER_ADDR'}) ) {
		$s_id .= sprintf("%02x", $_);
	}
	if( $ENV{'UNIQUE_ID'} ne '' &&						# UNIQUE IDが存在し
			length($ENV{'UNIQUE_ID'}) == 19 &&			# 19文字で
			$ENV{'UNIQUE_ID'} =~ /^[\x00-\x7F]+$/ ) {	# 全てASCIIのとき
		$s_id .= $ENV{'UNIQUE_ID'};
	} else { # その他
		$s_id .= sprintf("%011d", time);
		$s_id .= sprintf("%08d", $$);
	}

	return($s_id);
}

#-----------------------------------------------------------------------------#
#    sub setTerm : 指定した有効期限を設定
#-----------------------------------------------------------------------------#
#    input  : (1) Session開始日
#    input  : (2) 最終アクセス日時
#    input  : (3) 最終更新日時
#    input  : (4) 有効期限
#-----------------------------------------------------------------------------#
#    output : (1) 有効期限日時
#-----------------------------------------------------------------------------#
sub setTerm{
	my( $s_date, $a_date, $u_date, $term ) = @_;

	if( $term =~ /^[0-9]{14}$/ ) { # 日付指定
		$term =~ /(....)(..)(..)(..)(..)(..)/;
		if( &Date::Calc::check_date($1, $2, $3) ) {
			if( ( $4 >= 0 && $4 < 24 ) && ( $5 >= 0 && $5 < 60 ) && ( $6 >= 0 && $6 < 60 ) ) {
				return($term);
			}
		}
	} else { # 相対指定
		$term =~ /^(S|L|U)([0-9]*)(D|H|M|S)$/;
		if( $1 ne '' && $3 ne '' ) {
			my $date;
			if( $1 eq 'S' )     { $date = $s_date; }
			elsif( $1 eq 'L' )  { $date = $a_date; }
			elsif( $1 eq 'U' )  { $date = $u_date; }
			my( $dd, $dh, $dm, $ds ) = ( 0, 0, 0, 0 );
			if( $3 eq 'D' )     { $dd = $2; }
			elsif( $3 eq 'H' )  { $dh = $2; }
			elsif( $3 eq 'M' )  { $dm = $2; }
			elsif( $3 eq 'S' )  { $ds = $2; }
			$date =~ /^(....)(..)(..)(..)(..)(..)/;
			my($y, $m, $d, $hh, $mm, $ss ) = &Date::Calc::Add_Delta_DHMS($1, $2, $3, $4, $5, $6, $dd, $dh, $dm, $ds);
			return( sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss) );
		}
	}
}

#-----------------------------------------------------------------------------#
#    sub now : 現時間を取得
#-----------------------------------------------------------------------------#
#    output : (1) 現時間(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub now {
	my( $ss, $mm, $hh, $d, $m, $y, $wd, $yd, $ist ) = localtime(time);

	$y = $y + 1900;
	$m ++;
	my $now = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	return($now);
}

#-----------------------------------------------------------------------------#
#    sub chg_timestamp : 日付←→timestamp値 変換
#-----------------------------------------------------------------------------#
#    input  : (1) 日付(YYYYMMDDhhmmss) or timestamp値
#    input  : (2) 1 = 日付→timestamp値 ／ 2 = timestamp値→日付
#-----------------------------------------------------------------------------#
#    output : (1) timestamp値 or 日付(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub chg_timestamp {
	my( $win, $flg ) = @_;
	my( $ss, $mm, $hh, $d, $m, $y, $wd, $yd, $ist, $wot );

	if( $flg == 1 ) {
		($y,$m,$d,$hh,$mm,$ss) = ( $win =~ /^([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$/ );
		$y -= 1900;
		$m --;
		$wot = timelocal($ss,$mm,$hh,$d,$m,$y);
	} else {
		($ss,$mm,$hh,$d,$m,$y,$wd,$yd,$ist) = localtime($win);
		$y += 1900;
		$m ++;
		$wot = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	}

	return $wot;
}

#-----------------------------------------------------------------------------#
#   db_access : SQL実行
#-----------------------------------------------------------------------------#
#　　input  : (1) DBハンドル
#　　input  : (2) SQL文
#-----------------------------------------------------------------------------#
#　　output : (1) ステートメントハンドル
#-----------------------------------------------------------------------------#
sub db_access {

	my ($dbh, $sql_list) = @_;
	my ($sth);

	if ( !( ( $sth = $dbh->prepare("$sql_list") ) && ( $sth->execute ) ) ){
		return();
	}

	return( $sth );
}

#-----------------------------------------------------------------------------#
#	sub blength : バイト数を返却する
#-----------------------------------------------------------------------------#
#	input  : (1) 文字列
#-----------------------------------------------------------------------------#
#	output : (1) 文字列のバイト数
#-----------------------------------------------------------------------------#
sub blength(){
	my ($str) = @_;
	$str = Encode::encode('utf8', $str);
	return( length($str) );
}

1;
