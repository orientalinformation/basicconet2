package Plack_Env;
#----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  可変環境情報取得 パッケージ
#     Program Name   :  Plack_Env.pl
#     Create Date    :  2013.11.15
#     Programmer     :  msys  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2013 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2013.11.16 (msys) New Create
#-----------------------------------------------------------------------------#
#
#     仕様概要
#             このパッケージは、環境情報ファイルに記述された内容から
#             動作環境に応じた情報を返却します。
#
#     パッケージ使用方法
#
#             [1] 環境情報ファイルから設定情報の取得
#                 &MG_ENV::info_get( *plack_env );
#
#     環境情報ファイル設定方法
#
#             基本的に　環境変数名=データ　の形式で記述する。
#             環境変数名はその影響する範囲毎に下記のように設定する。
#
#          ・特定のプログラムのみに影響
#            PRG-[プログラム名]-[環境変数名]
#            /CGI/member/entry.cgiのみで使用されるメールアドレスの場合
#            PRG-MEMBER-ENTRY-EMAIL=xxx@yyy.co.jp
#
#          ・システム全体に影響
#            SYS-[システム名]-[環境変数名]
#            /CGI/member/　以下全てのプログラムで使用されるメールアドレスの場合
#            SYS-MEMBER-EMAIL=xxx@yyy.co.jp
#
#          ・品目全体に影響
#            [環境変数名]
#            品目全体で使用されるメールアドレスの場合
#            EMAIL=xxx@yyy.co.jp
#
#     注意事項
#             環境変数名に使用できない文字
#              「大文字英数字、アンダーバー以外」
#             データに使用できない文字
#              「=」「#」「SPACE」「TAB」
#
#----------------------------------------------------------------------------#
use utf8;
use strict;
use warnings;
my $version = "1.0.0";
my $library_name = 'Plack_Env.pl';

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#     initial_setting : initial setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	my $server_env = '';
	my $server_root = '/WWW';

    my (@getpwuid, $hinmei);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	# --- 環境修正
	if ( substr($hinmei,3,1) == 1) {                                
		$server_env = 'HONBAN';                                     
	} elsif ( substr($hinmei,3,1) == 2) {                           
		$server_env = 'TEST';                                       
	} else {                                                        
		$server_env = 'DEBUG';                                      
	}

    return($server_env, $server_root);
}

#----------------------------------------------------------------------------#
#     info_get : 環境情報ファイルから設定情報の取得
#----------------------------------------------------------------------------#
#     output : (1) 設定情報
#----------------------------------------------------------------------------#
sub info_get {
    my %plack_env;

	my ($server_env, $server_root) = &initial_setting;

	my (@getpwuid, $hinmei);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	#--- 環境情報ファイルパス ---#
	my $plack_env_file = "$server_root/$hinmei/pubdata/Plack_Env/plack_env.txt";

	if ( -s $plack_env_file ) {
		if ( open(IN,"$plack_env_file") ) {
			binmode(IN, ":utf8");
			while ( <IN> ) {
				chomp;
				if ( $_ !~ /^#/ && length($_) > 0 ) {
					$_ =~ s/#.+$//ig;				# ＃以降削除
					$_ =~ s/\s+$//ig;				# 末尾スペース削除
					my ($n,$v) = split(/=/);
					if ( $n =~ /^DEBUG:/ && $server_env eq "DEBUG" ) {
						$n =~ s/^DEBUG://;			#環境種別削除
						$plack_env{$n} = $v;
					} elsif ( $n =~ /^TEST:/ && $server_env eq "TEST" ) {
						$n =~ s/^TEST://;			#環境種別削除
						$plack_env{$n} = $v;
					} elsif ( $n =~ /^HONBAN:/ && $server_env eq "HONBAN" ) {
						$n =~ s/^HONBAN://;			#環境種別削除
						$plack_env{$n} = $v;
					}
				}
			
           }
			close IN;
		}
	}

	return ( \%plack_env );

}

#----------------------------------------------------------------------------#
#	port_info_get : 環境情報ファイルから設定情報の取得
#----------------------------------------------------------------------------#
#	output  : (1) plack情報        ハッシュリファレンス
#	output  : (2) port情報         ハッシュリファレンス
#	output  : (3) worker情報       ハッシュリファレンス
#	output  : (4) controller情報   ハッシュリファレンス
#----------------------------------------------------------------------------#
sub port_info_get {

	my %c2h;	#Controller to hinmoku
	my %c2p;	#Controller to port
	my %c2w;	#Controller to worker

	# --- 環境情報ファイルパス ---#
	my $server_root = '/WWW';
	my $port_env_file = "$server_root/sfw/linux5/perl5/psgi/port_env.txt";
	my %port_env;

	# --- ポート管理
	if ( -s $port_env_file ) {
		if ( open(IN,"$port_env_file") ) {
			binmode(IN, ":utf8");
			while ( <IN> ) {
				chomp;
				if ( $_ !~ /^#/ && length($_) > 0 ) {
					$_ =~ s/#.+$//ig;				# ＃以降削除
					$_ =~ s/\s+$//ig;				# 末尾スペース削除

					my ($h,$p) = $_ =~ /^(\w+)\t(\w+)/;

					if($port_env{$h}){
						push(@{$port_env{$h}},$p);
					}else{
						my @array = ($p);
						$port_env{$h} = \@array;
					}
				}
			}
			close IN;
		}
	}

	return ( \%port_env );

}

1;
