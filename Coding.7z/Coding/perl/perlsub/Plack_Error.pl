package Plack_Error;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  PSGI エラー制御ライブラリ
#     Program Name   :  PSGI_Error.pl
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2013 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2013.09.16 (m.maezawa) New Created
#-----------------------------------------------------------------------------#
#
#     仕様概要
#             PSGI エラー制御ライブラリ
#
#     動作環境
#             [1] Linux環境専用
#
#  <仕様概要>
#
#     このパッケージはPSGIやバッチプログラムで検出されるエラーの対処を
#     ライブラリ化したものです。すべてのプログラムで必ず利用します。
#     エラーには、プログラムが処理の続行が不可能な場合の「異常終了」があります。
#     「異常終了」の場合には、エラー情報が「監視メール」により専用のサーバ
#     に取り込まれ、監視がされます。
#
#    「異常終了」には、ユーザ画面上に異常画面を表示し、exitする「abend」
#     と、メインに処理を戻し、対応を行うことができる「abend_return」の2種類
#     が用意されています。
#
#     +---------------+-------+------+------------------------------+--------+
#     |   関数        |  PSGI |バッチ| 呼出し後の処理               | 監視ML |
#     +---------------+-------+------+------------------------------+--------+
#     |  abend        |   ○  |  ○  | die処理を行って内部で終了    |   ○   |
#     |  abend_return |   ○  |  ○  | メインに戻る為対応必要       |   ○   |
#     +---------------+-------+------+------------------------------+--------+
#
#     「abend_return」は、エラー情報を監視MLにメールしてメインに
#      処理を戻すので呼出し後の処理を品目プログラムで行う必要があります。
#
#  <パッケージ関数使用方法>
#
#  [1] 異常終了処理１  ( &Plack_Error::abend )
#      プログラムが処理続行不可能なエラーを検出した際に呼び出します。
#      この関数が呼び出されると、エラー内容が監視メールとして送信され、
#      dieします。呼び出し元もしくは.htaccessでエラー制御が必要です。
#
#      &CgiError::abend( 'エラー内容' );
#
#      ※エラー内容は「WEBアプリケーションエラー規約」に基づき指定する。
#
#  [2] 異常終了処理２ ( &Plack_Error::abend_return )
#      上記「abend」と処理は同一だが、強制終了はせず、メインに制御を返します。
#      異常を検出した後、処理をメインで行う必要のあるときに利用します。
#      ※バッチプログラムの場合には必ずこちらの関数を利用します。
#
#      &CgiError::abend_return( 'エラー内容' );
#
#      ※エラー内容は「WEBアプリケーションエラー規約」に基づき指定する。
#-----------------------------------------------------------------------------#
use IO::Handle;
use utf8;
use Unicode::Japanese;
use Encode;

my $version = "1.0.0";
my $library_name = 'Plack_Error.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
		#-----------------------------------------------------------------------------#
#    sub abend : プログラムにて検出された処理続行不能なエラー (dieする）
#-----------------------------------------------------------------------------#
#    input  : (1) エラーメッセージ
#-----------------------------------------------------------------------------#
sub abend(){
	my( @err ) = @_;

	my $s_error  = $?;
	my $p_error  = $!;
	my $error_today = &error_today_get;
	my $error_time  = &error_time_get;

	&error_mailsend( 'Plack_Error','A',
				$error_today,$error_time,$p_error,$s_error,@err );

	
	die &error_rec_get( 'Plack_Error','A',
				$error_today,$error_time,\@err );
}

#-----------------------------------------------------------------------------#
#    sub abend_return : プログラムにて検出された処理続行不能なエラー (return）
#-----------------------------------------------------------------------------#
#    input  : (1) エラーメッセージ
#-----------------------------------------------------------------------------#
sub abend_return(){
	my ( @err ) = @_;

	my $s_error  = $?;
	my $p_error  = $!;

	my $error_today = &error_today_get;
	my $error_time  = &error_time_get;

	&error_mailsend( 'Plack_Error','A',
				$error_today,$error_time,$p_error,$s_error,@err );

	warn &error_rec_get( 'Plack_Error','A',
				$error_today,$error_time,\@err );

	return;
}

#-----------------------------------------------------------------------------#
#    sub error_rec_get : エラーログに表示する内容を返す
#-----------------------------------------------------------------------------#
#    input  : (1) エラータイプ（CgiError or Warning)
#    input  : (2) エラーレベル（CgiErrorは固定でA、ワーニングは可変）
#    input  : (3) 現在の日付（9999/99/99）
#    input  : (4) 現在の時間（99:99:99）
#    input  : (5) 現在のerrnoの値
#    input  : (6) 最後にコマンド実行したものが返したステータス
#    input  : (7) エラーメッセージ
#-----------------------------------------------------------------------------#
#    output : (1) エラーログに表示する内容
#-----------------------------------------------------------------------------#
sub error_rec_get(){
	my ( $type,$level,$today,$time,$err_msg ) = @_;

	my $script_name = '';
	if ( length( $ENV{'SCRIPT_FILENAME'} ) > 0 ){
		$script_name = $ENV{'SCRIPT_FILENAME'};
	}
	else {
		$script_name = $0;
	}

	my $rec = '';
	$rec  = "$type($level): [$today $time]\t";
	$rec .= $script_name;
	$rec .= "\t";
        $rec .= join("\t",@$err_msg);
	$rec .= "\t";

	return( $rec );
}

#-----------------------------------------------------------------------------#
#    sub error_mailsend : エラー内容メール送信
#-----------------------------------------------------------------------------#
#    input  : (1) エラータイプ（'CgiError' or 'Warning')
#    input  : (2) エラーレベル（CgiErrorは固定でA、ワーニングは可変
#    input  : (3) 現在の日付（9999/99/99）
#    input  : (4) 現在の時間（99:99:99）
#    input  : (5) 現在のerrnoの値
#    input  : (6) 最後にコマンド実行したものが返したステータス
#    input  : (7) エラーメッセージ
#-----------------------------------------------------------------------------#
sub error_mailsend(){
	my ( $type,$level,$today,$time,$p_error,$s_error,@error ) = @_;
	my ( $error_to, $conf_file, $mail_str );

	# --- 品目情報取得
	my (@getpwuid, $hinmei, $home_dir);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	my $mail  = '/usr/lib/sendmail';
	$error_to = 'cgi_err@ml.mediagalaxy.ne.jp';

	my $to = '';
	my ( $env_sw ) = &test_server();
	if ( $env_sw == 0 ){ return; }
	else {

		#---- 送信先設定ファイルパス ----#
		$conf_file = "/WWW/$hinmei/data/CgiError/CgiError.conf";
		if( -s $conf_file ) {
			if( open(IN, $conf_file) ) {
				binmode(IN, ":utf8");
				while(<IN>) {
					$_ = s/　/ /g;

					next if substr($_, 0, 1) eq '#';
					s/[\s\r\n]+$//g;
					next if substr($_, 0, 3) ne 'TO=';
					$to = substr($_, 3);
				}
				close IN;
			}
		}
		if( $to eq '' ) { 
			$to = $error_to;
		}
	}

	# ホストドメインとスクリプト名の取得（バッチの場合考慮）
	my $host_name = '';
	if ( length( $ENV{'HTTP_HOST'} ) > 0 ){
		$host_name = $ENV{'HTTP_HOST'};
	}
	else {
		chomp( $host_name = `hostname`);
	}
	my $script_name = '';
	if ( length( $ENV{'SCRIPT_FILENAME'} ) > 0 ){
		$script_name = $ENV{'SCRIPT_FILENAME'};
	}
	else {
		$script_name = $0;
	}

	my  $subject =
		"CgiError [$host_name $script_name $today $time]";

	if ( open (MMM,"\| $mail -f $error_to -t -oi") ){
		print MMM "Mime-Version: 1.0\n";
		print MMM "Content-type: text/plain; charset=\"ISO-2022-JP\"\n";
		print MMM "To: $to\n";
		print MMM "Subject: ".$subject."\n";

		print MMM "X-ERROR-TYPE: $type\n";
		print MMM "X-ERROR-LEVEL: $level\n";
		print MMM "X-ERROR-SERVER: $host_name\n";
		my $dir_name = $hinmei;
		print MMM "X-ERROR-DIR_NAME: $dir_name\n";
		print MMM "X-ERROR-PATH: $script_name\n";
		print MMM "X-ERROR-DATE: $today\n";
		print MMM "X-ERROR-TIME: $time\n";
		print MMM "\n";
		$mail_str .= join('',
						  "-" x 78,"\n","\t$subject\n",
						  "-" x 78,"\n\n" );
		foreach my $err(@error){
			$mail_str .= "\t$err\n";
		}
		$mail_str .= join('',
						  "\n","-" x 78,"\n","\tPerl ENV\n",
						  "-" x 78,"\n\n" );
		$mail_str .= "\t\$\!=$p_error\n";
		$mail_str .= "\t\$\?=$s_error\n";
		$mail_str .= join('',
						  "\n","-" x 78,"\n","\tENVROMENT\n",
						  "-" x 78,"\n\n");
		while( my ($a,$b) = each %ENV ){
			$mail_str .= "\t$a : $b\n";
		}
		$mail_str .= join('',
						  "\n","-" x 78,"\n",
						  "\tDISK LIST\n","-" x 78,"\n\n" );
		my $df = `/bin/df -k`;
		$mail_str .= "$df\n";
		$mail_str .= join('',
						  "\n","-"x 78,"\n","\tUPTIME LIST\n",
						  "-" x 78,"\n\n" );

		my $up = '';
		if( -s "/bin/uptime" )             { $up = `/bin/uptime`; }
		elsif( -s "/usr/bin/uptime" )      { $up = `/usr/bin/uptime`; }
		elsif( -s "/usr/local/bin/uptime" ){ $up = `/usr/local/bin/uptime`; }
		else {
			my $uptime_path = `which uptime`;
			if( -s $uptime_path ){ $up = `$uptime_path`; }
		}

		$mail_str .= "$up\n";
		$mail_str .= join('',
						  "\n", "-" x 78, "\n",
						  "\tSTDIN DATA\n", "-" x 78, "\n\n" );
		my $stdin = '';
		read(STDIN,$stdin,$ENV{'CONTENT_LENGTH'});
		$mail_str .= "$stdin\n";
		$mail_str = Unicode::Japanese->new($mail_str,'utf8')->jis;

		print MMM $mail_str;

		close MMM;
	}
}

#-----------------------------------------------------------------------------#
#    sub error_today_get : エラーサブルーチン専用日付返却サブルーチン
#-----------------------------------------------------------------------------#
#    output : (1) 現在の日付（9999/99/99）
#-----------------------------------------------------------------------------#
sub error_today_get(){
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

	$mon++;
	$mday = "0$mday" if ($mday < 10);
	$mon  = "0$mon" if ($mon < 10);
	$year += 1900;

	return( "$year/$mon/$mday" );
}

#-----------------------------------------------------------------------------#
#    sub error_time_get : エラーサブルーチン専用時間返却サブルーチン
#-----------------------------------------------------------------------------#
#    output : (1) 現在の時間（99:99:99）
#-----------------------------------------------------------------------------#
sub error_time_get(){
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

	$hour = "0$hour" if ($hour < 10);
	$min  = "0$min"  if ($min  < 10);
	$sec  = "0$sec"  if ($sec  < 10);

	return( "$hour:$min:$sec");
}

#-----------------------------------------------------------------------------#
#    sub test_server: テストサーバの見分け
#-----------------------------------------------------------------------------#
#    output : (1) 開発 or 検証 … 0 ／ 本番 … 1
#    output : (2) 品目ディレクトリ
#-----------------------------------------------------------------------------#
sub test_server {

	# --- 品目情報取得
	my (@getpwuid, $hinmei, $home_dir);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	#----- 環境の把握 --------------------------------------------------------#
	my $env_sw = 1;   # デフォルト本番環境

	# 検証環境
	if ( substr($hinmei,3,1) == 2) {
		$env_sw = 0;
	# 開発環境
	}elsif ( substr($hinmei,3,1) == 3) {
		$env_sw = 0;
	}
	return( $env_sw );
}

1;
