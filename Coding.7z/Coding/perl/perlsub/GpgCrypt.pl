package GpgCrypt;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  GPG暗号ライブラリ
#     Program Name   :  GpgCrypt.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#-----------------------------------------------------------------------------#
#
#  仕様概要
#
#      このパッケージは、指定された文字列に対してGPGで暗号化を行います。
#
#  [1] &GpgCrypt::encrypt_str2str
#
#      文字列をGPG暗号化して文字列で出力する。
#      $rtn = &GpgCrypt::encrypt_str2str( $gpgpath, $gnupghome, $userid, $moji, $tmpdir );
#
#      $pgpath..........GPGパス（絶対パス）
#      $gnupghome.......鍵束格納ディレクトリ（絶対パス）
#      $userid..........ユーザーID
#      $moji............暗号化対象文字列
#      $tmpdir..........テンポラリディレクトリパス
#      $rtn.............暗号化された文字列（失敗の場合はnull）
#
#  [2] &GpgCrypt::encrypt_str2file
#
#      文字列をGPG暗号化してファイルへ出力する。
#      $rtn = &GpgCrypt::encrypt_str2file( $gpgpath, $gnupghome, $userid, $moji, $tmpdir, $otfile );
#
#      $pgpath..........GPGパス（絶対パス）
#      $gnupghome.......鍵束格納ディレクトリ（絶対パス）
#      $userid..........ユーザーID
#      $moji............暗号化対象文字列
#      $tmpdir..........テンポラリディレクトリパス
#      $otfile..........出力先ファイルパス（上書）
#      $rtn.............暗号化されたファイルパス（失敗の場合はnull）
#
#  [3] &GpgCrypt::encrypt_file2str
#
#      ファイルをGPG暗号化して文字列で出力する。
#      $rtn = &GpgCrypt::encrypt_file2str( $gpgpath, $gnupghome, $userid, $infile, $tmpdir );
#
#      $pgpath..........GPGパス（絶対パス）
#      $gnupghome.......鍵束格納ディレクトリ（絶対パス）
#      $userid..........ユーザーID
#      $infile..........暗号化対象ファイルパス
#      $tmpdir..........テンポラリディレクトリパス
#      $rtn.............暗号化された文字列（失敗の場合はnull）
#
#  [4] &GpgCrypt::encrypt_file2file
#
#      ファイルをGPG暗号化してファイルへ出力する。
#      $rtn = &GpgCrypt::encrypt_file2file( $gpgpath, $gnupghome, $userid, $infile, $otfile );
#
#      $pgpath..........GPGパス（絶対パス）
#      $gnupghome.......鍵束格納ディレクトリ（絶対パス）
#      $userid..........ユーザーID
#      $infile..........暗号化対象ファイルパス
#      $otfile..........出力先ファイルパス（上書）
#      $rtn.............暗号化されたファイルパス（失敗の場合はnull）
#
#-----------------------------------------------------------------------------#
use utf8;
use Encode;

&init unless defined $GpgCrypt_ver;

#-----------------------------------------------------------------------------#
#    sub init : 初期設定
#-----------------------------------------------------------------------------#
#    input  : なし
#-----------------------------------------------------------------------------#
#    output : なし
#-----------------------------------------------------------------------------#
sub init {
	$GpgCrypt_ver = '1.0.0';
}

#-----------------------------------------------------------------------------#
#    sub encrypt_str2str : 文字列をGPG暗号化して文字列で出力する。
#-----------------------------------------------------------------------------#
#    input  : (1) GPGパス（絶対パス）
#    input  : (2) 鍵束格納ディレクトリ（絶対パス）
#    input  : (3) ユーザーID
#    input  : (4) 暗号化対象文字列
#    input  : (5) テンポラリディレクトリパス
#-----------------------------------------------------------------------------#
#    output : (1) 暗号化された文字列（失敗の場合はnull）
#-----------------------------------------------------------------------------#
sub encrypt_str2str {
	my( $gpgpath, $gnupghome, $userid, $moji, $tmpdir ) = @_;
	my( $gpgfile, $rtn );

	#----- パラメータチェック -----#
	if( $gpgpath eq '' || $gnupghome eq '' || $userid eq ''
		|| $moji eq '' || $tmpdir eq '') {
		return();
	}

	unless( -d $tmpdir )  { return(); }


	#----- テンポラリファイル作成 -----#
	if( substr($tmpdir, -1, 1) ne '/' )  { $tmpdir .= '/'; }

	srand;
	$i = int( rand( 1000000 ) );
	$tmpdir .= &gpg_today_get() . &gpg_time_get() . $i;
	$tmpdir =~ s/[^\w-_\.\/]//g;
	$tmpdir =~ s/\.\.+//g;

	$gpgfile = $tmpdir . '.gpg';

	#----- データを一時テンポラリへ出力 -----#
	unless( &gpg_sopen(OTF, '>', $tmpdir) ) {
		return();
	}
	$moji = Encode::encode('utf8', $moji);
	print OTF $moji;
	close OTF;

	#----- データを暗号化 -----#
	&gpg_ssystem($gpgpath, '-ear', $userid, '-o', $gpgfile, $tmpdir);

	#----- 暗号化したデータ取得 -----#
	unless( &gpg_sopen(INF, '<', $gpgfile) ) {
		return();
	}
	while(<INF>) {
		$rtn .= $_;
	}
	close INF;

	#----- テンポラリファイル削除 -----#
	unlink( $tmpdir ) if ( -e $tmpdir );
	unlink( $gpgfile ) if ( -e $gpgfile );

	$rtn = Encode::decode('utf8', $rtn);
	return( $rtn );
}

#-----------------------------------------------------------------------------#
#    sub encrypt_str2file : 文字列をGPG暗号化してファイルへ出力する。
#-----------------------------------------------------------------------------#
#    input  : (1) GPGパス（絶対パス）
#    input  : (2) 鍵束格納ディレクトリ（絶対パス）
#    input  : (3) ユーザーID
#    input  : (4) 暗号化対象文字列
#    input  : (5) テンポラリディレクトリパス
#    input  : (6) 出力先ファイルパス（上書）
#-----------------------------------------------------------------------------#
#    output : (1) 暗号化されたファイルパス（失敗の場合はnull）
#-----------------------------------------------------------------------------#
sub encrypt_str2file {
	my( $gpgpath, $gnupghome, $userid, $moji, $tmpdir, $otfile ) = @_;
	my( $rtn );

	#----- パラメータチェック -----#
	if( $gpgpath eq '' || $gnupghome eq '' || $userid eq ''
		|| $moji eq '' || $tmpdir eq '' || $otfile eq '') {
		return();
	}

	unless( -d $tmpdir )  { return(); }


	#----- テンポラリファイル作成 -----#
	if( substr($tmpdir, -1, 1) ne '/' )  { $tmpdir .= '/'; }

	srand;
	$i = int( rand( 1000000 ) );
	$tmpdir .= &gpg_today_get() . &gpg_time_get() . $i;
	$tmpdir =~ s/[^\w-_\.\/]//g;
	$tmpdir =~ s/\.\.+//g;

	#----- データを一時テンポラリへ出力 -----#
	unless( &gpg_sopen(OTF, '>', $tmpdir) ) {
		return();
	}
	$moji = Encode::encode('utf8', $moji);
	print OTF $moji;
	close OTF;

	#----- データを暗号化 -----#
	&gpg_ssystem($gpgpath, '-ear', $userid, '-o', $otfile, $tmpdir);

	#----- テンポラリファイル削除 -----#
	unlink( $tmpdir ) if ( -e $tmpdir );

	$otfile = Encode::decode('utf8', $otfile);
	return( $otfile );
}

#-----------------------------------------------------------------------------#
#    sub encrypt_file2str : ファイルをGPG暗号化して文字列で出力する。
#-----------------------------------------------------------------------------#
#    input  : (1) GPGパス（絶対パス）
#    input  : (2) 鍵束格納ディレクトリ（絶対パス）
#    input  : (3) ユーザーID
#    input  : (4) 暗号化対象ファイルパス
#    input  : (5) テンポラリディレクトリパス
#-----------------------------------------------------------------------------#
#    output : (1) 暗号化された文字列（失敗の場合はnull）
#-----------------------------------------------------------------------------#
sub encrypt_file2str {
	my( $gpgpath, $gnupghome, $userid, $infile, $tmpdir ) = @_;
	my( $moji, $rtn );

	#----- パラメータチェック -----#
	if( $gpgpath eq '' || $gnupghome eq '' || $userid eq ''
		|| $infile eq '' || $tmpdir eq '') {
		return();
	}

	unless( -s $infile )  { return(); }
	unless( -d $tmpdir )  { return(); }


	#----- テンポラリファイル作成 -----#
	if( substr($tmpdir, -1, 1) ne '/' )  { $tmpdir .= '/'; }

	srand;
	$i = int( rand( 1000000 ) );
	$tmpdir .= &gpg_today_get() . &gpg_time_get() . $i . '.gpg';
	$tmpdir =~ s/[^\w-_\.\/]//g;
	$tmpdir =~ s/\.\.+//g;

	#----- データを暗号化 -----#
	&gpg_ssystem($gpgpath, '-ear', $userid, '-o', $tmpdir, $infile);

	#----- 暗号化したデータ取得 -----#
	unless( &gpg_sopen(INF, '<', $tmpdir) ) {
		return();
	}
	while(<INF>) {
		$rtn .= $_;
	}
	close INF;

	#----- テンポラリファイル削除 -----#
	unlink( $tmpdir ) if ( -e $tmpdir );

	$rtn = Encode::decode('utf8', $rtn);
	return( $rtn );
}

#-----------------------------------------------------------------------------#
#    sub encrypt_file2file : ファイルをGPG暗号化してファイルへ出力する。
#-----------------------------------------------------------------------------#
#    input  : (1) GPGパス（絶対パス）
#    input  : (2) 鍵束格納ディレクトリ（絶対パス）
#    input  : (3) ユーザーID
#    input  : (4) 暗号化対象ファイルパス
#    input  : (5) 出力先ファイルパス（上書）
#-----------------------------------------------------------------------------#
#    output : (1) 暗号化されたファイルパス（失敗の場合はnull）
#-----------------------------------------------------------------------------#
sub encrypt_file2file {
	my( $gpgpath, $gnupghome, $userid, $infile, $otfile ) = @_;
	my( $moji, $rtn );

	#----- パラメータチェック -----#
	if( $gpgpath eq '' || $gnupghome eq '' || $userid eq ''
		|| $infile eq '' || $otfile eq '') {
		return();
	}

	unless( -s $infile )  { return(); }


	#----- データを暗号化 -----#
	&gpg_ssystem($gpgpath, '-ear', $userid, '-o', $otfile, $infile);

	$otfile = Encode::decode('utf8', $otfile);
	return( $otfile );
}

#-----------------------------------------------------------------------------#
#    sub gpg_today_get : GPG暗号ライブラリ専用日付返却サブルーチン
#-----------------------------------------------------------------------------#
#    input  : なし
#-----------------------------------------------------------------------------#
#    output : (1) 年月日（8桁）
#-----------------------------------------------------------------------------#
sub gpg_today_get {
	my( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst )
		= localtime(time);

	$mon++;
	$mday = "0$mday" if ($mday < 10);
	$mon  = "0$mon" if ($mon < 10);
	$year += 1900;

	return( "$year$mon$mday" );
}

#-----------------------------------------------------------------------------#
#    sub gpg_time_get : GPG暗号ライブラリ専用時間返却サブルーチン
#-----------------------------------------------------------------------------#
#    input  : なし
#-----------------------------------------------------------------------------#
#    output : (1) 時分秒（6桁）
#-----------------------------------------------------------------------------#
sub gpg_time_get {
	my( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst )
		= localtime(time);

	$hour = "0$hour" if ($hour < 10);
	$min  = "0$min"  if ($min  < 10);
	$sec  = "0$sec"  if ($sec  < 10);

	return( "$hour$min$sec");
}

#-----------------------------------------------------------------------------#
#    sub gpg_sopen : GPG暗号ライブラリ専用セキュリティ保護機能実装ファイルOPEN
#-----------------------------------------------------------------------------#
#    input  : (1) ファイルハンドル
#    input  : (2) 入出力リダイレクト（ <,>,>>,| ）
#    input  : (3) 対象ファイル名
#    input  : (4) パイプコマンド( 1..n : 順番に起動する）
#-----------------------------------------------------------------------------#
#    output : (1) リターンコード( 1:正常,0:異常終了 ）
#-----------------------------------------------------------------------------#
sub gpg_sopen {
	my( $fhd, $io, $in_file, @in_com ) = @_;
	my( $file, $com, @com, $wk, $rtn );

	$file = &gpg_path( $in_file ); 
	foreach $com(@in_com){ push( @com,&gpg_meta($com) ); }
	undef $wk;
	undef $rtn; 
	if ( $io eq '<' ){
		if ( @com ){
			$com = shift( @com ); 
			$wk .= "$com $file |";
			foreach $com( @com ){ $wk .= "$com |"; }
		}
		else { $wk .= "$file"; }
	}
	elsif ( $io eq '>' || $io eq '>>' ){
		if ( @com ){
			foreach $com( @com ){ $wk .= "| $com "; }
			$wk .= "$io $file";
		}
		else { $wk .= "$io $file"; }
	}
	elsif ( $io eq '|' ){
		$com = shift( @com ); 
		$wk .= "| $com";
		if ( @com ){
			foreach $com( @com ){ $wk .= " | $com"; }
		}
	}
	if ( $wk ){ $rtn = open( $fhd,$wk ); }

	return( $rtn ); 
}

#-----------------------------------------------------------------------------#
#    sub gpg_meta : GPG暗号ライブラリ専用データ中から危険なメタ文字を削除
#-----------------------------------------------------------------------------#
#    input  : (1) 変換前文字列
#-----------------------------------------------------------------------------#
#    output : (1) 変換後文字列
#-----------------------------------------------------------------------------#
sub gpg_meta {
	my( $in ) = shift; 
     
	$in =~ s/([;<>\*\|&\$!#\(\)\[\]\{\}:'"])//g;
	return( $in );
}

#-----------------------------------------------------------------------------#
#    sub gpg_path : GPG暗号ライブラリ専用ファイルパスとして使用可能な文字列以外の文字列を削除する
#-----------------------------------------------------------------------------#
#    input  : (1) 変換前文字列
#-----------------------------------------------------------------------------#
#    output : (1) 変換後文字列
#-----------------------------------------------------------------------------#
sub gpg_path {
	my( $in ) = shift; 
    
	$in =~ s/[^\w-_\.\/]//g;
	$in =~ s/\.\.+//g;
	return( $in ); 
}

#------------------------------------------------------------------------------
#   ssystem : セキュリティ保護機能実装 コマンド起動 ( system )
#------------------------------------------------------------------------------
sub gpg_ssystem () {
	my( @in_com ) = @_;
	my( $com, @com );

	foreach $com (@in_com) {
		if ( $com eq '|' || $com eq '<' || $com eq '>' || $com eq '>>'
			 || $com eq ';' || $com eq '*' || $com eq '?' ) {
			push( @com,$com );
		}
		else { push( @com, &gpg_meta($com) ); }
	}
	$com = join(' ',@com);

	return ( system( $com ) );
}
