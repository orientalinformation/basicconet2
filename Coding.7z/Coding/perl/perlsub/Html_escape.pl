package Html_escape;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  タグ変換（サニタイジング）
#     Program Name   :  Html_escape.pl
#     Create Date    :  2010.11.11
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ Html_escape.pl version 1.0.0 を
#                       UTF-8 にしてリニューアル新規作成
#-----------------------------------------------------------------------------#
#
#     仕様概要
#             データ中の " ' < > & をサニタイジング（無毒化）を行う。
#             また、逆変換も行う。
#
#     パッケージ使用方法
#
#             [1] 文字列変換
#                 $rtn = &Html_escape::string_change( $scala ); 
#
#             [2] ハッシュ変換
#                 &Html_escape::hash_change( \%in ); 
#
#             [3] 文字列逆変換
#                 $rtn = &Html_escape::string_return( $scala ); 
#
#             [4] ハッシュ逆変換
#                 &Html_escape::hash_return( \%in ); 
#
#     返り値の説明
#             %in  -> nameをkeyとした連想配列
#
#     サニタイジング（無毒化）
#             & -> &amp;
#             " -> &quot;
#             ' -> &#39;
#             < -> &lt;
#             > -> &gt;
#
#     逆変換
#             &quot; -> "
#             &#39;  -> '
#             &lt;   -> <
#             &gt;   -> >
#             &amp;  -> &
#
#----------------------------------------------------------------------------#
use utf8;
use strict;

my $version = "1.0.0";
my $library_name = 'Html_escape.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#----------------------------------------------------------------------------#
#     string_change : 文字列変換
#----------------------------------------------------------------------------#
sub string_change {

	my ( $d ) = @_ ; 

	$d =~ s/&/&amp;/g ;
	$d =~ s/"/&quot;/g ;
	$d =~ s/'/&#39;/g ;
	$d =~ s/</&lt;/g ;
	$d =~ s/>/&gt;/g ;

	#--- IEの&nbsp;（半角スペース）未変換バグ対応 ---------------------------#
	$d =~ s/&amp;nbsp;/ /g ;

	return( $d ); 

}

#----------------------------------------------------------------------------#
#     string_return : 文字列逆変換
#----------------------------------------------------------------------------#
sub string_return {

	my ( $d ) = @_ ; 

	$d =~ s/&quot;/"/g ;
	$d =~ s/&#39;/'/g ;
	$d =~ s/&lt;/</g ;
	$d =~ s/&gt;/>/g ;
	$d =~ s/&amp;/&/g ;

	return( $d ); 

}

#----------------------------------------------------------------------------#
#     hash_change : ハッシュ変換
#----------------------------------------------------------------------------#
sub hash_change { 
	my ( $in ) = @_; 
	my ( $n,$v ); 

	my %image_name;
	my %image_type;
	my @keys = sort keys %$in;
	foreach my $n ( @keys ) {
		if ( defined $in->{$n.'_name'} && defined $in->{$n.'_type'} ) {
			$image_name{$n.'_name'} = $n;
			$image_type{$n.'_type'} = $n;
		} elsif ( $image_name{$n} ne '' && $in->{$n} ) {
		} elsif ( $image_type{$n} ne '' && $in->{$n} ) {
		} else {
			$v = &string_change( $in->{$n} );
			$in->{$n} = $v;
		}
	}

}

#----------------------------------------------------------------------------#
#     hash_return : ハッシュ逆変換
#----------------------------------------------------------------------------#
sub hash_return { 
	my ( $in ) = @_; 
	my ( $n,$v ); 

	my %image_name;
	my %image_type;
	my @keys = sort keys %$in;
	foreach my $n ( @keys ) {
		if ( defined $in->{$n.'_name'} && defined $in->{$n.'_type'} ) {
			$image_name{$n.'_name'} = $n;
			$image_type{$n.'_type'} = $n;
		} elsif ( $image_name{$n} ne '' && $in->{$n} ) {
		} elsif ( $image_type{$n} ne '' && $in->{$n} ) {
		} else {
			$v = &string_return( $in->{$n} );
			$in->{$n} = $v;
		}
	}

}

1;
