package Session_control;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  セッションコンテナ制御ライブラリ
#     Program Name   :  Session_control.pl
#     Create Date    :  2010.11.11
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#     comment        :  セッションコンテナ制御ライブラリ
#                       セッション管理手法については共有文書をご参照ください。
#                       PHPのライブラリと完全互換しています。
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ Session_control.pl version 1.2.0を元に
#                       リニューアル新規作成
#-----------------------------------------------------------------------------#
# [1] session_start : セッションスタート
#
#  my ($code,$s_id) = &Session_control::session_start($s_name,$term[,$rand]);
#  ※注意  ディレクトリは自動作成しますが、基本ディレクトリは作成しませんので
#          あらかじめ用意しておいてください。基本ディレクトリは、
#          /WWW/[品目ディレクトリ]/pubdata/MG_Session/V1/ になります。
#          ※パーミッションは必ず 705 にすること。
#
# [Input]
#     $s_name....セッションName
#     $term......有効期限
#     $rand......ランダム値（省略時50）
# [Output]
#     $code......コード(1:正常,0:異常終了,-1:有効期限指定エラー,-2:SessionID発行エラー)
#     $s_id......セッションID
#-----------------------------------------------------------------------------#
# [2] session_check : セッションチェック
#
#  my $rtn = &Session_control::session_check($s_name,$s_id);
#
# [Input]
#     $s_name....セッション名
#     $s_id......セッションID
# [Output]
#     $rtn.......コード(1:正常,0:有効期限切れ,-1:不正なセッションID,-2:コンテナ不在)
#-----------------------------------------------------------------------------#
# [3] container_get : コンテナからのデータ取得
#
#  my ($rtn,$data) = &Session_control::container_get($s_name,$s_id,$term);
#
# [Input]
#     $s_name....セッション名
#     $s_id......セッションID
#     $term......有効期限
# [Output]
#     $rtn.......コード(1:正常,0:有効期限切れ,-1:不正なセッションID,-2:コンテナ不在)
#     $data......コンテナデータ(スカラ値)
#-----------------------------------------------------------------------------#
# [4] container_set : コンテナデータの設定
#
#  my $rtn = &Session_control::container_set($s_name,$s_id,$data,$term);
#
# [Input]
#     $s_name....セッション名
#     $s_id......セッションID
#     $data......データ(スカラ値)
#     $term......有効期限(省略可)
# [Output]
#     $rtn.......コード(1:正常,0:有効期限切れ,-1:不正なセッションID,-2:コンテナ不在)
#-----------------------------------------------------------------------------#
# [5] scalar2hash : スカラ値をハッシュに変換
#
#  my %hash = &Session_control::scalar2hash($scalar);
#
# [Input]
#     $scalar....スカラー値
# [Output]
#     %hash......ハッシュ値
#-----------------------------------------------------------------------------#
# [6] hash2scalar : ハッシュをスカラ値に変換
#
#  my $scalar = &Session_control::hash2scalar(%hash);
#
# [Input]
#     %hash......ハッシュ値
# [Output]
#     $scalar....スカラー値
#-----------------------------------------------------------------------------#
# [7] session_change : Session ID変更
#
#  my ($rtn,$new_s_id) = &Session_control::session_change($s_name,$s_id[,$rand]);
#
# [Input]
#     $s_name....セッション名
#     $s_id......セッションID
#     $rand......ランダム値（省略時50）
# [Output]
#     $rtn.......結果(1:OK,0:有効期限切れ:,-1:不正なセッションID,-2:Container不在,-3:Session ID発行エラー)
#     $new_s_id..変更後セッションID
#-----------------------------------------------------------------------------#
# [8] session_end : Session 終了
#
#  my ($rtn) = &Session_control::session_end($s_name,$s_id);
#
# [Input]
#     $s_name....セッション名
#     $s_id......セッションID
# [Output]
#     $rtn.......結果(1:OK,0:異常終了,-1:不正なセッションID,-2:Container不在)
#-----------------------------------------------------------------------------#

use utf8;
use Encode;
use Date::Calc qw( check_date Add_Delta_DHMS );
use Time::Local;

my $version = "1.0.0";
my $library_name = 'Session_control.pl';

&initial_setting();

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#    sub initial_setting : Initial Setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	#---- XSS対策 ----#
	my @env = qw(
				 SCRIPT_FILENAME HTTP_USER_AGENT HTTP_X_JPHONE_COLOR
				 HTTP_X_UP_SUBNO REMOTE_ADDR SERVER_ADDR UNIQUE_ID
				);

	foreach ( @env ) {
		$ENV{$_} =~ s/\</\&lt\;/g;
		$ENV{$_} =~ s/\>/\&gt\;/g;
		$ENV{$_} =~ s/\"/\&quot\;/g;
		$ENV{$_} =~ s/\'/\&\#39\;/g;
	}

	my $server_root = '/WWW';
	my @getpwuid = getpwuid($>);
	my $hinmei = $getpwuid[0];

	if($hinmei ne ''){
		$hin_dir = $hinmei;
	} else {
		print "Content-type:text/plain;charset=UTF-8\n\n";
		print Encode::encode('utf8', "Can't execute Session_control.pl!!\n");
		exit;
	}

	$s_length = 33; # Session ID's Length

	$con_dir = "$server_root/$hin_dir/pubdata/MG_Session/V1/";

	@fields = qw(
		start_date last_reference_date last_update_date delete_date
		get_cnt set_cnt data_code remote_addr user_agent data_area
	); # Container's Data Fields

	$default_rand = 50;
	$max_rand     = 100;

	#---- Check carrier ----#
	$carrier = 'WWW';
	if( $ENV{'HTTP_USER_AGENT'} =~ /^DoCoMo/ ) {
		$carrier = 'IMODE';
	}elsif($ENV{HTTP_USER_AGENT} =~ /^J-PHONE/
		   || $ENV{HTTP_USER_AGENT} =~ /^Vodafone/
		   || $ENV{HTTP_USER_AGENT} =~ /^MOT-/
		   || $ENV{HTTP_USER_AGENT} =~ /^SoftBank/
		  ){
		$carrier = 'SKY';
	}elsif($ENV{HTTP_USER_AGENT} =~ /^UP\.Browser/
		   || $ENV{HTTP_USER_AGENT} =~ /^KDDI-/){
		$carrier = 'WAP';
	}

	#---- 乱数の種を作成 ----#
	srand(time ^ ($$ + ($$ << 15)));
}

#-----------------------------------------------------------------------------#
#    sub session_start : セッション管理スタート
#-----------------------------------------------------------------------------#
#    input  : (1) セッションName
#    input  : (2) 有効期限
#    input  : (3) ランダム値
#-----------------------------------------------------------------------------#
#    output : (1) コード(1:正常,0:異常終了,-1:有効期限指定エラー,-2:SessionID発行エラー)
#    output : (2) SessionID
#-----------------------------------------------------------------------------#
sub session_start {
	my ($s_name, $term, $rand) = @_;
	my $now = &now();

	#---- Check item ----#
	#-- Session Name --#
	if( $s_name eq '' )  { return(0); }

	#-- Term --#
	my $s_term = &setTerm($now, $now, $now, $term);
	if( $now > $s_term )  { return(-1); }
	
	#-- Make Session ID & Check --#
	my $s_id = &makeSessionID($s_name, $rand);
	if( &blength($s_id) != $s_length )  { return(-2); }

	#---- Make Container File ----#
	#-- Set Attribute --#
	my %c;
	$c{'start_date'} = $now;
	$c{'last_reference_date'} = $now;
	$c{'last_update_date'} = $now;
	$c{'delete_date'} = $s_term;
	$c{'get_cnt'} = '0';
	$c{'set_cnt'} = '0';
	$c{'data_code'} = 'utf8';
	$c{'remote_addr'} = $ENV{'REMOTE_ADDR'};
	$c{'user_agent'} = $ENV{'HTTP_USER_AGENT'};
	$c{'carrier'} = $carrier;
	$c{'data_area'} = '';

	&setSessionData($s_name, $s_id, \%c) || return(0);

	return(1, $s_id);
}

#-----------------------------------------------------------------------------#
#    sub session_check : セッションチェック
#-----------------------------------------------------------------------------#
#    input  : (1) SessionName
#    input  : (2) SessionID
#-----------------------------------------------------------------------------#
#    output : (1) コード(1:正常,0:有効期限切れ,-1:不正なセッションID,-2:コンテナ不在)
#-----------------------------------------------------------------------------#
sub session_check {
	my ($s_name, $s_id) = @_;
	my $now = &now();

	#---- Check Session ID ----#
	if( $s_id eq '' || ( $s_id ne '' && &blength($s_id) != $s_length ) ) {
		return(-1);
	}

	#---- Search For Session Container ----#
	my $data = &getSessionData($s_name, $s_id);
	if( $data eq '' )                                     { return(-2); }
	#---- 有効期限のチェック ----#
	if( $now > $$data{'delete_date'} )                    { return(0); }

	return(1);
}

#-----------------------------------------------------------------------------#
#    sub container_get : コンテナからのデータ取得
#-----------------------------------------------------------------------------#
#    input  : (1) Session Name
#    input  : (2) Session ID
#    input  : (3) 有効期限
#-----------------------------------------------------------------------------#
#    output : (1) コード(1:正常,0:有効期限切れ,-1:不正なセッションID,-2:コンテナ不在)
#    output : (2) コンテナデータ(スカラ値)
#-----------------------------------------------------------------------------#
sub container_get {
	my ($s_name, $s_id, $term) = @_;
	my $rtn;
	my $now = &now();

	#---- Check Session ----#
	my $chk = &session_check($s_name, $s_id);
	if( $chk != 1 )  { return($chk); }
	
	#---- Get Session Data ----#
	my $data = &getSessionData($s_name, $s_id);
	if( $data eq '' )  { return(-2); } # Not Found

	#-- Set Attribute --#
	$$data{'get_cnt'} ++;
	$$data{'last_reference_date'} = $now;

	#---- 有効期限を計算 ----#
	my $s_term = &setTerm($$data{'start_date'}, $$data{'last_reference_date'}, $$data{'last_update_date'}, $term);
	if( $now > $s_term )  { return(0); } # Time is Over.

	$$data{'delete_date'} = $s_term;

	&setSessionData($s_name, $s_id, $data) || return(-2);

	return(1, $$data{'data_area'});
}

#-----------------------------------------------------------------------------#
#    sub container_set : コンテナデータの設定
#-----------------------------------------------------------------------------#
#    input  : (1) Session Name
#    input  : (2) Session ID
#    input  : (3) データ(スカラ値)
#    input  : (4) 有効期限
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:正常,0:有効期限切れ,-1:不正なセッションID,-2:コンテナ不在)
#-----------------------------------------------------------------------------#
sub container_set {
	my ($s_name, $s_id, $data, $term) = @_;
	my $rtn;
	my $now = &now();

	#-- Check Session --#
	my $chk = &session_check($s_name, $s_id);
	if( $chk != 1 )  { return($chk); }
	
	#-- Get Session Data --#
	my $ref = &getSessionData($s_name, $s_id);
	if( $ref eq '' )  { return(-2); } # Not Found

	#-- Set Attribute --#
	$$ref{'set_cnt'} ++;
	$$ref{'last_reference_date'} = $now;
	$$ref{'last_update_date'} = $now;
	$$ref{'data_code'} = 'utf8';
	$$ref{'data_area'} = $data;

	#---- 有効期限を計算 ----#
	my $s_term = &setTerm($$ref{'start_date'}, $$ref{'last_reference_date'}, $$ref{'last_update_date'}, $term);
	if( $now > $s_term )  { return(0); } # Time is over.

	$$ref{'delete_date'} = $s_term;

	&setSessionData($s_name, $s_id, $ref) || return(-2);
	return(1);
}

#-----------------------------------------------------------------------------#
#    sub scalar2hash : Scalar To Hash
#-----------------------------------------------------------------------------#
#    input  : (1) Scalar
#-----------------------------------------------------------------------------#
#    output : (1) Hash
#-----------------------------------------------------------------------------#
sub scalar2hash {
	my ($scalar) = @_;
	my %hash;

	foreach my $row ( split(/\n/, $scalar ) ) {
		$row =~ /^([^=]*)=([^\n]*)/;
		my ($n, $v) = ($1, $2);
		$v =~ s/\r/\n/g;
		if( $n =~ /^([^\n]*)\[([^\n]*)\]/ ) {         # Array
			$hash{$1}->[$2] = $v;
		} elsif( $n =~ /^([^\n]*)\{([^\n]*)\}/ ) {    # Hash
			$hash{$1}->{$2} = $v;
		} else {
			$hash{$n} = $v;
		}
	}
	
	return(%hash);
}

#-----------------------------------------------------------------------------#
#    sub hash2scalar : Hash To Scalar
#-----------------------------------------------------------------------------#
#    input  : (1) Hash
#-----------------------------------------------------------------------------#
#    output : (1) Scalar
#-----------------------------------------------------------------------------#
sub hash2scalar {
	my (%hash) = @_;
	my $scalar;

	while( my ($n, $v) = each(%hash) ) {
		if( $v =~ /^ARRAY\([^\0]*\)/ ) {
			for( my $i = 0; $i < (@$v); $i ++ ) {
				$v->[$i] =~ s/\r\n/\r/g;
				$v->[$i] =~ s/\n/\r/g;
				$scalar .= "$n\[$i\]=$v->[$i]\n";
			}
		} elsif( $v =~ /^HASH\([^\0]*\)/ ) {
			while( my ($nn, $vv) = each(%$v) ) {
				$vv =~ s/\r\n/\r/g;
				$vv =~ s/\n/\r/g;
				$scalar .= "$n\{$nn\}=$vv\n";
			}
		} else {
			$v =~ s/\r\n/\r/g;
			$v =~ s/\n/\r/g;
			$scalar .= "$n=$v\n";
		}
	}
	
	return($scalar);
}

#-----------------------------------------------------------------------------#
#    sub session_change : Session ID変更
#-----------------------------------------------------------------------------#
#    input  : (1) Session Name
#    input  : (2) Session ID
#    input  : (3) ランダム値
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:正常,0:有効期限切れ:,-1:不正なセッションID,-2:Container不在,-3:Session ID発行エラー)
#    output : (2) New Session ID
#-----------------------------------------------------------------------------#
sub session_change {
	my ($s_name, $s_id, $rand) = @_;

	#-- Check Session --#
	my $chk = &session_check($s_name, $s_id);
	if( $chk != 1 )  { return($chk); }

	#-- Get Session Data --#
	my $data = &getSessionData($s_name, $s_id);
	if( $data eq '' )  { return(-2); }

	#-- Make Session ID --#
	my $new_s_id = &makeSessionID($s_name, $rand);
	if( &blength($new_s_id) != $s_length )  { return(-3); }

	#-- Set Attribute --#
	$$data{'session_id'} = $new_s_id;
	&setSessionData($s_name, $new_s_id, $data) || return(-2);
	&session_end($s_name, $s_id);
	
	return(1, $new_s_id);
}

#-----------------------------------------------------------------------------#
#    sub session_end : Session 終了
#-----------------------------------------------------------------------------#
#    input  : (1) Session Name
#    input  : (2) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) 結果(1:OK,0:異常終了,-1:不正なセッションID,-2:Container不在)
#-----------------------------------------------------------------------------#
sub session_end {
	my ($s_name, $s_id) = @_;

	if( &blength($s_id) != $s_length )  { return(-1); }

	my $s_path = &getSessionPath($s_name, $s_id);
	if( -s $s_path ) {
		unlink($s_path);
		return(1);
	} else {
		return(-2);
	}
}

#-----------------------------------------------------------------------------#
#  ライブラリ専用ライブラリ
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
#    sub getSessionData : Sessionコンテナデータ取得
#-----------------------------------------------------------------------------#
#    input  : (1) Session Name
#    input  : (2) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) コンテナデータ(Hash Ref)
#-----------------------------------------------------------------------------#
sub getSessionData {
	my ($s_name, $s_id) = @_;
	my $s_path = &getSessionPath($s_name, $s_id);

	if(-s $s_path){
		
		&session_sopen(IN, '<', $s_path) || return();
		my %ref;
		my $cnt = 0;
		while(<IN>) {
			chomp;
			$_ = Encode::decode('utf8', $_);
			if( $cnt < (@fields) - 1 ) {
				$ref{$fields[$cnt]} = $_;
				$cnt ++;
			} else {
				$ref{'data_area'} .= $_ . "\n";
			}
		}
		close(IN);

		#---- timestamp値変換→日付 ----#
		$ref{'start_date'} = &chg_timestamp($ref{'start_date'}, 2);
		$ref{'last_update_date'} = &chg_timestamp($ref{'last_update_date'}, 2);
		$ref{'last_reference_date'} = &chg_timestamp($ref{'last_reference_date'}, 2);
		$ref{'delete_date'} = &chg_timestamp($ref{'delete_date'}, 2);

		return(\%ref);
	}

	return();
}

#-----------------------------------------------------------------------------#
#    sub setSessionData : Sessionコンテナデータ設定
#-----------------------------------------------------------------------------#
#    input  : (1) Session名
#    input  : (2) Session ID
#    input  : (3) データ
#-----------------------------------------------------------------------------#
#    output : (1) 結果(0:NG,1:OK)
#-----------------------------------------------------------------------------#
sub setSessionData {
	my ($s_name, $s_id, $data) = @_;
	my $s_path = &getSessionPath($s_name, $s_id);

	#---- 日付→timestamp値変換 ----#
	$$data{'start_date'} = &chg_timestamp($$data{'start_date'}, 1);
	$$data{'last_reference_date'} = &chg_timestamp($$data{'last_reference_date'}, 1);
	$$data{'last_update_date'} = &chg_timestamp($$data{'last_update_date'}, 1);
	$$data{'delete_date'} = &chg_timestamp($$data{'delete_date'}, 1);
	my $buf;
	foreach( @fields ) {
		$buf .= $$data{$_} . "\n";
	}
	chomp($buf);
	
	&session_sopen(OUT, '>', $s_path) || return(0);
	print OUT Encode::encode('utf8', $buf);
	close(OUT);
	
	return(1);
}

#-----------------------------------------------------------------------------#
#    sub makeSessionID : Make Session ID
#-----------------------------------------------------------------------------#
#    input  : (1) Session Name
#    input  : (2) ランダム値
#-----------------------------------------------------------------------------#
#    output : (1) Session ID
#-----------------------------------------------------------------------------#
sub makeSessionID {
	my ($s_name, $rand) = @_;

	#--- ランダム値の設定 ----------------------------------------------------#
	if ( $rand eq '' )           { $rand = $default_rand + 1; }
	elsif ( $rand > $max_rand )  { $rand = $max_rand + 1; }
	else                         { $rand = $rand + 1; }

	#-- Make Basic Directory --#
	my $s_path;
	foreach( "$con_dir/$s_name/", "Container/", "$carrier/" ) {
		$s_path .= $_;
		unless( -d $s_path ) {
			mkdir($s_path, 0777) || return(0);
		}
	}
	
	#---- Make Session ID ----#
	my $s_id;
	for ( my $i = 1; $i <= 3; $i++ ) {
		my $r = int(rand($rand));
		$s_id .= sprintf("%02d", int("$r"));
	}
	foreach( split(/\./, $ENV{'SERVER_ADDR'}) ) {
		$s_id .= sprintf("%02x", $_);
	}
	if( $ENV{'UNIQUE_ID'} ne '' &&						# UNIQUE IDが存在し
			length($ENV{'UNIQUE_ID'}) == 19 &&			# 19文字で
			$ENV{'UNIQUE_ID'} =~ /^[\x00-\x7F]+$/ ) {	# 全てASCIIのとき
	} else { # その他
		$s_id .= sprintf("%011d", time);
		$s_id .= sprintf("%08d", $$);
	}
	
	#---- Make Session Container's Directory ----#
	my $ss = 0;
	foreach( "2", "2", "2" ) {
		$s_path .= substr($s_id, $ss, $_) . "/";
		unless( -d $s_path ) {
			mkdir($s_path, 0777) || return(0);
		}
		$ss += $_;
	}
	$s_path = &getSessionPath($s_name, $s_id);
	if( -s $s_path )  { return(0); }
	
	return($s_id);
}

#-----------------------------------------------------------------------------#
#    sub setTerm : 指定した有効期限を設定
#-----------------------------------------------------------------------------#
#    input  : (1) Session開始日
#    input  : (2) 最終アクセス日時
#    input  : (3) 最終更新日時
#    input  : (4) 有効期限
#-----------------------------------------------------------------------------#
#    output : (1) 有効期限日時
#-----------------------------------------------------------------------------#
sub setTerm {
	my ($s_date, $a_date, $u_date, $term) = @_;

	if( $term =~ /^[0-9]{14}$/ ) { # 日付指定
		$term =~ /(....)(..)(..)(..)(..)(..)/;
		if( &Date::Calc::check_date($1, $2, $3) ) {
			if( ( $4 >= 0 && $4 < 24 ) && ( $5 >= 0 && $5 < 60 ) && ( $6 >= 0 && $6 < 60 ) ) {
				return($term);
			}
		}
	} else { # 相対指定
		$term =~ /^(S|L|U)([0-9]*)(D|H|M|S)$/;
		if( $1 ne '' && $3 ne '' ) {
			my $date;
			if( $1 eq 'S' )     { $date = $s_date; }
			elsif( $1 eq 'L' )  { $date = $a_date; }
			elsif( $1 eq 'U' )  { $date = $u_date; }
			my ($dd, $dh, $dm, $ds) = (0, 0, 0, 0);
			if( $3 eq 'D' )  { $dd = $2; }
			elsif( $3 eq 'H' )  { $dh = $2; }
			elsif( $3 eq 'M' )  { $dm = $2; }
			elsif( $3 eq 'S' )  { $ds = $2; }
			$date =~ /^(....)(..)(..)(..)(..)(..)/;
			my ($y, $m, $d, $hh, $mm, $ss) = &Date::Calc::Add_Delta_DHMS($1, $2, $3, $4, $5, $6, $dd, $dh, $dm, $ds);
			return( sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss) );
		}
	}
}

#-----------------------------------------------------------------------------#
#    sub now : 現時間を取得
#-----------------------------------------------------------------------------#
#    output : (1) 現時間(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub now {
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
	
	$year += 1900;
	$mon ++;
	return(sprintf("%04d%02d%02d%02d%02d%02d",$year,$mon,$mday,$hour,$min,$sec));
}

#-----------------------------------------------------------------------------#
#    sub chg_timestamp : 日付←→timestamp値 変換
#-----------------------------------------------------------------------------#
#    input  : (1) 日付(YYYYMMDDhhmmss) or timestamp値
#    input  : (2) 1 = 日付→timestamp値 ／ 2 = timestamp値→日付
#-----------------------------------------------------------------------------#
#    output : (1) timestamp値 or 日付(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub chg_timestamp {
    my( $win, $flg ) = @_;
    my( $ss, $mm, $hh, $d, $m, $y, $wd, $yd, $ist, $wot );

    if( $flg == 1 ) {
		($y,$m,$d,$hh,$mm,$ss) = ( $win =~ /^([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$/ );
        $y -= 1900;
        $m --;
        $wot = timelocal($ss,$mm,$hh,$d,$m,$y);
    } else {
        ($ss,$mm,$hh,$d,$m,$y,$wd,$yd,$ist) = localtime($win);
        $y += 1900;
        $m ++;
        $wot = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
    }

    return $wot;
}

#-----------------------------------------------------------------------------#
#    sub getSessionPath : Sessionファイルパスを取得
#-----------------------------------------------------------------------------#
#    input  : (1) Session名
#    input  : (2) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) ファイルパス
#-----------------------------------------------------------------------------#
sub getSessionPath {
	my ($s_name, $s_id) = @_;

	my $path = "$con_dir/$s_name/Container/$carrier/" .
		substr($s_id, 0, 2) . "/" .
		substr($s_id, 2, 2) . "/" .
		substr($s_id, 4, 2) . "/" .
		substr($s_id, 6) . ".txt";
	
	return($path);
}


#-----------------------------------------------------------------------------#
#  既存ライブラリからのパクリ
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
#    sub session_sopen : セキュリティ保護機能実装ファイルOPEN
#-----------------------------------------------------------------------------#
#    input  : (1) ファイルハンドル
#    input  : (2) 入出力リダイレクト（ <,>,>>,| ）
#    input  : (3) 対象ファイル名
#    input  : (4) パイプコマンド( 1..n : 順番に起動する）
#-----------------------------------------------------------------------------#
#    output : (1) リターンコード( 1:正常,0:異常終了 ）
#-----------------------------------------------------------------------------#
sub session_sopen {
	my( $fhd, $io, $in_file, @in_com ) = @_;
	my( $file, $com, @com, $wk, $rtn );

	$file = &session_path( $in_file ); 
	foreach $com (@in_com)  { push( @com, &session_meta($com) ); }
	undef $wk;
	undef $rtn; 
	if( $io eq '<' ) {
		if( @com ) {
			$com = shift( @com ); 
			$wk .= "$com $file |";
			foreach $com ( @com )  { $wk .= "$com |"; }
		}
		else { $wk .= "$file"; }
	}
	elsif( $io eq '>' || $io eq '>>' ) {
		if( @com ) {
			foreach $com ( @com )  { $wk .= "| $com "; }
			$wk .= "$io $file";
		}
		else { $wk .= "$io $file"; }
	}
	elsif( $io eq '|' ) {
		$com = shift( @com ); 
		$wk .= "| $com";
		if( @com ) {
			foreach $com ( @com )  { $wk .= " | $com"; }
		}
	}
	if( $wk )  { $rtn = open( $fhd, $wk ); }

	return( $rtn ); 
}

#-----------------------------------------------------------------------------#
#    sub session_meta : データ中から危険なメタ文字を削除
#-----------------------------------------------------------------------------#
#    input  : (1) 変換前文字列
#-----------------------------------------------------------------------------#
#    output : (1) 変換後文字列
#-----------------------------------------------------------------------------#
sub session_meta {
	my( $in ) = shift; 

	$in =~ s/([;<>\*\|&\$!#\(\)\[\]\{\}:\'\"])//g;
	return( $in );
}

#-----------------------------------------------------------------------------#
#    sub session_path : ファイルパスとして使用可能な文字列以外の文字列を削除する
#-----------------------------------------------------------------------------#
#    input  : (1) 変換前文字列
#-----------------------------------------------------------------------------#
#    output : (1) 変換後文字列
#-----------------------------------------------------------------------------#
sub session_path {
	my( $in ) = shift; 

	$in =~ s/[^a-zA-Z0-9\-_\.\/\@]//g;
	$in =~ s/\.\.+//g;
	return( $in ); 
}

#-----------------------------------------------------------------------------#
#	sub blength : バイト数を返却する
#-----------------------------------------------------------------------------#
#	input  : (1) 文字列
#-----------------------------------------------------------------------------#
#	output : (1) 文字列のバイト数
#-----------------------------------------------------------------------------#
sub blength(){
	my ($str) = @_;
	$str = Encode::encode('utf8', $str);
	return( length($str) );
}

1;
