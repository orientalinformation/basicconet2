package MG_ENV;
#----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  可変環境情報取得 パッケージ
#     Program Name   :  MG_ENV.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2010 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Create
#     version 1.1.0  :  2013.10.20 (YU) Plack/PSGI対応
#-----------------------------------------------------------------------------#
#
#     仕様概要
#             このパッケージは、環境情報ファイルに記述された内容から
#             動作環境に応じた情報を返却します。
#
#     パッケージ使用方法
#
#             [1] 起動サーバの取得
#                 $s_env = &MG_ENV::server_env();
#                 ※返却される文字列は以下のとうり
#                   (1) DEBUG  ............ 制作環境
#                   (2) TEST   ............ テスト（検証）環境
#                   (3) HONBAN ............ 本番環境
#             [2] 環境情報ファイルから設定情報の取得
#                 &MG_ENV::info_get( *mg_env );
#
#     環境情報ファイル設定方法
#
#             基本的に　環境変数名=データ　の形式で記述する。
#             環境変数名はその影響する範囲毎に下記のように設定する。
#
#          ・特定のプログラムのみに影響
#            PRG-[プログラム名]-[環境変数名]
#            /CGI/member/entry.cgiのみで使用されるメールアドレスの場合
#            PRG-MEMBER-ENTRY-EMAIL=xxx@yyy.co.jp
#
#          ・システム全体に影響
#            SYS-[システム名]-[環境変数名]
#            /CGI/member/　以下全てのプログラムで使用されるメールアドレスの場合
#            SYS-MEMBER-EMAIL=xxx@yyy.co.jp
#
#          ・品目全体に影響
#            [環境変数名]
#            品目全体で使用されるメールアドレスの場合
#            EMAIL=xxx@yyy.co.jp
#
#     注意事項
#             環境変数名に使用できない文字
#              「大文字英数字、アンダーバー以外」
#             データに使用できない文字
#              「=」「#」「SPACE」「TAB」
#
#----------------------------------------------------------------------------#
use utf8;

my $version = "1.0.0";
my $library_name = 'MG_ENV.pl';

&initial_setting unless defined $initial_setting;
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#-----------------------------------------------------------------------------#
#     initial_setting : initial setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	$initial_setting = 1;

	#--- 特殊な検証環境のURLは以下へ追加する ---#
	#--- CgiError.plも同様なロジックを使用している為 ---#
	#--- 同時に修正を行う事！！！ ---#

	$server_env = '';

	$server_root = '/WWW';
	my (@getpwuid, $hinmei);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

#1.1.0#	#====[ Webの場合 ]
#1.1.0#	if ($ENV{'DOCUMENT_ROOT'} =~ m|$server_root/$hinmei/http| ||
#1.1.0#		$ENV{'DOCUMENT_ROOT'} =~ m|$server_root/$hinmei/https|) {
#1.1.0#
#1.1.0#		if ( substr($hinmei,3,1) == 3) {
#1.1.0#			$server_env = 'DEBUG';
#1.1.0#		} elsif ( substr($hinmei,3,1) == 2) {
#1.1.0#			$server_env = 'TEST';
#1.1.0#		} else {
#1.1.0#			$server_env = 'HONBAN';
#1.1.0#		}
#1.1.0#
#1.1.0#	#====[ バッチの場合 ]
#1.1.0#	} else {
#1.1.0#
#1.1.0#		#--- 現在の作業ディレクトリの取得 ----------------------------#
#1.1.0#
#1.1.0#		#--- 引き数から起動サーバを把握 ------------------------------#
#1.1.0#		if ( $ARGV[0] eq 'h' ) {
#1.1.0#			$server_env = 'HONBAN';
#1.1.0#		} elsif ( $ARGV[0] eq 't' ) {
#1.1.0#			$server_env = 'TEST';
#1.1.0#		} else {
#1.1.0#			$server_env = 'DEBUG';
#1.1.0#		}
#1.1.0#	}

	# --- 環境修正
	if ( substr($hinmei,3,1) == 1) {                                #1.1.0#
		$server_env = 'HONBAN';                                     #1.1.0#
	} elsif ( substr($hinmei,3,1) == 2) {                           #1.1.0#
		$server_env = 'TEST';                                       #1.1.0#
	} else {                                                        #1.1.0#
		$server_env = 'DEBUG';                                      #1.1.0#
	}
}

#----------------------------------------------------------------------------#
#     server_env : 起動サーバ種別返却
#----------------------------------------------------------------------------#
#     output : (1) 起動サーバ
#----------------------------------------------------------------------------#
sub server_env { return ( $server_env ); }

#----------------------------------------------------------------------------#
#     info_get : 環境情報ファイルから設定情報の取得
#----------------------------------------------------------------------------#
#     output : (1) 設定情報
#----------------------------------------------------------------------------#
sub info_get {
	local( *mg_env ) = shift;

	$server_root = '/WWW';
	my (@getpwuid, $hinmei);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	#--- 環境情報ファイルパス ---#
	$mg_env_file = "$server_root/$hinmei/pubdata/MG_ENV/mg_env.txt";

	if ( -s $mg_env_file ) {
		if ( open(IN,"$mg_env_file") ) {
			binmode(IN, ":utf8");
			while ( <IN> ) {
				chomp;
				if ( $_ !~ /^#/ && length($_) > 0 ) {
					$_ =~ s/#.+$//ig;				# ＃以降削除
					$_ =~ s/\s+$//ig;				# 末尾スペース削除
					($n,$v) = split(/=/);
					if ( $n =~ /^DEBUG:/ && $server_env eq "DEBUG" ) {
						$n =~ s/^DEBUG://;			#環境種別削除
						$mg_env{$n} = $v;
					} elsif ( $n =~ /^TEST:/ && $server_env eq "TEST" ) {
						$n =~ s/^TEST://;			#環境種別削除
						$mg_env{$n} = $v;
					} elsif ( $n =~ /^HONBAN:/ && $server_env eq "HONBAN" ) {
						$n =~ s/^HONBAN://;			#環境種別削除
						$mg_env{$n} = $v;
					}
				}
			}
			close IN;
		}
	}

	return ( *mg_env );

}
1;
