package FileLock;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  ファイル排他制御 パッケージ
#     Program Name   :  FileLock.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#-----------------------------------------------------------------------------#
#     comment : 
#
#     <処理概要>
#
#         このライブラリは、データファイルを操作する際に複数のプログラムが
#         同一のファイルを同時に操作しないように排他制御を行います。
#         CSVファイルやテキストファイルのOPENを行う場合には、必ず
#         このライブラリを利用します。
#
#         このライブラリに指定されたファイルは、同時にアクセスすることが
#         許されません。いままでの「filelock.pl」との違いは、
#         ロックファイルを指定するのではなく、ファイル自体を指定するところ
#         にあります。ロックファイル自体は指定の場所（初期設定参照）に
#         ファイル毎に自動的に作成されます。
#
#     <初期設定>
#
#         /WWW/[品目名]/pubdata/Lock/File/ というディレクトリが必要
#         ※上記ディレクトリ配下に、「ファイルパス名.lock」というファイルが
#           作成され、それが排他制御用のファイルとなります。
#
#     <利用履歴(品目毎の排他制御の利用履歴)>
#  
#         ProcessLock、FileLock、SystemLockを新規で実装した場合には、必ず
#         利用履歴を記述しておく必要があります。（本番サーバへもステージング）
#         実装した排他制御の種別、何のための排他制御なのか、どのような処理
#         の場合に同一の排他制御を利用すべきなのか、修正や後から担当になった
#         人の為に解りやすく記述してください。
#        
#         利用履歴ファイル：/WWW/[品目名]/pubdata/Lock/README.txt
#               
#         ----- 記述例 --------------------------------------------------------
#         | 2005年01月25日　[SystemLock] /WWW/CGI/xxx/xxx.cgi 藁谷(Ver1.0.0)  |
#         |                 会員データの新規登録の際、memberとpointの２つの   |
#         |                 テーブルに書き込みを行い同期をとっている。        |
#         |                 これら２つのテーブルに対してinsertを行う場合には  |
#         |                 必ずこのロックを利用すること。                    |
#         |                 システム名＝「member_point_tbl_insert」           |
#         | 2005年01月25日　[FileLock] /WWW/CGI/yyy/yyy.cgi 丸山(Ver1.1.0)    |
#         |                 ログイン失敗のデータログの出力に利用              |
#         |                 ファイル名＝/WWW/DATA/yyy/yyy.log                 |
#         ---------------------------------------------------------------------
#     <利用方法>
#         require '/WWW/[品目名]/perl/perlsub/FileLock.pl';   # パッケージ定義
#         
#         my $data_dir = "/WWW/[品目名]/data/xxxxx/xxxxx/xxxxx.csv";  # ファイル定義
#
#         # ファイルロック開始（ファイルをOPENする直前に）
#         my $rtn = &FileLock::lock_start( $data_dir ); 
#         if ( $rtn != 0 ){ 
#             if ( $rtn == 1 ){
#                  &CgiError::normal_error
#                    ("現在アクセスが込み合っています。少々お待ちください"); 
#             }
#             else {
#                  &CgiError::abend("プロセスロック設定エラー ($rtn)"); 
#             }
#         }
#
#         # ファイル操作ロジック
#         my $OTF = new IO::Handle; 
#         &sopen( $OTF,">>",$data_dir ) || &CgiError::abend(".....");
#         
#         ...... 処理ロジック ......
#
#         close ( $OTF ); 
#
#         # プロセスロック完了（プログラム最後で呼び出す）
#         if ( ! &FileLock::lock_end( $data_dir) ){ 
#             &CgiError::abend("プロセスロック失敗"); 
#         }
#
#     <処理関数詳細>    
# 
#     [1] ファイルロックを開始する。
#      
#      &FileLock::lock_start( ロック対象ファイル名,試行回数,最大有効時間 ) 
#
#      ロック対象ファイル名は、操作するファイル自体のパスを指定する。
#      ロックできたら、0を返す。ロックに失敗したら、0以外を返す
#      ロック試行回数とはロックができなかった場合に何回リトライするかを
#      数値で指定する（デフォルト５回。省略可能）
#      ロック最大有効時間とは、ロックファイルがなんらかの状態で残ってしまう
#      ことをさける為に、指定秒数以上経過している場合には強制的にロックを
#      はずし、新しくロックする機能。秒単位で数値で指定する
#     （デフォルト600秒。省略可能）
#      ロック最大有効時間に明示的に「0」を指定した場合には、経過秒以上の判断を
#      せず、明示的な解除がされるまでロックを行う。（バッチ処理など処理時間が
#      長い場合や、安易な解除をしたくないシステムなどで使用する）
#
#      ※最大有効期間を設定する場合には、ロック試行回数も必ず対で指定する。
#      ※&FileLock::start( ,900 ) のような指定はできない。
#
#     [2] ファイルロックを解除する。
#
#     &FileLock::lock_end ( ロック対象ファイル名 );
#
#      ロック対象ファイル名は、操作するファイル自体のパスを指定する。
#    　ロック解除できたら、１を返す。０の場合は異常
#
#-----------------------------------------------------------------------------#
use utf8;

my $version = "1.0.0";
my $library_name = 'FileLock.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#-----------------------------------------------------------------------------#
#     lock_start : ロック開始
#-----------------------------------------------------------------------------#
#     input(1) : ロック対象ファイルパス（省略不可）
#     input(2) : ロック試行回数（省略可、省略時5回）
#     input(3) : ロック最大有効時間（省略可、省略時600秒）
#-----------------------------------------------------------------------------#
#     output : リターンコード   0..... 正常にロック完了
#                               1..... プロセス起動中（ロック中）
#                               2..... 品目名の取得に失敗
#                               3..... ロックディレクトリ不備
#-----------------------------------------------------------------------------#
sub lock_start {

	my ( $file_path, $alarm_interval, $maxlock_sec )   = @_; 

	# 品目ディレクトリ名の取得
	my $server_root = '/WWW';
	my (@getpwuid, $hinmei);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	if ( length( $hinmei ) <= 0 ){ return( 2 ); }

	# ロックディレクトリ、ファイル名の把握
	my $file_dir  = $server_root."/$hinmei/pubdata/Lock/File";
	
	my $file_name = $file_path;
	$file_name =~ s|/|-|ig; 
	$file_name .= ".lock";
	my $real_name = ".filelock_${file_name}";
	my $lock_file = "$file_dir/$file_name"; 

	# ディレクトリ不備調査
	if ( -d $file_dir && -r $file_dir && -w $file_dir ){  

		# ロックする為のリアルファイルの作成
		if ( ! -r "$file_dir/$real_name" ){
			`/bin/touch $file_dir/$real_name`;
			unlink( $lock_file );
		}
		
		# 試行回数のデフォルト設定
		if ( $alarm_interval !~ /^[0-9]+$/ || $alarm_interval < 0 ){   
			$alarm_interval = 5;      
		}
		
		# ロック期間のデフォルト設定
		if ( $maxlock_sec !~ /^[0-9]+$/){ 
			$maxlock_sec = 600;
		}

		if ( -s $lock_file || -e $lock_file ) {
			my $timestmp = &filelock_timestmp( $lock_file );
			if ( $timestmp && $maxlock_sec > 0 ){
				if ( time - $timestmp > $maxlock_sec ) {
					if ( ! &lock_end($file_path) ){
						return( 1 );
					}
				}
			}
		}
		# ロックファイルを作成できるまでループする
		my $buf_alarm_interval = $alarm_interval; # 試行回数保持
		while( ! symlink( $real_name,$lock_file ) ) {  
			if ( --$alarm_interval <= 0 ){
				my $timestmp = &filelock_timestmp( $lock_file );
				if ( $timestmp && $maxlock_sec > 0
					 && ( time - $timestmp > $maxlock_sec ) ){
					if ( ! &lock_end($file_path) ){
						return( 1 );
					}
					$alarm_interval = $buf_alarm_interval;
				}
				else { return( 1 ); }  
			}
			else { sleep( 1 ); }
		}
		return( 0 );
	}
	else { return ( 3 ); }
}

#-----------------------------------------------------------------------------#
#     lock_end : ロック完了（ロックファイルの削除）
#-----------------------------------------------------------------------------#
#     input(1) : ロック対象ファイルパス（省略不可）
#-----------------------------------------------------------------------------#
#     output : リターンコード( 1...正常、0...異常　）
#-----------------------------------------------------------------------------#
sub lock_end {
	my $file_path = shift; 

	# 品目ディレクトリ名の取得
	my $server_root = '/WWW';
	my (@getpwuid, $hinmei);
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	if ( length( $hinmei ) <= 0 ){ return( 2 ); }

	# ロックディレクトリ、ファイル名の把握
	my $file_dir  = $server_root."/$hinmei/pubdata/Lock/File";

	my $file_name = $file_path;
	$file_name =~ s|/|-|ig; 
	$file_name .= ".lock";
	my $lock_file = "$file_dir/$file_name";

	# ロックファイルを削除する
	my ( $unun ) = unlink( $lock_file );

	return( $unun );
}

#-----------------------------------------------------------------------------#
#     filelock_timestmp : ファイルのタイムスタンプを把握
#-----------------------------------------------------------------------------#
#     input  : ファイルパス
#-----------------------------------------------------------------------------#
#     output : タイムスタンプ（mtime）
#-----------------------------------------------------------------------------#
sub filelock_timestmp (){ 
	my( $file ) = shift;  
	my( $dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$time_stmp,
		$mtime,$ctime,$blksize,$blocks ) = lstat( $file );
	return( $mtime );
}
1;

