package Utility;

#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(MGクラウド汎用版)
#     Project Name   :  Mysql利用 ライブラリ
#     Program Name   :  MysqlUty.pl
#     Create Date    :  2013.07.27
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2013 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2013.07.27 (YU) New Create
#-----------------------------------------------------------------------------#
#     history        :  MGクラウド版ライブラリ
#-----------------------------------------------------------------------------#
#
#     仕様概要
#             MySQLを使った、接続やSQL実行サポート
#
#     動作環境
#             [1] Linux環境専用
#                 DBD::mysql をメイン処理で呼ぶ事。
#
#     パッケージ使用方法
#
#             [1] MySQL接続
#                  $dbh = &MysqlUty::db_connect($host, $dbname, $user, $passwd, {
#                      AutoCommit => 1,
#                      AutoInactiveDestroy  => 0,
#                      mysql_auto_reconnect => 0,
#                      RaiseError => 0,
#                      mysql_enable_utf8 => 1,
#                  });
#
#             [2] MySQL実行
#                  ($sth,$err,$warnings) = &MysqlUty::db_access($dbh,$sql);
#                  if($err || $warnings){
#                     $dbh->disconnect()if($dbh);
#                     &CgiError::abend( "[DB-02]","[$sql]",$err,$warnings);
#                  }
#                  $sth->finish;
#
#     返り値の説明
#             エラー処理は品目側処理として適切に組み込む。
#
#     処理制御パラメータの説明(\%modeリファレンス)
#
#             %mode  -> nameをkeyとした連想配列
#             文字列変換処理を行ないたくない文字を指定可能
#
#             指定方法
#
#              $mode{"\x26"} = "off" ;   #行ないたくない文字（未変換）は'off'指定

#
#     注意事項
#             接続パラメータを変更する場合は挙動に注意すること。
#-----------------------------------------------------------------------------#
use utf8;
use Encode;
use strict;
use warnings;

my $version      = "1.0.0";
my $library_name = 'Utility.pl';

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
    return ( $version, $library_name );
}

#-----------------------------------------------------------------------------#
#   db_connect : DBD::mysql接続インターフェース
#-----------------------------------------------------------------------------#
#    input  : (1) ホスト
#    input  : (2) DB名
#    input  : (3) ユーザー
#    input  : (4) パスワード
#    input  : (5) 接続オプション (ハッシュリファレンス)
#-----------------------------------------------------------------------------#
#    output : (1) DBハンドル
#-----------------------------------------------------------------------------#
sub db_connect () {
    my ( $host, $dbname, $user, $passwd, $option ) = @_;
    my $dbh
        = DBI->connect( "DBI:mysql:$dbname:$host", $user, $passwd, $option );

    return ($dbh);
}

#-----------------------------------------------------------------------------#
#   db_access : SQL実行
#-----------------------------------------------------------------------------#
#    input  : (1) DBハンドル
#    input  : (2) SQL文
#-----------------------------------------------------------------------------#
#    output : (1) ステートメントハンドル
#-----------------------------------------------------------------------------#
sub db_access {

    my ( $dbh, $sql_list ) = @_;
    my ( $sth, $errstr, $warnings_cnt, $warnings );

    # エラー処理
    if ( !( ( $sth = $dbh->prepare("$sql_list") ) && ( $sth->execute ) ) ) {
        $errstr = $dbh->errstr;

        # 正常処理
    }
    else {
        my $warnings_cnt = $sth->{mysql_warning_count};
		my $sth2;

        # ワーニングあり
        if ($warnings_cnt) {
            if (!(     ( $sth2 = $dbh->prepare("show warnings") )
                    && ( $sth2->execute )
                )
                )
            {
                $warnings = "warning get error";
            }
            else {
                if ( my $arrayref = $sth2->fetchrow_arrayref() ) {
                    $warnings = join( ' | ', @$arrayref );
                }
                $sth2->finish;
            }
        }
    }
    return ( $sth, $errstr, $warnings );
}

#-----------------------------------------------------------------------------#
#   location_href : 絶対パスチェック付きロケーション
#-----------------------------------------------------------------------------#
#   input   : (1) 遷移先URL(要 絶対パス)
#-----------------------------------------------------------------------------#
#   output  : (1) リターンコード (0: NG, 1: OK)
#-----------------------------------------------------------------------------#
sub location_href() {

    my ($url) = @_;

    if ( substr( $url, 0, 7 ) eq 'http://'
        || substr( $url, 0, 8 ) eq 'https://'
        || substr( $url, 0, 6 ) eq 'ftp://'
        || substr( $url, 0, 7 ) eq 'ftps://' )
    {
        return;
    }
    else{
        return("[Command-01]",
            "sub location_href",
            "Fatal location URL[ $url ]\n"
        );
    }
}
#------------------------------------------------------------------------------
#   sopen : セキュリティ保護機能実装 ファイルOPEN
#------------------------------------------------------------------------------
sub sopen(){
	my ( $fhd,$io,$in_file,@in_com ) = @_; #local
	my ( $file,$com,@com,$wk,$rtn ); #local

	$file = &path( $in_file ); 
	$com = &meta($com);
	foreach $com(@in_com){ push( @com,$com ); }
	undef $wk;
	undef $rtn;
	if ( $io eq '<' ){
		if ( @com ){
			$com = shift( @com ); 
			$wk .= "$com $file |";
			foreach $com( @com ){ $wk .= "$com |"; }
		}
		else { $wk .= "$file"; }
	}
	elsif ( $io eq '>' || $io eq '>>' ){
		if ( @com ){
			foreach $com( @com ){ $wk .= "| $com "; }
				$wk .= "$io $file";
			}
			else { $wk .= "$io $file"; }
		}
		elsif ( $io eq '|' ){
			$com = shift( @com ); 
			$wk .= "| $com";
		if ( @com ){
			foreach $com( @com ){ $wk .= " | $com"; }
		}
	}
	if ( $wk ){ $rtn = open( $fhd,$wk ); }

	return( $rtn ); 
}

#------------------------------------------------------------------------------
#   scommand : セキュリティ保護機能実装 コマンド起動 ( バッククォート ）
#------------------------------------------------------------------------------
sub scommand () {
	my ( @in_com ) = @_;
	my ( $com,@com,$rtn );

	$com = &meta($com);
	foreach $com(@in_com){
		if ( $com eq '|' || $com eq '<' || $com eq '>' || $com eq '>>'
		  || $com eq ';' || $com eq '*' || $com eq '?' ){ 
			push( @com,$com ); 
		}
		else { push( @com,$com ); }
	}
	$com = join(' ',@com); 
	$rtn = `$com`;

	return( $rtn ); 
}

#------------------------------------------------------------------------------
#   ssystem : セキュリティ保護機能実装 コマンド起動 ( system )
#------------------------------------------------------------------------------
sub ssystem () {
	my ( @in_com ) = @_;
	my ( $com,@com );

	$com = &meta($com);
	foreach $com(@in_com){
		if ( $com eq '|' || $com eq '<' || $com eq '>' || $com eq '>>'
		  || $com eq ';' || $com eq '*' || $com eq '?' ){ 
			push( @com,$com ); 
		}
		else { push( @com,$com ); }
	}
	$com = join(' ',@com); 
	return ( system( $com ) ); 
}

#------------------------------------------------------------------------------
#   meta : データ中から危険なメタ文字を削除
#------------------------------------------------------------------------------
sub meta ($) {
	my ( $in ) = shift; #local

	$in =~ s/([;<>\*\|&\$!#\(\)\[\]\{\}:'"])//g;
	return( $in ); 
}

#------------------------------------------------------------------------------
#   path : ファイルパスとして使用可能な文字列以外の文字列を削除する
#------------------------------------------------------------------------------
sub path ($) {
	my ( $in ) = shift; #local

	$in =~ s/[^0-9a-zA-Z\-_\.\/]//g;
	$in =~ s/\.\.+//g;
	return( $in ); 
}

1;
