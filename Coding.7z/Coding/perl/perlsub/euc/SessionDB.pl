package SessionDB;
#-----------------------------------------------------------------------------#
#      Client Name     : ���� (****)
#      Project Name    : SessionContainer��DB�ǥ饤�֥��
#      Program Name    : SessionDB.pl
#      Create Date     : 2003.07.17
#      Programmer      : Ippey (Pro.DigitalCom.DNP)
#      Entry Server    : All Sever
#      Called By       : All Programs
#      Notice          : This File Code is EUC.
#      Copyright       : 2003 DNP.DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#      version 1.0.0   : 2003.07.17 (Ippey)     New Create
#      version 1.0.1   : 2003.09.29 (Y.Sugioka) srand�ΥХ�
#      version 2.0.0   : 2014.10.16 (y.washizu) MGCLOUD�ܹԤ�ȼ��Date::DateCalc�λ��Ѥ�ػ�
#-----------------------------------------------------------------------------#
#
# [Comment]
#��
#  ���å��������饤�֥�� DB��
#  ���å���������ˡ�ˤĤ��Ƥ϶�ͭʸ��򤴻��Ȥ���������
#  
#-----------------------------------------------------------------------------#
# [1] session_start : Session����Start!!
#  my ($rtn,$s_id) = &SessionDB::session_start($dbh,$s_name,$term);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $term : Session Term
# [Output]
#  $rtn : ���(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:Session IDȯ�ԥ��顼)
#��$s_id : Session ID
#-----------------------------------------------------------------------------#
# [2] session_check : Session Check!!
#  my ($rtn) = &SessionDB::session_check($dbh,$s_name,$s_id);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�,-3:�۾ｪλ)
#-----------------------------------------------------------------------------#
# [3] container_get : Get Container Data!!
#  my ($rtn,$code,$data) = &SessionDB::container_get($dbh,$s_name,$s_id[,$term]);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $term : Term(option)
# [Output]
#  $rtn : ���(1:����,0:ͭ�������ڤ�,-1:������Session ID,-2:����ƥ��Ժ�,-3:�۾ｪλ)
#  $code : �ǡ���������
#  $data : Container Data(Scalar)
#-----------------------------------------------------------------------------#
# [4] container_set : Set Container Data
#  my $rtn = &SessionDB::container_set($dbh,$s_name,$s_id,$code,$d_area[,$term]);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $code : Data Code
#  $d_area : Data (Scalar)
#  $term : Term
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
# [5] scalar2hash : Scalar To Hash
#  my %hash = &SessionDB::scalar2hash($scalar);
# [Input]
#  $scalar : Scalar
# [Output]
#  %hash : Hash
#-----------------------------------------------------------------------------#
# [6] hash2scalar : Hash To Scalar
#  my $scalar = &SessionDB::hash2scalar(%hash);
# [Input]
#  %hash : Hash
# [Output]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
# [7] session_change : Change Session ID
#  my ($rtn,$new_s_id) = &SessionDB::session_change($dbh,$s_name,$s_id);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Old Session ID
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼,-4:�Ķ������ߥ�)
#  $new_s_id : New Session ID
#-----------------------------------------------------------------------------#
# [8] session_end : Session End
#  my $rtn = &SessionDB::session_end($dbh,$s_name,$s_id);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
# [Output]
#  $rtn : ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

use Jcode;
use DBD::mysql;
#2.0.0#use Date::DateCalc qw(check_date calc_new_date_time);
use Date::Calc qw( check_date Add_Delta_DHMS );#2.0.0#

&initial_setting();

#-----------------------------------------------------------------------------#
# init : Initial Setting
#-----------------------------------------------------------------------------#
# [Input]
#  None
#-----------------------------------------------------------------------------#
# [Output]
#  None
#-----------------------------------------------------------------------------#
sub initial_setting{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#



    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if($ENV{SCRIPT_FILENAME} =~ m#[\w+]/(CGI|SCGI)/([^/]+)#){
		$hin_dir = $2;
	}elsif($2 =~ /-bin/){
		$hin_dir = $`;
	}else{
		print "Content-typej:text/plain;charset=Shift_JIS\n\n";
		print "Can't execute SessionContainer.pl!!\n";
	}
	
	$s_length = 39; # Session ID's Length
	
	
	@fields = qw(
		session_id start_date last_reference_date last_update_date
		get_cnt set_cnt data_code carrier user_agent data_area
	); # Container's Data Fields
	
	#---- Check carrier ----#
	$carrier = 'WWW';
	$table_flg = '_w';
	if($ENV{HTTP_USER_AGENT} =~ /^DoCoMo/){
		$carrier = 'IMODE';
		$table_flg = '_i';
	}elsif($ENV{HTTP_X_JPHONE_COLOR} ne ''){
		$carrier = 'SKY';
		$table_flg = '_j';
	}elsif($ENV{HTTP_X_UP_SUBNO} ne ''){
		$carrier = 'WAP';
		$table_flg = '_e';
	}

}

#-----------------------------------------------------------------------------#
# session_start : Session����Start!!
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $term : Session Term
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:Session IDȯ�ԥ��顼)
#��$s_id : Session ID
#-----------------------------------------------------------------------------#
sub session_start{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$term) = @_;
	my $now = &now();

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#---- Check Param ----#
	#-- Session Name --#
	if($s_name eq ''){
		return(0);
	}
	
	#-- Term --#
	my $s_term = &setTerm($now,$now,$term);
	if($now > $s_term){
		return(-1);
	}
	
	#---- Make Session ID ----#
	my $s_id = &makeSessionID();
	if(length($s_id) != $s_length){
		return(-2);
	}
	
	#---- Make Session Container ----#
	my $sql = "insert into $s_name$table_flg set ";
	$sql .= "session_id = " . $dbh->quote($s_id) . ",";
	$sql .= 'start_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_reference_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_update_date = ' . $dbh->quote($s_term) . ",";
	$sql .= 'get_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'set_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'data_code = ' . $dbh->quote('asc') . ",";
	$sql .= "carrier = " . $dbh->quote($carrier) . ",";
	$sql .= 'user_agent = ' . $dbh->quote($ENV{HTTP_USER_AGENT}) . ",";
	$sql .= 'data_area = ' . $dbh->quote('');
	
	my $sth = &execQuery($dbh,$sql) ||
		return(0);
	$sth->finish;
	
	return(1,$s_id);
	
}

#-----------------------------------------------------------------------------#
# session_check : Session Check!!
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�,-3:�۾ｪλ)
#-----------------------------------------------------------------------------#
sub session_check{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id) = @_;
	my $now = &now;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#---- Check Session ID ----#
	if($s_id eq '' || ($s_id ne '' && length($s_id) != $s_length)){
		return(-2);
	}else{
	
		#---- Search Session Container ----#
		my ($rtn,$rs) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn == 0){return(-3);}
		
		if($rs ne ''){
			if($now > $$rs{last_update_date}){return(0);}
			if($ENV{HTTP_USER_AGENT} ne $$rs{user_agent}){return(-1);}
			return(1);
		}else{ # Not Found
			return(-2);
		}
		
	}

}

#-----------------------------------------------------------------------------#
#  container_get : Get Container Data!!
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $term : Term(option)
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:����,0:ͭ�������ڤ�,-1:������Session ID,-2:����ƥ��Ժ�,-3:�۾ｪλ)
#  $code : �ǡ���������
#  $data : Container Data(Scalar)
#-----------------------------------------------------------------------------#
sub container_get{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id,$term) = @_;
	my $rtn;
	my $now = &now;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#---- Check Session ----#
	my $chk = &session_check($dbh,$s_name,$s_id);
	if($chk != 1){
		return($chk); # Error
	}else{
		
		my ($rtn,$data) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn == 0){
			return(-3);
		} # Abend
		if($data eq ''){
			return(-2);
		} # Not Found
		if($now > $$data{last_update_date}){
			return(0);
		} # Time is Over.
		
		#---- Set Attribute ----#
		$$data{get_cnt} ++;
		$$data{last_reference_date} = $now;
		if($term ne ''){
			my $s_term = &setTerm($$data{start_date},$$data{last_reference_date},$term);
			unless($now > $s_term){$$data{last_update_date} = $s_term;}
		}
		
		my $s_rtn = &setSessionData($dbh,$s_name,$s_id,$data);
		if($s_rtn == -1){return(-3);} # Abend
		if($s_rtn == 0){return(-2);} # Not Found
		
		return(1,$$data{data_code},$$data{data_area});
		
	}

}

#-----------------------------------------------------------------------------#
# container_set : Set Container Data
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $code : Data Code
#  $d_area : Data (Scalar)
#  $term : Term
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
sub container_set{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id,$code,$d_area,$term) = @_;
	my $rtn;
	my $now = &now(); 

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#---- Check Session ----#
	my $chk = &session_check($dbh,$s_name,$s_id);
	if($chk != 1){
		return($chk);
	}else{
		
		my ($rtn,$data) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn != 1){
			return(-3);
		} # Abend
		if($data eq ''){
			return(-2);
		} # Not Found
		if($now > $$data{last_update_date}){
			return(0);
		} # Time is over.
		
		#---- Set Attribute ----#
		$$data{set_cnt} ++;
		$$data{last_reference_date} = $now;
		$$data{data_code} = $code;
		$$data{data_area} = $d_area;
		if($term ne ''){
			my $s_term = &setTerm($$data{start_date},$$data{last_reference_date},$term);
			unless($now > $s_term){$$data{last_update_date} = $s_term;}
		}
		
		my $s_rtn = &setSessionData($dbh,$s_name,$s_id,$data);
		if($s_rtn == -1){return(-3);} # Abend
		if($s_rtn == 0){return(-2);} # Not Found
		
		return(1);
	}

}

#-----------------------------------------------------------------------------#
# scalar2hash : Scalar To Hash
#-----------------------------------------------------------------------------#
# [Input]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
# [Output]
#  %hash : Hash
#-----------------------------------------------------------------------------#
sub scalar2hash{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($scalar) = @_;
	my %hash;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#
	
	foreach my $row(split(/\n/,$scalar)){
		$row =~ /^([^=]*)=([^\n]*)/;
		my ($n,$v) = ($1,$2);
		if($n =~ /^([^\n]*)\[([^\n]*)\]/){
			if($2 =~ /[^0-9]*/){ # Hash
				$hash{$1}->{$2} = $v;
			}else{ # Array
				$hash{$1}->[$2] = $v;
			}
		}else{
			$hash{$n} = $v;
		}
	}
	
	return(%hash);

}

#-----------------------------------------------------------------------------#
# hash2scalar : Hash To Scalar
#-----------------------------------------------------------------------------#
# [Input]
#  %hash : Hash
#-----------------------------------------------------------------------------#
# [Output]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
sub hash2scalar{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my (%hash) = @_;
	my $scalar;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	while(my ($n,$v) = each(%hash)){
		if($v =~ /^ARRAY\([^\0]*\)/){
			for(my $i = 0;$i < (@$v);$i ++){
				$scalar .= "$n\[$i\]=$v->[$i]\n";
			}
		}elsif($v =~ /^HASH\([^\0]*\)/){
			while(my ($nn,$vv) = each(%$v)){
				$scalar .= "$n\{$nn\}=$vv\n";
			}
		}else{
			$scalar .= "$n=$v\n";
		}
	}
	
	return($scalar);

}

#-----------------------------------------------------------------------------#
# session_change : Change Session ID
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Old Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼,-4:�Ķ������ߥ�)
#  $new_s_id : New Session ID
#-----------------------------------------------------------------------------#
sub session_change{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id) = @_;
	my $now = &now();
	my $rtn;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my $chk = &session_check($dbh,$s_name,$s_id);
	if($chk != 1){
		return($chk);
	}else{
		my ($rtn,$data) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn == 0){
			return(-4);
		} # Abend
		if($data eq ''){
			return(-2);
		} # Not Found
		if($now > $$data{last_update_date}){
			return(0);
		} # Time is over.
		
		my $new_s_id = &makeSessionID();
		if(length($new_s_id) != $s_length){return(-3);}
		
		$$data{session_id} = $new_s_id;
		
		my $s_rtn = &setSessionData($dbh,$s_name,$s_id,$data);
		if($s_rtn == -1){return(-4);} # Abend
		if($s_rtn == 0){return(-2);} # Not Found
		
		return(1,$new_s_id);
		
	}

}

#-----------------------------------------------------------------------------#
# session_end : Session End
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#
sub session_end{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id) = @_;
	my $now = &now;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if(length($s_id) != $s_length){return(-1);}
	
	my $sql = "delete from $s_name$table_flg ";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	
	my $sth = &execQuery($dbh,$sql) ||
		return(0);
	
	if($sth->rows == 0){
		$rtn = -2;
	}else{
		$rtn = 1;
	}
	$sth->finish;
	
	return($rtn);

}

#-----------------------------------------------------------------------------#
#  Local Subroutines
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# getSessionData : Get Session Data
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : Result(1:OK,0:NG)
#  $rs : ResultSet
#-----------------------------------------------------------------------------#
sub getSessionData{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my $sql = "select " . join(',',@fields) . " from $s_name$table_flg";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &execQuery($dbh,$sql) ||
		return(0);
	my $rs = $sth->fetchrow_hashref;
	$sth->finish;
	
	return(1,$rs);

}

#-----------------------------------------------------------------------------#
# setSessionData : Set Session Data
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $data : Data
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : Result(1:OK,0:Can't Set,-1:Abend)
#-----------------------------------------------------------------------------#
sub setSessionData{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$s_name,$s_id,$data) = @_;
	my $rtn;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my $sql = "update $s_name$table_flg set ";
	foreach(@fields){
		$sql .= " $_ = " . $dbh->quote($$data{$_}) . ",";
	}
	chop($sql);
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &execQuery($dbh,$sql) ||
		return(-1);
	if($sth->rows == 0){
		$rtn = 0;
	}else{
		$rtn = 1;
	}
	$sth->finish;
	
	return($rtn);

}

#-----------------------------------------------------------------------------#
# makeSessionID : Make Session ID
#-----------------------------------------------------------------------------#
# [Input]
#  None
#-----------------------------------------------------------------------------#
# [Output]
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
sub makeSessionID{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#



    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my $s_id;
	foreach(split(/\./,$ENV{SERVER_ADDR})){
		$s_id .= sprintf("%02x",$_);
	}
#1.0.1#	srand(time ^ ($$ + ($ << 15)));
	srand(time ^ ($$ + ($$ << 15)));                                    #1.0.1#
	$s_id .= sprintf("%02d",int(rand(100)));
	$s_id .= sprintf("%02d",int(rand(100)));
	foreach(split(/\./,$ENV{REMOTE_ADDR})){
		$s_id .= sprintf("%02x",$_);
	}
	if($ENV{UNIQUE_ID} ne '' &&
		length($ENV{UNIQUE_ID}) == 19){ # UNIQUE ID��¸�ߤ�19��ΤȤ�
		$s_id .= $ENV{UNIQUE_ID};
	}else{ # ����¾
		$s_id .= sprintf("%011d",time);
		$s_id .= sprintf("%08d",$$);
	}
	
	return($s_id);


}

#-----------------------------------------------------------------------------#
# setTerm : ���ꤷ��ͭ�����¤�����
#-----------------------------------------------------------------------------#
# [Input]
#  $s_date : Session������
#  $a_date : �ǽ�������������
#  $term : ͭ������
#-----------------------------------------------------------------------------#
# [Output]
#  $t_date : ͭ����������
#-----------------------------------------------------------------------------#
sub setTerm{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_date,$a_date,$term) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if(length($term) == 14){ # ���ջ���
		$term =~ /(....)(..)(..)(..)(..)(..)/;
		if(check_date($1,$2,$3)){
			if(($4 >= 0 && $4 < 24) && ($5 >= 0 && $5 < 60) && ($6 >= 0 && $6 < 60)){
				return($term);
			}
		}
	}else{ # ���л���
		$term =~ /^(S|L)([0-9]*)(D|H|M|S)$/;
		if($1 ne '' && $3 ne ''){
			my $date;
			if($1 eq 'S'){
				$date = $s_date;
			}elsif($1 eq 'L'){
				$date = $a_date;
			}
			my ($dd,$dh,$dm,$ds) = (0,0,0,0);
			if($3 eq 'D'){
				$dd = $2;
			}elsif($3 eq 'H'){
				$dh = $2;
			}elsif($3 eq 'M'){
				$dm = $2;
			}elsif($3 eq 'S'){
				$ds = $2;
			}
			$date =~ /^(....)(..)(..)(..)(..)(..)/;
#2.0.0#			my ($y,$m,$d,$hh,$mm,$ss) = calc_new_date_time($1,$2,$3,$4,$5,$6,$dd,$dh,$dm,$ds);
			my ($y,$m,$d,$hh,$mm,$ss) = &Date::Calc::Add_Delta_DHMS($1,$2,$3,$4,$5,$6,$dd,$dh,$dm,$ds);	#2.0.0#
			return(sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss));
		}
	}

}

#-----------------------------------------------------------------------------#
# now : �����֤����
#-----------------------------------------------------------------------------#
# [Input]
#  None
#-----------------------------------------------------------------------------#
# [Output]
#  $now : ������(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub now{


    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my ($ss,$mm,$hh,$d,$m,$y,$wd,$yd,$ist) = localtime(time);
	
	$y = $y + 1900;
	$m ++;
	my $now = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	return($now);
	

}

#-----------------------------------------------------------------------------#
# execQuery : �����꡼�¹�
#-----------------------------------------------------------------------------#
# [Input]
#  $dbh : DB Handler
#  $sql : SQL
#-----------------------------------------------------------------------------#
# [Output]
#  $sth : Statement Handler
#-----------------------------------------------------------------------------#
sub execQuery{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($dbh,$sql) = @_;
	my $sth;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if(($sth = $dbh->prepare($sql)) && ($sth->execute)){
		return($sth);
	}

}


1;
