package Cookie;
#----------------------------------------------------------------------------#
#     Client Name    :  ���ѥ饤�֥��
#     Project Name   :  Cookie �饤�֥��
#     Program Name   :  Cookie.pl
#     Create Date    :  2000.01.23
#     Programmer     :  Waragai  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  any programs 
#     Notice         :  This File Code is EUC
#     Copyright      :  2000 DNP DigitalCom CO.,LTD.
#----------------------------------------------------------------------------#
#     verison  1.0.0 :  2000.01.23 (wara)     New Create
#     verison  2.0.0 :  2000.01.29 (wara)     ���åȥɥᥤ���ѹ�
#     verison  2.0.1 :  2001.02.26 (wara)     ���åȥɥᥤ��BUG !!
#     verison  2.1.1 :  2003.01.15 (maru)     �ɥᥤ�����Υ��å������å��ɲ�
#     verison  2.2.1 :  2003.02.22 (ayako)    ǯ������ʬ�û���δؿ��ɲ�
#     verison  2.3.1 :  2003.08.22 (maru)     secure�ؿ��ɲ�
#     verison  2.4.1 :  2003.10.16 (y.ueda)   secure�ɥᥤ�����ؿ��ɲ�
#     verison  2.5.1 :  2003.11.14 (maru)     ���ڤ��֥��ߥ�����ܥ��ڡ�����
#     verison  2.5.2 :  2004.05.27 (maru)     �����Υ��ߥ��������
#     verison  2.6.2 :  2004.07.20 (maru)     CSS�к����ɲ�
#     verison  2.7.2 :  2004.09.08 (maru)     secure�ؿ��ɲ�
#     version  2.7.3 :  2014.08.05 (y.washizu)MGCLOUD�ܹԤ�ȼ��Date::DateCalc�λ��ͤ�ػ�
#     version  2.7.4 :  2016.01.26 (y.washizu)dates_difference���ѤǤ��ʤ�����Cookie2.pl�˴󤻤�
#-----------------------------------------------------------------------------#
#   [1] ���å����Υ��å�
#        &Cookie::set_cookie ( $name,$value,$expires )
#            $name    : ����̾
#            $value   : ���å�����
#            $expires : ͭ�������� (��ά��) ͭ��������������ñ�̤ǥ��å�
#        ��ɬ��content-type�����˥��åȤ���
#-----------------------------------------------------------------------------#
#   [2] ���å����μ��Ф�
#        $cookie = &Cookie::get_cookie ( $kmk_name );
#            $kmk_name : ���Ф��������å����ι���̾
#            $cookie   : ���Ф��ǡ��� ( return ) 
#-----------------------------------------------------------------------------#
#   [3] ���å����Υ��åȡʥɥᥤ������
#        &Cookie::set_cookie_domain ( $domain,$name,$value,$expires )
#            $domain  : �ɥᥤ��
#            $name    : ����̾
#            $value   : ���å�����
#            $expires : ͭ�������� (��ά��) ͭ��������������ñ�̤ǥ��å�
#-----------------------------------------------------------------------------#
#   [4] ���å����Υ��åȡ�secure�С�������                            #2.3.1#
#        &Cookie::set_cookie_secure ( $name,$value,$expires )
#            $name    : ����̾
#            $value   : ���å�����
#            $expires : ͭ�������� (��ά��) ͭ��������������ñ�̤ǥ��å�
#-----------------------------------------------------------------------------#
#   [5] ���å����Υ��åȡ�secure�ɥᥤ�����С�������                #2.4.1#
#        &Cookie::set_cookie_secure_domain ( $domain,$name,$value,$expires )
#            $domain  : �ɥᥤ��
#            $name    : ����̾
#            $value   : ���å�����
#            $expires : ͭ�������� (��ά��) ͭ��������������ñ�̤ǥ��å�
#-----------------------------------------------------------------------------#
#2.7.3#use Date::DateCalc;            #2.2.1#
#2.7.3#use Date::DateCalc qw(:all);   #2.2.1#
use Date::Calc;            #2.7.3#
use Date::Calc qw(:all);   #2.7.3#
#-----------------------------------------------------------------------------#
#    set_cookie : ���å����ǡ�������¸
#-----------------------------------------------------------------------------#
sub set_cookie {
    local( $name, $value, $expires ) = @_; 
    local( $cookie, $domain, $wk_expires, @dom );     

	$value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
	$value =~ s/ /+/g;
	if ( defined $expires && $expires =~ /^\d+$/ ){
		$wk_expires = &get_expire( $expires );
	}
	if ( $ENV{'HTTP_HOST'} =~ /:\d+$/ ){ $domain = $`; }         
	else                               { $domain = $ENV{'HTTP_HOST'}; }    
	if ( $domain ){                                                     #2.0.0#
		@dom = split(/\./,$domain);                                     #2.0.0#
#2.0.1#		if ( @dom > 3 ){                                            #2.0.0#
#2.0.1#			$domain = join('.',splice(@dom,-3));                    #2.0.0#
#2.0.1#			$domain = '.' . $domain;                                #2.0.0#
#2.0.1#		}                                                           #2.0.0#
		$domain = join( '.',splice( @dom,$#dom * -1 ) );                #2.0.1#
		$domain = '.' . $domain;                                        #2.0.1#
	}                                                                   #2.0.0#

#2.5.1#	$cookie = "Set-Cookie:";
#2.5.1#	$cookie .= "$name=$value;";
#2.5.1#	$cookie .= "expires=$wk_expires;" if $wk_expires; 
#2.5.1#	$cookie .= "domain=$domain;" if $domain;
#2.5.1#	$cookie .= "path=/;\n";

	$cookie = "Set-Cookie: ";                                           #2.5.1#
	$cookie .= "$name=$value; ";                                        #2.5.1#
	$cookie .= "expires=$wk_expires; " if $wk_expires;                  #2.5.1#
	$cookie .= "domain=$domain; " if $domain;                           #2.5.1#
#2.5.2#	$cookie .= "path=/; \n";                                            #2.5.1#
	$cookie .= "path=/\n";                                              #2.5.2#

	print "$cookie"; 

    return( $cookie );
}

#-----------------------------------------------------------------------------#
#    set_cookie_secure : ���å����ǡ�������¸��secure�С�������
#-----------------------------------------------------------------------------#
sub set_cookie_secure {                                                 #2.3.1#
    local( $name, $value, $expires ) = @_; 
    local( $cookie, $domain, $wk_expires, @dom );     

	$value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
	$value =~ s/ /+/g;
	if ( defined $expires && $expires =~ /^\d+$/ ){
		$wk_expires = &get_expire( $expires );
	}
	if ( $ENV{'HTTP_HOST'} =~ /:\d+$/ ){ $domain = $`; }         
	else                               { $domain = $ENV{'HTTP_HOST'}; }    
	if ( $domain ){
		@dom = split(/\./,$domain);
		$domain = join( '.',splice( @dom,$#dom * -1 ) );
		$domain = '.' . $domain;
	}

#2.5.1#	$cookie = "Set-Cookie:";
#2.5.1#	$cookie .= "$name=$value;";
#2.5.1#	$cookie .= "expires=$wk_expires;" if $wk_expires; 
#2.5.1#	$cookie .= "domain=$domain;" if $domain;
#2.5.1#	$cookie .= "path=/;";
#2.5.1#	$cookie .= "secure\n";

	$cookie = "Set-Cookie: ";                                           #2.5.1#
	$cookie .= "$name=$value; ";                                        #2.5.1#
	$cookie .= "expires=$wk_expires; " if $wk_expires;                  #2.5.1#
	$cookie .= "domain=$domain; " if $domain;                           #2.5.1#
	$cookie .= "path=/; ";                                              #2.5.1#
	$cookie .= "secure\n";                                              #2.5.1#

	print "$cookie"; 

    return( $cookie );
}

#--- 2.1.1 -------------------------------------------------------------------#
#    set_cookie_domain : ���å����ǡ�������¸�ʥɥᥤ������
#-----------------------------------------------------------------------------#
sub set_cookie_domain {
    local( $domain, $name, $value, $expires ) = @_; 
    local( $cookie, $wk_expires, @dom );     

	$value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
	$value =~ s/ /+/g;
	if ( defined $expires && $expires =~ /^\d+$/ ){
		$wk_expires = &get_expire( $expires );
	}

#2.5.1#	$cookie = "Set-Cookie:";
#2.5.1#	$cookie .= "$name=$value;";
#2.5.1#	$cookie .= "expires=$wk_expires;" if $wk_expires; 
#2.5.1#	$cookie .= "domain=$domain;" if $domain;
#2.5.1#	$cookie .= "path=/;\n";

	$cookie = "Set-Cookie: ";                                           #2.5.1#
	$cookie .= "$name=$value; ";                                        #2.5.1#
	$cookie .= "expires=$wk_expires; " if $wk_expires;                  #2.5.1#
	$cookie .= "domain=$domain; " if $domain;                           #2.5.1#
#2.5.2#	$cookie .= "path=/; \n";                                            #2.5.1#
	$cookie .= "path=/\n";                                              #2.5.2#

	print "$cookie"; 

    return( $cookie );
}
#-----------------------------------------------------------------------------#
#    set_cookie_secure_domain : ���å����ǡ�������¸�ʥɥᥤ������
#-----------------------------------------------------------------------------#
sub set_cookie_secure_domain {                                          #2.4.1#
    local( $domain, $name, $value, $expires ) = @_; 
    local( $cookie, $wk_expires, @dom );     

	$value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
	$value =~ s/ /+/g;
	if ( defined $expires && $expires =~ /^\d+$/ ){
		$wk_expires = &get_expire( $expires );
	}

#2.5.1#	$cookie = "Set-Cookie:";
#2.5.1#	$cookie .= "$name=$value;";
#2.5.1#	$cookie .= "expires=$wk_expires;" if $wk_expires; 
#2.5.1#	$cookie .= "domain=$domain;" if $domain;
#2.5.1#	$cookie .= "path=/;";
#2.5.1#	$cookie .= "secure\n";

	$cookie = "Set-Cookie: ";                                           #2.5.1#
	$cookie .= "$name=$value; ";                                        #2.5.1#
	$cookie .= "expires=$wk_expires; " if $wk_expires;                  #2.5.1#
	$cookie .= "domain=$domain; " if $domain;                           #2.5.1#
	$cookie .= "path=/; ";                                              #2.5.1#
	$cookie .= "secure\n";                                              #2.5.1#

	print "$cookie"; 

    return( $cookie );
}

#-----------------------------------------------------------------------------#
#    get_cookie : ���å����ǡ����μ���
#-----------------------------------------------------------------------------#
sub get_cookie {
    local( $kmk_name ) = shift;
    local( $tmp,$name,$value ); 

    for $tmp (split(/; */, $ENV{'HTTP_COOKIE'})) {
        ($name, $value) = split(/=/, $tmp);
        $name  =~ tr/+/ /;
        $name  =~ s/%(..)/pack("C", hex($1))/eg;
        $value =~ tr/+/ /;
        $value =~ s/%(..)/pack("C", hex($1))/eg;
        if ( $name eq $kmk_name ){ return( $value ); }
    }
    return( 0 ); 
}

#-----------------------------------------------------------------------------#
#    get_cookie_css : ���å����ǡ����μ�����CSS�к��ǡ�                 #2.6.2#
#-----------------------------------------------------------------------------#
sub get_cookie_css {
    local( $kmk_name ) = shift;
    local( $tmp,$name,$value ); 

    for $tmp (split(/; */, $ENV{'HTTP_COOKIE'})) {
        ($name, $value) = split(/=/, $tmp);
        $name  =~ tr/+/ /;
        $name  =~ s/%(..)/pack("C", hex($1))/eg;
        $value =~ tr/+/ /;
        $value =~ s/%(..)/pack("C", hex($1))/eg;
        if ( $name eq $kmk_name ){
			$value =~ s/"/��/g;
			$value =~ s/'/��/g;
			$value =~ s/</��/g;
			$value =~ s/>/��/g;
			return( $value );
		}
    }
    return( 0 ); 
}

#-----------------------------------------------------------------------------#
#   get_expire : ���դ����Sun,22-Mar-1988 09:30:45 GMT�פη������Ѵ�����
#-----------------------------------------------------------------------------#
sub get_expire {
    local( $days_later ) = @_; 
    local( $sec,$min,$hour,$mday,$mon,$year,$wday )
		= gmtime(time + int($days_later*60*60*24));

    $mon = ("Jan","Feb","Mar","Apr","May","Jun"
           ,"Jul","Aug","Sep","Oct","Nov","Dec")[$mon];
    $wday = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")[$wday];

    sprintf( "$wday, %2.2d-$mon-%4.4d %2.2d:%2.2d:%2.2d GMT"
			 ,$mday,$year+1900,$hour,$min,$sec);
}

#--- 2.2.1 -------------------------------------------------------------------#
#    set_cookie_expires : ���å����ǡ�������¸�����ջ��֤�����
#-----------------------------------------------------------------------------#
sub set_cookie_expires {
    local( $name, $value, $expires ) = @_;
    local( $cookie, $domain, $wk_expires, @dom );
        
    $value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
    $value =~ s/ /+/g;
    if ( defined $expires && $expires =~ /^\d+$/ ){
        $wk_expires = &get_expire2( $expires ); #2.2.1#set_cookie�Ȥ��������㤦
    }
    if ( $ENV{'HTTP_HOST'} =~ /:\d+$/ ){ $domain = $`; }
    else                               { $domain = $ENV{'HTTP_HOST'}; }
    if ( $domain ){                                                     
        @dom = split(/\./,$domain);                                     
        $domain = join( '.',splice( @dom,$#dom * -1 ) );                
        $domain = '.' . $domain;                                        
    }                                                                   
#print "Content-type: text/html\n\n";
#2.5.1#    $cookie = "Set-Cookie:";
#2.5.1#    $cookie .= "$name=$value;";
#2.5.1#    $cookie .= "expires=$wk_expires;" if $wk_expires;
#2.5.1#    $cookie .= "domain=$domain;" if $domain;
#2.5.1#    $cookie .= "path=/;\n";

    $cookie = "Set-Cookie: ";                                           #2.5.1#
    $cookie .= "$name=$value; ";                                        #2.5.1#
    $cookie .= "expires=$wk_expires; " if $wk_expires;                  #2.5.1#
    $cookie .= "domain=$domain; " if $domain;                           #2.5.1#
#2.5.2#    $cookie .= "path=/; \n";                                            #2.5.1#
    $cookie .= "path=/\n";                                              #2.5.2#

    print "$cookie";

    return( $cookie );
}


#--- 2.2.1 -------------------------------------------------------------------#
#    set_cookie_domain_expires : ���å����ǡ�������¸�ʥɥᥤ���������ջ��ֻ����
#-----------------------------------------------------------------------------#
sub set_cookie_domain_expires {
    local( $domain, $name, $value, $expires ) = @_;
    local( $cookie, $wk_expires, @dom );

        $value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
        $value =~ s/ /+/g;
        if ( defined $expires && $expires =~ /^\d+$/ ){
                $wk_expires = &get_expire2( $expires ); #2.2.1#set_cookie_domain�Ȥ��������㤦
        }

#2.5.1#        $cookie = "Set-Cookie:";
#2.5.1#        $cookie .= "$name=$value;";
#2.5.1#        $cookie .= "expires=$wk_expires;" if $wk_expires;
#2.5.1#        $cookie .= "domain=$domain;" if $domain;
#2.5.1#        $cookie .= "path=/;\n";

        $cookie = "Set-Cookie: ";                                       #2.5.1#
        $cookie .= "$name=$value; ";                                    #2.5.1#
        $cookie .= "expires=$wk_expires; " if $wk_expires;              #2.5.1#
        $cookie .= "domain=$domain; " if $domain;                       #2.5.1#
#2.5.2#        $cookie .= "path=/; \n";                                        #2.5.1#
        $cookie .= "path=/\n";                                          #2.5.2#

        print "$cookie";

    return( $cookie );
}

#--- 2.7.2 -------------------------------------------------------------------#
#    set_cookie_expires_secure : ���å����ǡ�������¸�����ջ��֤�����
#-----------------------------------------------------------------------------#
sub set_cookie_expires_secure {
    local( $name, $value, $expires, $path ) = @_;
    local( $cookie, $domain, $wk_expires, @dom );
        
    $value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
    $value =~ s/ /+/g;
    if ( defined $expires && $expires =~ /^\d+$/ ){
        $wk_expires = &get_expire2( $expires ); #2.2.1#set_cookie�Ȥ��������㤦
    }
    if ( $ENV{'HTTP_HOST'} =~ /:\d+$/ ){ $domain = $`; }
    else                               { $domain = $ENV{'HTTP_HOST'}; }
    if ( $domain ){                                                     
        @dom = split(/\./,$domain);                                     
        $domain = join( '.',splice( @dom,$#dom * -1 ) );                
        $domain = '.' . $domain;
    }                                                                   

    if ( $path eq '' ) { $path = "/"; }

    $cookie = "Set-Cookie: ";
    $cookie .= "$name=$value; ";
    $cookie .= "expires=$wk_expires; " if $wk_expires;
    $cookie .= "domain=$domain; " if $domain;
    $cookie .= "path=$path; ";
	$cookie .= "secure\n";

    print "$cookie";

    return( $cookie );
}


#--- 2.7.2 -------------------------------------------------------------------#
#    set_cookie_domain_expires_secure : ���å����ǡ�������¸�ʥɥᥤ���������ջ��ֻ����
#-----------------------------------------------------------------------------#
sub set_cookie_domain_expires_secure {
    local( $domain, $name, $value, $expires, $path ) = @_;
    local( $cookie, $wk_expires, @dom );

    $value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
    $value =~ s/ /+/g;
    if ( defined $expires && $expires =~ /^\d+$/ ){
        $wk_expires = &get_expire2( $expires ); #2.2.1#set_cookie_domain�Ȥ��������㤦
    }

    if ( $path eq '' ) { $path = "/"; }

    $cookie = "Set-Cookie: ";
    $cookie .= "$name=$value; ";
    $cookie .= "expires=$wk_expires; " if $wk_expires;
    $cookie .= "domain=$domain; " if $domain;
    $cookie .= "path=$path; ";
	$cookie .= "secure\n";

    print "$cookie";

    return( $cookie );
}

#--- 2.2.1 -------------------------------------------------------------------#
#   get_expire2 : ���ջ��֤����Sun,22-Mar-1988 09:30:45 GMT�פη������Ѵ�����
#-----------------------------------------------------------------------------#
sub get_expire2 {
    local( $set_date ) = @_;
    local( $diff_days, $tm );

    #---- ǯ������ʬ�äˤ櫓�� ----#
    local( $set_year, $set_month, $set_day, $set_hour, $set_min, $set_sec ) =
        ( $set_date =~ /^(\d\d\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)/ ); 
#2.7.4#    #---- �����ä򻻽Ф�������ܤ�GMT���9���֤���Ƥ����----#
#2.7.4#    $diff_days = dates_difference( '1970','01','01',$set_year, $set_month, $set_day);
#2.7.4#    $tm = $diff_days*60*60*24 + $set_hour*60*60 + $set_min*60 + $set_sec - 9*60*60;    

    #---add #2.7.4#--������--------------------#
    #---- �����ä򻻽Ф�������ܤ�GMT���9���֤���Ƥ����----#
    $diff_days = &Date::Calc::Delta_Days
                    ( '1970','01','01',$set_year, $set_month, $set_day);
    $tm = $diff_days*60*60*24 + $set_hour*60*60 + $set_min*60 + $set_sec - 9*60*60;
    #---add #2.7.4#--������--------------------#

    local( $sec,$min,$hour,$mday,$mon,$year,$wday ) = gmtime("$tm");

    $mon = ("Jan","Feb","Mar","Apr","May","Jun"
           ,"Jul","Aug","Sep","Oct","Nov","Dec")[$mon];
    $wday = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")[$wday];

    sprintf( "$wday, %2.2d-$mon-%4.4d %2.2d:%2.2d:%2.2d GMT"
                         ,$mday,$year+1900,$hour,$min,$sec);
}

1;
