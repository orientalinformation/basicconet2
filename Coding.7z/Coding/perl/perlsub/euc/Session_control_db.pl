package Session_control_db;
#-----------------------------------------------------------------------------#
#    Client Name   : ����
#    System Name   : CPS���ѥ饤�֥��
#    Project Name  : ���å���󥳥�ƥ�����饤�֥�� DB��
#    Program Name  : Session_control_db.pl
#    Create Date   : 2004.06.25
#    Programmer    : Y.Sugioka (Pro.DigitalCom.DNP)
#    Entry Server  : All Sever
#    Called By     : All Programs
#    File Code     : EUC
#    Execute Env   : EUC
#    Copyright     : 2004 DNP.DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#    version 1.0.0 : 2004.06.25 (Y.Sugioka)  New Create
#    version 1.0.1 : 2005.05.26 (Y.Sugioka)  Ʊ�쥢����������update�Զ���б�
#    version 1.0.2 : 2005.08.26 (sugi)       ����μ��������륿���ߥ��ѹ�
#    version 1.0.3 : 2006.06.15 (maru)       vodafone 3Gü���б�
#    version 1.0.4 : 2006.08.22 (ysakurai)   255 byte ��Ķ���� user_agent �б�
#    version 1.1.4 : 2006.08.30 (sugi)       SoftBank�б�
#    version 1.2.4 : 2010.04.05 (Y.Nagaoka)  UserAgentȽ����
#-----------------------------------------------------------------------------#
#    comment       : ���å��������饤�֥�� DB��
#                    ���å���������ˡ�ˤĤ��Ƥ϶�ͭʸ��򤴻��Ȥ���������
#                    PHP�Υ饤�֥��ȴ����ߴ����Ƥ��ޤ���
#-----------------------------------------------------------------------------#
#    history       : /WWW/CGI/perlsub/SessionDB2.pl
#-----------------------------------------------------------------------------#
# [1] session_start : ���å���󥹥�����
#
#     ($rtn,$s_id) = &Session_control_db::session_start($dbh,$s_name,$term);
#
# [Input]
#     $dbh........DB�ϥ�ɥ�
#     $s_name.....���å����̾
#     $term.......ͭ������
# [Output]
#     $rtn........���(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:Session IDȯ�ԥ��顼)
#��   $s_id.......���å����ID
#-----------------------------------------------------------------------------#
# [2] session_check : ���å��������å�
#
#     $rtn = &Session_control_db::session_check($dbh,$s_name,$s_id);
#
# [Input]
#     $dbh........DB�ϥ�ɥ�
#     $s_name.....���å����̾
#     $s_id.......���å����ID
# [Output]
#     $rtn........���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�,-3:�۾ｪλ)
#-----------------------------------------------------------------------------#
# [3] container_get : ����ƥʤ���Υǡ�������
#
#     ($rtn,$in_code,$data) = &Session_control_db::container_get($dbh,$s_name,$s_id,$term[,$ot_code]);
#
# [Input]
#     $dbh........DB�ϥ�ɥ�
#     $s_name.....���å����̾
#     $s_id.......���å����ID
#     $term.......ͭ������
#     $ot_code....���Ф���Υǡ���ʸ��������(��ά��)
# [Output]
#     $rtn........���(1:����,0:ͭ�������ڤ�,-1:������Session ID,-2:����ƥ��Ժ�,-3:�۾ｪλ)
#     $in_code....����ƥʥǡ���ʸ��������
#     $data.......���å�������ʥ����顼��
#-----------------------------------------------------------------------------#
# [4] container_set : ����ƥʥǡ���������
#
#     $rtn = &Session_control_db::container_set($dbh,$s_name,$s_id,$code,$d_area,$term);
#
# [Input]
#     $dbh........DB�ϥ�ɥ�
#     $s_name.....���å����̾
#     $s_id.......���å����ID
#     $code.......�ǡ���ʸ��������
#     $d_area.....���å�������ʥ����顼��
#     $term.......ͭ������
# [Output]
#     $rtn........���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
# [5] scalar2hash : �������ͤ�ϥå�����Ѵ�
#
#     %hash = &Session_control_db::scalar2hash($scalar);
#
# [Input]
#     $scalar.....�����顼�ǡ���
# [Output]
#     %hash.......�ϥå���ǡ���
#-----------------------------------------------------------------------------#
# [6] hash2scalar : �ϥå���򥹥����ͤ��Ѵ�
#
#     $scalar = &Session_control_db::hash2scalar(%hash);
#
# [Input]
#     %hash.......�ϥå���ǡ���
# [Output]
#     $scalar.....�����顼�ǡ���
#-----------------------------------------------------------------------------#
# [7] session_change : Session ID�ѹ�
#
#     ($rtn,$new_s_id) = &Session_control_db::session_change($dbh,$s_name,$s_id);
#
# [Input]
#     $dbh........DB�ϥ�ɥ�
#     $s_name.....���å����̾
#     $s_id.......�ѹ������å����ID
# [Output]
#     $rtn........���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼,-4:�Ķ������ߥ�)
#     $new_s_id...�ѹ��奻�å����ID
#-----------------------------------------------------------------------------#
# [8] session_end : Session ��λ
#
#     $rtn = &Session_control_db::session_end($dbh,$s_name,$s_id);
#
# [Input]
#     $dbh........DB�ϥ�ɥ�
#     $s_name.....���å����̾
#     $s_id.......���å����ID
# [Output]
#     $rtn........���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#

use Jcode;
use DBD::mysql;
use Date::Calc qw( check_date Add_Delta_DHMS );
use Time::Local;

&initial_setting();

#-----------------------------------------------------------------------------#
#    sub init : Initial Setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	#---- XSS�к� ----#
	my @env = qw(
				 SCRIPT_FILENAME HTTP_USER_AGENT HTTP_X_JPHONE_COLOR
				 HTTP_X_UP_SUBNO REMOTE_ADDR SERVER_ADDR UNIQUE_ID
				);

	foreach ( @env ) {
		$ENV{$_} =~ s/\</\&lt\;/g;
		$ENV{$_} =~ s/\>/\&gt\;/g;
		$ENV{$_} =~ s/\"/\&quot\;/g;
		$ENV{$_} =~ s/\'/\&\#39\;/g;
	}


	if( $ENV{'SCRIPT_FILENAME'} =~ m#[\w+]/(CGI|SCGI)/([^/]+)# ) {
		$hin_dir = $2;
	} elsif( $2 =~ /-bin/ ) {
		$hin_dir = $`;
	} else {
		print "Content-type:text/plain;charset=Shift_JIS\n\n";
		print "Can't execute Session_control_db.pl!!\n";
	}

	$s_length = 33; # Session ID's Length

	@fields = qw(
		session_id start_date last_reference_date last_update_date
		delete_date get_cnt set_cnt data_code remote_addr user_agent data_area
	); # Container's Data Fields

	#---- Check carrier ----#
	$table_flg = '_w';
	if( $ENV{'HTTP_USER_AGENT'} =~ /^DoCoMo/ ) {
		$table_flg = '_i';
#1.0.3#	}elsif( $ENV{'HTTP_X_JPHONE_COLOR'} ne '' ) {
	}elsif($ENV{HTTP_USER_AGENT} =~ /^J-PHONE/                          #1.0.3#
		   || $ENV{HTTP_USER_AGENT} =~ /^Vodafone/                      #1.0.3#
		   || $ENV{HTTP_USER_AGENT} =~ /^MOT-/                          #1.1.4#
		   || $ENV{HTTP_USER_AGENT} =~ /^SoftBank/                      #1.1.4#
		  ){                                                            #1.1.4#
#1.1.4#		   || $ENV{HTTP_USER_AGENT} =~ /^MOT-/ ){                   #1.0.3#
		$table_flg = '_j';
#1.0.3#	}elsif( $ENV{'HTTP_X_UP_SUBNO'} ne '' ) {
	}elsif($ENV{HTTP_USER_AGENT} =~ /^UP\.Browser/                      #1.0.3#
		   || $ENV{HTTP_USER_AGENT} =~ /^KDDI-/){                       #1.0.3#
		$table_flg = '_e';
	}

	#---- ����μ����� ----#
	srand(time ^ ($$ + ($$ << 15)));                                    #1.0.2#

	#---- HTTP_USER_AGENT ��Ƭ���� 255 byte ����� ----#
	$http_user_agent = substr( $ENV{HTTP_USER_AGENT}, 0, 255 );         #1.0.4#
}

#-----------------------------------------------------------------------------#
#    sub session_start : Session����Start!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:Session IDȯ�ԥ��顼)
#��  output : (2) Session ID
#-----------------------------------------------------------------------------#
sub session_start {
	my( $dbh, $s_name, $term ) = @_;
	my $now = &now();

	#---- Check Param ----#
	#-- Session Name --#
	if( $s_name eq '' )  { return(0); }

	#-- Term --#
	my $s_term = &setTerm($now, $now, $now, $term);
	if( $now > $s_term )  { return(-1); }

	#---- Make Session ID ----#
	my $s_id = &makeSessionID();
	if( length($s_id) != $s_length )  { return(-2); }

	#---- ���բ�timestamp���Ѵ� ----#
	$now = &chg_timestamp($now, 1);
	$s_term = &chg_timestamp($s_term, 1);

	#---- Make Session Container ----#
	my $sql = "insert into $s_name$table_flg set ";
	$sql .= "session_id = " . $dbh->quote($s_id) . ",";
	$sql .= 'start_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_reference_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_update_date = ' . $dbh->quote($now) . ",";
	$sql .= 'delete_date = ' . $dbh->quote($s_term) . ",";
	$sql .= 'get_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'set_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'data_code = ' . $dbh->quote('euc') . ",";
	$sql .= 'remote_addr = ' . $dbh->quote($ENV{'REMOTE_ADDR'}) . ",";
#1.0.4#	$sql .= 'user_agent = ' . $dbh->quote($ENV{'HTTP_USER_AGENT'}) . ",";
	$sql .= 'user_agent = ' . $dbh->quote($http_user_agent) . ",";      #1.0.4#
	$sql .= 'data_area = ' . $dbh->quote('');

	my $sth = &db_access($dbh, $sql) || return(0);
	$sth->finish;

	return( 1, $s_id );
}

#-----------------------------------------------------------------------------#
#    sub session_check : Session Check!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�,-3:�۾ｪλ)
#-----------------------------------------------------------------------------#
sub session_check {
	my( $dbh, $s_name, $s_id ) = @_;
	my $now = &now();

	#---- Check Session ID ----#
	if( $s_id eq '' || ( $s_id ne '' && length($s_id) != $s_length ) ) {
		return(-2);
	}

	#---- Search Session Container ----#
	my( $rtn, $rs ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn == 0 )                                     { return(-3); }
	if( $rs eq '' )                                     { return(-2); }
	#---- ͭ�����¤Υ����å� ----#
	if( $now > $$rs{'delete_date'} )                    { return(0); }
	#---- �桼������������ȤΥ����å� ----#
#1.0.4#	if( $ENV{'HTTP_USER_AGENT'} ne $$rs{'user_agent'} ) { return(-1); }
	#1.2.4#	if( $http_user_agent ne $$rs{'user_agent'} ) { return(-1); } #1.0.4#

	return(1);
}

#-----------------------------------------------------------------------------#
#    sub container_get : Get Container Data!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB�ϥ�ɥ�
#    input  : (2) ���å����̾
#    input  : (3) ���å����ID
#    input  : (4) ͭ������
#    input  : (5) ���Ф���Υǡ���ʸ��������(��ά��)
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:����,0:ͭ�������ڤ�,-1:������Session ID,-2:����ƥ��Ժ�,-3:�۾ｪλ)
#    output : (2) ����ƥʥǡ���ʸ��������
#    output : (3) Container Data(Scalar)
#-----------------------------------------------------------------------------#
sub container_get {
	my( $dbh, $s_name, $s_id, $term, $ot_code ) = @_;
	my $now = &now();

	#---- Check Session ----#
	my $chk = &session_check($dbh, $s_name, $s_id);
	if( $chk != 1 )  { return($chk); } # Error

	#---- Get Session Data ----#
	my( $rtn, $data ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn == 0 )    { return(-3); } # Abend
	if( $data eq '' )  { return(-2); } # Not Found

	#---- Set Attribute ----#
#1.0.1#	$$data{'get_cnt'} ++;
	$$data{'last_reference_date'} = $now;

	#---- ͭ�����¤�׻� ----#
	my $s_term = &setTerm($$data{'start_date'}, $$data{'last_reference_date'}, $$data{'last_update_date'}, $term);
	if( $now > $s_term )  { return(0); } # Time is Over.

	$$data{'delete_date'} = $s_term;

#1.0.1#	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data);
	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data, '1', '0'); #1.0.1#
	if( $s_rtn == -1 )  { return(-3); } # Abend
	if( $s_rtn == 0 )   { return(-2); } # Not Found

	#---- ����ƥʥǡ�����ʸ���������Ѵ� ----#
	if( $ot_code ne '' && $ot_code ne $$data{'data_code'} ) {
		$$data{'data_area'} = Jcode->new($$data{'data_area'}, $$data{'data_code'})->$ot_code;
	}

	return( 1, $$data{'data_code'}, $$data{'data_area'} );
}

#-----------------------------------------------------------------------------#
#    sub container_set : Set Container Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB�ϥ�ɥ�
#    input  : (2) ���å����̾
#    input  : (3) ���å����ID
#    input  : (4) �ǡ���ʸ��������
#    input  : (5) �ǡ���(��������)
#    input  : (6) ͭ������
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
sub container_set {
	my( $dbh, $s_name, $s_id, $code, $d_area, $term ) = @_;
	my $now = &now();

	#---- Check Session ----#
	my $chk = &session_check($dbh, $s_name, $s_id);
	if( $chk != 1 )  { return($chk); }

	my( $rtn, $data ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn != 1 )    { return(-3); } # Abend
	if( $data eq '' )  { return(-2); } # Not Found

	#---- Set Attribute ----#
#1.0.1#	$$data{'set_cnt'} ++;
	$$data{'last_reference_date'} = $now;
	$$data{'last_update_date'} = $now;
	$$data{'data_code'} = $code;
	$$data{'data_area'} = $d_area;

	#---- ͭ�����¤�׻� ----#
	my $s_term = &setTerm($$data{'start_date'}, $$data{'last_reference_date'}, $$data{'last_update_date'}, $term);
	if( $now > $s_term )  { return(0); } # Time is over.

	$$data{'delete_date'} = $s_term;

#1.0.1#	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data);
	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data, '0', '1'); #1.0.1#
	if( $s_rtn == -1 )  { return(-3); } # Abend
	if( $s_rtn == 0 )   { return(-2); } # Not Found

	return(1);
}

#-----------------------------------------------------------------------------#
#    sub scalar2hash : Scalar To Hash
#-----------------------------------------------------------------------------#
#    input  : (1) Scalar
#-----------------------------------------------------------------------------#
#    output : (1) Hash
#-----------------------------------------------------------------------------#
sub scalar2hash {
	my( $scalar ) = @_;
	my %hash;

	$scalar =~ s/\r\n/\n/g;
	$scalar =~ s/\r/\n/g;
	foreach my $row ( split(/\n/, $scalar ) ) {
		$row =~ /^([^=]*)=([^\n]*)/;
		my ($n, $v) = ($1, $2);
		if( $n =~ /^([^\n]*)\[([^\n]*)\]/ ) {         # Array
			$hash{$1}->[$2] = $v;
		} elsif( $n =~ /^([^\n]*)\{([^\n]*)\}/ ) {    # Hash
			$hash{$1}->{$2} = $v;
		} else {
			$hash{$n} = $v;
		}
	}

	return(%hash);
}

#-----------------------------------------------------------------------------#
#    sub hash2scalar : Hash To Scalar
#-----------------------------------------------------------------------------#
#    input  : (1) Hash
#-----------------------------------------------------------------------------#
#    output : (1) Scalar
#-----------------------------------------------------------------------------#
sub hash2scalar {
	my( %hash ) = @_;
	my $scalar;

	while( my( $n, $v ) = each(%hash) ) {
		if( $v =~ /^ARRAY\([^\0]*\)/ ) {
			for( my $i = 0; $i < (@$v); $i ++ ) {
				$scalar .= "$n\[$i\]=$v->[$i]\n";
			}
		} elsif( $v =~ /^HASH\([^\0]*\)/ ) {
			while( my( $nn, $vv ) = each(%$v) ) {
				$scalar .= "$n\{$nn\}=$vv\n";
			}
		} else {
			$scalar .= "$n=$v\n";
		}
	}

	return($scalar);
}

#-----------------------------------------------------------------------------#
#    sub session_change : Change Session ID
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Old Session ID
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼,-4:�Ķ������ߥ�)
#    output : (2) New Session ID
#-----------------------------------------------------------------------------#
sub session_change {
	my( $dbh, $s_name, $s_id ) = @_;

	my $chk = &session_check($dbh, $s_name, $s_id);
	if( $chk != 1 )  { return($chk); }

	my( $rtn, $data ) = &getSessionData($dbh, $s_name, $s_id);
	if( $rtn == 0 )    { return(-4); } # Abend
	if( $data eq '' )  { return(-2); } # Not Found

	my $new_s_id = &makeSessionID();
	if( length($new_s_id) != $s_length )  { return(-3); }

	$$data{'session_id'} = $new_s_id;

	my $s_rtn = &setSessionData($dbh, $s_name, $s_id, $data);
	if( $s_rtn == -1 )  { return(-4); } # Abend
	if( $s_rtn == 0 )   { return(-2); } # Not Found

	return( 1, $new_s_id );
}

#-----------------------------------------------------------------------------#
#    sub session_end : Session End
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#
sub session_end {
	my( $dbh, $s_name, $s_id ) = @_;
	my $now = &now();

	if( length($s_id) != $s_length )  { return(-1); }

	my $sql = "delete from $s_name$table_flg ";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &db_access( $dbh, $sql ) || return(0);
	if( $sth->rows == 0 )  { $rtn = -2; }
	else                   { $rtn = 1; }
	$sth->finish;

	return($rtn);
}

#-----------------------------------------------------------------------------#
#    Local Subroutines
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
#    sub getSessionData : Get Session Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) Result(1:OK,0:NG)
#    output : (2) ResultSet
#-----------------------------------------------------------------------------#
sub getSessionData {
	my( $dbh, $s_name, $s_id ) = @_;

	#---- �ǡ�������� ----#
	my $sql = "select " . join(',',@fields) . " from $s_name$table_flg";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &db_access($dbh, $sql) || return(0);
	my $rs = $sth->fetchrow_hashref;
	$sth->finish;

	#---- timestamp���Ѵ������� ----#
	if( $rs ) {                                                         #1.0.1#
		$rs->{'start_date'} = &chg_timestamp($rs->{'start_date'}, 2);
		$rs->{'last_update_date'} = &chg_timestamp($rs->{'last_update_date'}, 2);
		$rs->{'last_reference_date'} = &chg_timestamp($rs->{'last_reference_date'}, 2);
		$rs->{'delete_date'} = &chg_timestamp($rs->{'delete_date'}, 2);
	}                                                                   #1.0.1#

	return(1, $rs);
}

#-----------------------------------------------------------------------------#
#    sub setSessionData : Set Session Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#    input  : (4) Data
#    input  : (5) Get Count Up Flag
#    input  : (6) Set Count Up Flag
#-----------------------------------------------------------------------------#
#    output : (1) Result(1:OK,0:Can't Set,-1:Abend)
#-----------------------------------------------------------------------------#
sub setSessionData {
#1.0.1#	my( $dbh, $s_name, $s_id, $data ) = @_;
	my( $dbh, $s_name, $s_id, $data, $g_cnt, $s_cnt ) = @_;             #1.0.1#

	#---- ���բ�timestamp���Ѵ� ----#
	$data->{'start_date'} = &chg_timestamp($data->{'start_date'}, 1);
	$data->{'last_update_date'} = &chg_timestamp($data->{'last_update_date'}, 1);
	$data->{'last_reference_date'} = &chg_timestamp($data->{'last_reference_date'}, 1);
	$data->{'delete_date'} = &chg_timestamp($data->{'delete_date'}, 1);

	#---- �ǡ����򹹿� ----#
	my $sql = "update $s_name$table_flg set ";
	foreach( @fields ) {
		if( $_ eq 'get_cnt' ) {                                         #1.0.1#
			if( $g_cnt eq '1' ) {                                       #1.0.1#
				$sql .= " $_ = $_ + 1,"                                 #1.0.1#
			}                                                           #1.0.1#
		}                                                               #1.0.1#
		elsif( $_ eq 'set_cnt' ) {                                      #1.0.1#
			if( $s_cnt eq '1' ) {                                       #1.0.1#
				$sql .= " $_ = $_ + 1,"                                 #1.0.1#
			}                                                           #1.0.1#
		}                                                               #1.0.1#
		else {                                                          #1.0.1#
			$sql .= " $_ = " . $dbh->quote($$data{$_}) . ",";
		}                                                               #1.0.1#
	}
	chop($sql);
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &db_access($dbh, $sql) || return(-1);
	if( $sth->rows == 0 )  { $rtn = 0; }
	else                   { $rtn = 1; }
	$sth->finish;

	return($rtn);
}

#-----------------------------------------------------------------------------#
#    sub makeSessionID : Make Session ID
#-----------------------------------------------------------------------------#
#    output : (1) Session ID
#-----------------------------------------------------------------------------#
sub makeSessionID {

	my $s_id;
#1.0.2#	srand(time ^ ($$ + ($$ << 15)));
	$s_id .= sprintf("%02d", int(rand(100)));
	$s_id .= sprintf("%02d", int(rand(100)));
	$s_id .= sprintf("%02d", int(rand(100)));
	foreach( split(/\./,$ENV{'SERVER_ADDR'}) ) {
		$s_id .= sprintf("%02x", $_);
	}
	if( $ENV{'UNIQUE_ID'} ne '' &&
		length($ENV{'UNIQUE_ID'}) == 19 ) { # UNIQUE ID��¸�ߤ�19��ΤȤ�
		$s_id .= $ENV{'UNIQUE_ID'};
	} else { # ����¾
		$s_id .= sprintf("%011d", time);
		$s_id .= sprintf("%08d", $$);
	}

	return($s_id);
}

#-----------------------------------------------------------------------------#
#    sub setTerm : ���ꤷ��ͭ�����¤�����
#-----------------------------------------------------------------------------#
#    input  : (1) Session������
#    input  : (2) �ǽ�������������
#    input  : (3) �ǽ���������
#    input  : (4) ͭ������
#-----------------------------------------------------------------------------#
#    output : (1) ͭ����������
#-----------------------------------------------------------------------------#
sub setTerm{
	my( $s_date, $a_date, $u_date, $term ) = @_;

	if( length($term) == 14 ) { # ���ջ���
		$term =~ /(....)(..)(..)(..)(..)(..)/;
		if( &Date::Calc::check_date($1, $2, $3) ) {
			if( ( $4 >= 0 && $4 < 24 ) && ( $5 >= 0 && $5 < 60 ) && ( $6 >= 0 && $6 < 60 ) ) {
				return($term);
			}
		}
	} else { # ���л���
		$term =~ /^(S|L|U)([0-9]*)(D|H|M|S)$/;
		if( $1 ne '' && $3 ne '' ) {
			my $date;
			if( $1 eq 'S' )     { $date = $s_date; }
			elsif( $1 eq 'L' )  { $date = $a_date; }
			elsif( $1 eq 'U' )  { $date = $u_date; }
			my( $dd, $dh, $dm, $ds ) = ( 0, 0, 0, 0 );
			if( $3 eq 'D' )     { $dd = $2; }
			elsif( $3 eq 'H' )  { $dh = $2; }
			elsif( $3 eq 'M' )  { $dm = $2; }
			elsif( $3 eq 'S' )  { $ds = $2; }
			$date =~ /^(....)(..)(..)(..)(..)(..)/;
			my($y, $m, $d, $hh, $mm, $ss ) = &Date::Calc::Add_Delta_DHMS($1, $2, $3, $4, $5, $6, $dd, $dh, $dm, $ds);
			return( sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss) );
		}
	}
}

#-----------------------------------------------------------------------------#
#    sub now : �����֤����
#-----------------------------------------------------------------------------#
#    output : (1) ������(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub now {
	my( $ss, $mm, $hh, $d, $m, $y, $wd, $yd, $ist ) = localtime(time);

	$y = $y + 1900;
	$m ++;
	my $now = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	return($now);
}

#-----------------------------------------------------------------------------#
#    sub chg_timestamp : ���բ���timestamp�� �Ѵ�
#-----------------------------------------------------------------------------#
#    input  : (1) ����(YYYYMMDDhhmmss) or timestamp��
#    input  : (2) 1 = ���բ�timestamp�� �� 2 = timestamp�͢�����
#-----------------------------------------------------------------------------#
#    output : (1) timestamp�� or ����(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub chg_timestamp {
	my( $win, $flg ) = @_;
	my( $ss, $mm, $hh, $d, $m, $y, $wd, $yd, $ist, $wot );

	if( $flg == 1 ) {
		($y,$m,$d,$hh,$mm,$ss) = ( $win =~ /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/ );
		$y -= 1900;
		$m --;
		$wot = timelocal($ss,$mm,$hh,$d,$m,$y);
	} else {
		($ss,$mm,$hh,$d,$m,$y,$wd,$yd,$ist) = localtime($win);
		$y += 1900;
		$m ++;
		$wot = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	}

	return $wot;
}

#-----------------------------------------------------------------------------#
#   db_access : SQL�¹�
#-----------------------------------------------------------------------------#
#����input  : (1) DB�ϥ�ɥ�
#����input  : (2) SQLʸ
#-----------------------------------------------------------------------------#
#����output : (1) ���ơ��ȥ��ȥϥ�ɥ�
#-----------------------------------------------------------------------------#
sub db_access {

	my ($dbh, $sql_list) = @_;
	my ($sth);

	if ( !( ( $sth = $dbh->prepare("$sql_list") ) && ( $sth->execute ) ) ){
		return();
	}

	return( $sth );
}

1;
