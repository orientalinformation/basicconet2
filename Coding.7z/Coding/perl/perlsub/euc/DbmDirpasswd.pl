#-----------------------------------------------------------------------------#
#     Client Name    :  $B<RMQ(B
#     Project Name   :  Apache Directory Password $B@)8f%i%$%V%i%j(B (DBM)
#     Program Name   :  DbmDirpasswd.pl
#     Create Date    :  99.07.02
#     Programmer     :  wara (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  any programs
#     Notice         :  This File Code is EUC
#     Copyright      :  1999 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  : 1999.07.02 (wara)   New Create  (CPS1.0)
#     version 1.1.0  : 1999.11.01 (wara)   Null $B%G!<%?$N>l9g%(%i!<$H$9$k(B
#     version 1.2.0  : 1999.11.01 (wara)   $B%f!<%6$N:o=|5!G=DI2C(B
#     version 1.3.0  : 2005.03.31 (wara)   $B%m%C%/%U%!%$%k:o=|5!G=(B&strict$B=$@5(B
#     version 1.4.0  : 2005.03.31 (wara)   $B%m%C%/;n9T2s?t(B 5->15$B$XJQ99(B
#     version 1.5.0  : 2005.04.07 (wara)   $B!V(Bpassword_check$B!W4X?tDI2C(B
#-----------------------------------------------------------------------------#
#  [1] add_user $B%G%#%l%/%H%j%Q%9%o!<%IDI2C(B
#      $B0z?t(B1 $file_nm.... $B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $B0z?t(B2 $user....... $B%f!<%6L>(B
#      $B0z?t(B3 $passwd..... $B%Q%9%o!<%I(B
#      $BLa$jCM(B............ 1:$B@5>o=*N;(B 0:$B0[>o=*N;(B
#
#      $B!v%U%!%$%k$,B8:_$7$J$$>l9g!"?75,:n@.(B
#-----------------------------------------------------------------------------#
#  [2] upd_user $B%G%#%l%/%H%j%Q%9%o!<%I99?7(B
#      $B0z?t(B1 $file_nm.... $B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $B0z?t(B2 $user....... $B%f!<%6L>(B
#      $B0z?t(B3 $passwd..... $B%Q%9%o!<%I(B
#      $BLa$jCM(B............ 1:$B@5>o=*N;(B  0:$B0[>o=*N;(B
#
#      $B!v%f!<%6$,B8:_$7$J$$>l9g!"DI2C!#%U%!%$%k$,B8:_$7$J$$>l9g?75,:n@.(B
#-----------------------------------------------------------------------------#
#  [3] del_user $B%G%#%l%/%H%j%Q%9%o!<%I:o=|(B
#      $B0z?t(B1 $file_nm.... $B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $B0z?t(B2 $user....... $B%f!<%6L>(B
#      $BLa$jCM(B............ 1:$B@5>o=*N;(B  0:$B0[>o=*N;(B
#-----------------------------------------------------------------------------#
#  [4] find_user $B%f!<%68!:w(B
#      $B0z?t(B1 $file_nm.... $B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $B0z?t(B2 $user....... $B%f!<%6L>(B
#      $BLa$jCM(B............ 1:$B9gCW(B 0:$B9gCW$7$J$$(B -1:$B0[>o=*N;(B
#-----------------------------------------------------------------------------#
#  [5] get_password $B0E9f2=%Q%9%o!<%I$r<hF@(B ($B"(%a%$%s$+$i$ODL>o8F$S=P$5$J$$(B)
#      $B0z?t(B1 $pw........ $B%Q%9%o!<%I(B
#      $BLa$jCM(B .......... $B0E9f2=$7$?J8;zNs(B
#-----------------------------------------------------------------------------#
#  [6] password_check DBM$B$K@_Dj$5$l$F$$$k%Q%9%o!<%I$N@5Ev@-%A%'%C%/(B
#      $B0z?t(B1 $file_nm.... $B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $B0z?t(B2 $user....... $B%f!<%6L>(B
#      $B0z?t(B3 $pass ...... $B%Q%9%o!<%I(B 
#      $BLa$jCM(B............ 1:$B@5Ev(B 0:$BITEv(B -1:$B%f!<%6@_Dj$J$7(B -2:$B0[>o=*N;(B
#-----------------------------------------------------------------------------#

package DbmDirpasswd;
#------------------------------------------------------------------------------
#   add_user : $B%G%#%l%/%H%j%Q%9%o!<%IDI2C(B
#------------------------------------------------------------------------------
sub add_user {
    my ($file_nm, $user, $passwd) = @_;                                 #1.3.0#
    my ($cpw, %kmk);                                                    #1.3.0#

    if ( length( $user ) > 0 && length( $passwd ) > 0 ){                #1.1.0#
        $file_nm = &passwd_path( $file_nm );
		$cpw = &get_password( $passwd );
		if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }        #1.4.0#
        if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			&passwd_file_unlock("$file_nm.lk");
			return(0);
		}
        else {                                                          #1.1.0#
            $kmk{$user} = $cpw; 
            dbmclose %kmk;
            &passwd_file_unlock("$file_nm.lk");
            return(1);
		}                                                               #1.1.0#
    }                                                                   #1.1.0#
    else { return(0); }                                                 #1.1.0#
}

#------------------------------------------------------------------------------
#   upd_user : $B%G%#%l%/%H%j%Q%9%o!<%I99?7(B
#------------------------------------------------------------------------------
sub upd_user {
    my ($file_nm, $user, $passwd) = @_;                                 #1.3.0#
    my ($cpw, %kmk);                                                    #1.3.0#
	
    if ( length( $user ) > 0 && length( $passwd ) > 0 ){                #1.1.0#
        $file_nm = &passwd_path($file_nm);
        $cpw = &get_password($passwd);
        if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }        #1.4.0#
        if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			&passwd_file_unlock("$file_nm.lk");
			return(0);
		}
        else {                                                          #1.1.0#
            $kmk{$user} = $cpw; 
            dbmclose %kmk;
            &passwd_file_unlock("$file_nm.lk");
			return(1);
		}                                                               #1.1.0#
    }                                                                   #1.1.0#
    else { return(0); }                                                 #1.1.0#
}

#------------------------------------------------------------------------------
#   del_user : $B%G%#%l%/%H%j%Q%9%o!<%I:o=|(B                               V1.2.0
#------------------------------------------------------------------------------
sub del_user {                                                          #1.2.0#
    my ( $file_nm, $user ) = @_;                                        #1.2.0#
    my ( $cpw, %kmk );                                                  #1.2.0#

    if ( length( $user ) > 0 ){                                         #1.2.0#
        $file_nm = &passwd_path( $file_nm );                            #1.2.0#
        if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }        #1.4.0#
        if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {                  #1.2.0#
			&passwd_file_unlock("$file_nm.lk");                         #1.2.0#
			return(0);                                                  #1.2.0#
		}                                                               #1.2.0#
        else {                                                          #1.2.0#
            delete $kmk{$user};                                         #1.2.0#
            dbmclose %kmk;                                              #1.2.0#
            &passwd_file_unlock("$file_nm.lk");                         #1.2.0#
			return(1);                                                  #1.2.0#
		}                                                               #1.2.0#
    }                                                                   #1.2.0#
    else { return(0); }                                                 #1.2.0#
}                                                                       #1.2.0#

#------------------------------------------------------------------------------
#   find_user : $B%f!<%68!:w(B
#------------------------------------------------------------------------------
sub find_user {
    my ( $file_nm, $user ) = @_;                                        #1.3.0#
    my ( $rtn, %kmk );                                                  #1.3.0#

    if ( length( $user ) > 0  ){                                        #1.1.0#
        $file_nm = &passwd_path($file_nm);
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			return( -1 );
        }
        else { 
            $rtn = 0; 
            if ( $kmk{$user} ){ $rtn = 1; }
            else              { $rtn = 0; }
        }
        dbmclose %kmk;
        return($rtn);    
    }                                                                   #1.1.0#
    else { return(0); }                                                 #1.1.0#
}

#------------------------------------------------------------------------------
#   password_check : $B%Q%9%o!<%I$N@5Ev@-%A%'%C%/(B                         V1.5.0
#------------------------------------------------------------------------------
sub password_check {                                                    #1.5.0#
    my ( $file_nm, $user, $pass ) = @_;                                 #1.5.0#
    my ( $rtn, %kmk );                                                  #1.5.0#
                                                                        #1.5.0#
    if ( length( $user ) > 0 && length( $pass ) > 0 ){                  #1.5.0#
        $file_nm = &passwd_path( $file_nm );                            #1.5.0#
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {                  #1.5.0#
			return( -2 );                                               #1.5.0#
        }                                                               #1.5.0#
        else {                                                          #1.5.0#
			if ( defined $kmk{$user} ){                                 #1.5.0#
				if ( crypt( $pass, $kmk{$user}) eq $kmk{$user} ){       #1.5.0#
					$rtn = 1;   # $B%Q%9%o!<%I$,@5Ev(B                      #1.5.0#
				}                                                       #1.5.0#
				else {                                                  #1.5.0#
					$rtn = 0;   # $B%Q%9%o!<%I$,4V0c$C$F$$$k(B              #1.5.0#
				}                                                       #1.5.0#
			}                                                           #1.5.0#
			else {                                                      #1.5.0#
				$rtn = -1;   # $B%f!<%6$,B8:_$7$J$$>l9g(B                   #1.5.0#
			}                                                           #1.5.0#
        }                                                               #1.5.0#
        dbmclose %kmk;                                                  #1.5.0#
        return( $rtn );                                                 #1.5.0#
    }                                                                   #1.5.0#
	else { return( -2 ); }                                              #1.5.0#
}                                                                       #1.5.0#

#------------------------------------------------------------------------------
#   get_passwd : $B%Q%9%o!<%I$r0E9f2=(B
#------------------------------------------------------------------------------
sub get_password {
    my ($pw) = @_;                                                      #1.3.0#
    my ($salt, @itoa64, $v, $n, $arr_no, $rtn);                         #1.3.0#

    @itoa64 = ('.','/','0','1','2','3','4','5','6','7','8','9',
               'A','B','C','D','E','F','G','H','I','J','K','L','M',
               'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
               'a','b','c','d','e','f','g','h','i','j','k','l','M',
               'n','o','p','q','r','s','t','u','v','w','x','y','z');	

    srand();
    $v = int(rand()*100000);
    $n = 2;
    while (--$n >= 0) {
        $arr_no = $v & hex("3F");
        $salt .= $itoa64[$arr_no];
        $v >>= 6;
    }

    $rtn = crypt($pw, $salt);
    return($rtn);
}

#------------------------------------------------------------------------------
#   passwd_file_lock : $B@lMQ(B $B%U%!%$%k%m%C%/(B
#------------------------------------------------------------------------------
sub passwd_file_lock {
    my ($lock_file)   = $_[0];                                          #1.3.0#
    my ($in_alarm_interval)   = $_[1];                                  #1.3.0#

#1.3.0#    while(!symlink(".",$lock_file)){
#1.3.0#        if(--$alarm_interval == 0 ){
#1.3.0#                return(-1);
#1.3.0#        }
#1.3.0#        sleep(1);
#1.3.0#    }
#1.3.0#    return(0);

    my @dirs = split('/',$lock_file);                                   #1.3.0#
    my $file_name = pop( @dirs );                                       #1.3.0#
    my $file_dir  = join('/',@dirs);                                    #1.3.0#
    my $real_name = ".filelock_${file_name}";                           #2.3.2#

    if ( -d $file_dir && -r $file_dir && -w $file_dir ){                #1.3.0#
		                                                                #1.3.0#
        if ( ! -r "$file_dir/$real_name" ){                             #1.3.0#
            `/bin/touch $file_dir/$real_name`;                          #1.3.0#
            unlink( $lock_file );                                       #1.3.0#
        }                                                               #1.3.0#
		my $alarm_interval = 5;                                         #1.3.0#
        if ( $in_alarm_interval =~ /^\d+$/ && $in_alarm_interval > 0 ){ #1.3.0#
            $alarm_interval = $in_alarm_interval;                       #1.3.0#
        }                                                               #1.3.0#
		my $maxlock_sec = 600;                                          #1.3.0#
		                                                                #1.3.0#
        while( ! symlink( $real_name,$lock_file ) ) {                   #1.3.0#
            if ( --$alarm_interval <= 0 ){                              #1.3.0#
                return( -1 );                                           #1.3.0#
            }                                                           #1.3.0#
            else {                                                      #1.3.0#
                my $timestmp = &DbmDirpasswd_timestmp( $lock_file );    #1.3.0#
                if ( $maxlock_sec > 0                                   #1.3.0#
                     && ( time - $timestmp > $maxlock_sec ) ){          #1.3.0#
                    passwd_file_unlock( $lock_file );                   #1.3.0#
                    $alarm_interval = $in_alarm_interval;               #1.3.0#
                }                                                       #1.3.0#
				else { sleep( 1 ); }                                    #1.3.0#
			}                                                           #1.3.0#
        }                                                               #1.3.0#
        return( 0 );                                                    #1.3.0#
    }                                                                   #1.3.0#
    else { return ( -1 ); }                                             #1.3.0#
}

#------------------------------------------------------------------------------
#   passwd_file_unlock : DbmDirpasswd.pl$B@lMQ(B $B%U%!%$%k%"%s%m%C%/(B
#------------------------------------------------------------------------------
sub passwd_file_unlock {
    my ($unun) = unlink($_[0]);                                         #1.3.0#
    return($unun);
}

#------------------------------------------------------------------------------
#   passwd_path : DbmDirpasswd.pl$B@lMQ(B $B%U%!%$%k%Q%9%A%'%C%/(B
#------------------------------------------------------------------------------
sub passwd_path () {
    my ( $in ) = shift;                                                 #1.3.0#
	
    $in =~ s/[^\w\-_\.\/]//g;
    $in =~ s/\.\.\+//g;
	
    return( $in );
}

#------------------------------------------------------------------------------
#   DbmDirpasswd_timestmp : DbmDirpasswd.pl$B@lMQ(B $B%U%!%$%k%?%$%`%9%?%s%W(B  V1.3.0
#------------------------------------------------------------------------------
sub DbmDirpasswd_timestmp (){                                           #1.3.0#
	my( $file ) = shift;                                                #1.3.0#
    my( $dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$time_stmp,        #1.3.0#
        $mtime,$ctime,$blksize,$blocks ) = lstat( $file );              #1.3.0#
    return( $mtime );                                                   #1.3.0#
}                                                                       #1.3.0#

1;
