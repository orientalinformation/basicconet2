package WWWDecode;
#----------------------------------------------------------------------------#
#     Client Name    :  ����
#     Project Name   :  WWW���󥳡��ɥǡ����ǥ����� �ѥå�����
#     Program Name   :  WWWDecode.pl
#     Create Date    :  1999.07.24
#     Programmer     :  Waragai  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs 
#     Notice         :  This File Code is EUC
#     Copyright      :  2002 DNP DigitalCom CO.,LTD.
#----------------------------------------------------------------------------#
#     verison 1.0.0  :  1999.07.24 (wara)  New Create ( CPS1.0 )
#     verison 1.0.1  :  1999.10.07 (wara)  �ե�������ɤ߹��ߤΥХ�����
#     verison 1.0.2  :  2000.02.09 (wara)  ʸ���������٣գ�
#     verison 2.0.2  :  2000.10.23 (wara)  Jcode�⥸�塼���ǻ��ѡ�ʸ���İ�����
#     verison 2.0.3  :  2001.02.23 (wara)  GET+POST���б�
#     verison 2.1.3  :  2002.06.11 (Y.Sugioka)  GET��POST����롼�����ɲ�
#     verison 2.2.3  :  2004.05.17 (maru)  name��CSS�к�
#----------------------------------------------------------------------------#
#
#     ���ͳ���
#             ���Υѥå������ϡ����󥿡��ͥåȥ֥饦���������������
#             ���󥳡��ɥǡ�����ǥ����ɤ��ֵѤ��ޤ���
# 
#     �ѥå�����������ˡ
#
#             [1] ��ư�İ��ǥ�����
#                 &WWWDecode::auto( *in ); 
#
#             [2] GET�᥽�åɸ���ǥ�����
#                 &WWWDecode::method_get( *in ); 
#
#             [3] POST�᥽�åɸ���ǥ�����
#                 &WWWDecode::method_post( *in ); 
#
#             [4] x-www-form-urlencoded �Υǥ�����
#                 &WWWDecode::urlencode( *in ); 
#
#             [5] x-www-form-urlencoded �Υǥ����ɡʥǡ���������ʬ��ά�ǡ�
#                 &WWWDecode::mainencode( $scala ); 
#
#             [6] multipart/form-data �Υǥ�����
#                 &WWWDecode::formdata( *in ); 
#
#             [7] ����ʸ�����Ѵ�
#                 $rtn = &WWWDecode::default_conv( $scala ); 
#
#             [8] ����ʸ�����Ѵ��ϥå�����
#                 &WWWDecode::default_conv_hash( *in ); 
#
#     �֤��ͤ�����
#             %in  -> name��key�Ȥ���Ϣ������
#                     ( Ʊ��� name ��¸�ߤ���Ȥ���\x00��Ϣ�� ��
#             @in  -> name��value�� \x00 (null)��Ϣ�뤷������
#             $in  -> name������
#
#     ���ջ���
#             multipart/form-data�Υǥ����ɤǥե���������Ƥξ��ˤϡ�
#             �ե������̾�Τ���file�פξ��ˤϡ���file_name�פˤϡ�
#             �ե�����̾����file_type�פˤϡ��ޥ��ॿ���פ��ɲä���ޤ���
#----------------------------------------------------------------------------#

use Jcode;                                                            #2.0.2#
&initial_setting unless defined $WWWDecode_version; 

#----------------------------------------------------------------------------#
#     sub initial_setting : initial setting 
#----------------------------------------------------------------------------#
#     input  : �ʤ�
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub initial_setting (){ 

#2.2.3#    $WWWDecode_version = "1.0.2"; 
    $WWWDecode_version = "2.2.3";                                      #2.2.3#

#2.0.2#    if ( $jcode::version < 2.0 ){ 
#2.0.2#        print "Content-Type : text/plain\n\n";
#2.0.2#		print "jcode.pl Error !! This Program use jcode.pl 2.0 later";
#2.0.2#		exit; 
#2.0.2#    }
}

#----------------------------------------------------------------------------#
#     sub auto : ��ư�İ��ǥ�����
#----------------------------------------------------------------------------#
#     input  : (1) ���ϥǡ�������Ǽ������ΰ�Υϥå���
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub auto { 
    local( *in ) = shift; 

    if ( $ENV{'CONTENT_TYPE'} =~ m#^multipart/form-data#) {
        &formdata( *in ); 
    }
    else { 
        &urlencode( *in ); 
    }
}

#----------------------------------------------------------------------------#
#     sub method_get : GET�᥽�åɸ���ǥ�����                         #2.1.3#
#----------------------------------------------------------------------------#
#     input  : (1) ���ϥǡ�������Ǽ������ΰ�Υϥå���
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub method_get { 
    local( *in ) = shift; 
    local( $buf,*name,*value ); 

	if ( $ENV{'REQUEST_METHOD'} ne 'GET' )  { return; }

	$buf = $ENV{'QUERY_STRING'};

	&mainencode( $buf );
}

#----------------------------------------------------------------------------#
#     sub method_post : POST�᥽�åɸ���ǥ�����                       #2.1.3#
#----------------------------------------------------------------------------#
#     input  : (1) ���ϥǡ�������Ǽ������ΰ�Υϥå���
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub method_post { 
    local( *in ) = shift; 
    local( $buf,*name,*value ); 

	if ( $ENV{'REQUEST_METHOD'} ne 'POST' )  { return; }

	if ( $ENV{'CONTENT_TYPE'} =~ m#^multipart/form-data#) {
		 &formdata( *in ); 
	}
	else { 
		read(STDIN, $buf, $ENV{'CONTENT_LENGTH'});

		&mainencode( $buf );
	}
}

#----------------------------------------------------------------------------#
#     sub urlencode : x-www-form-urlencoded �Υǥ�����
#----------------------------------------------------------------------------#
#     input  : (1) ���ϥǡ�������Ǽ������ΰ�Υϥå���
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub urlencode { 
    local( *in ) = shift; 
    local( $buf,$buf1,$buf2,@buf1,@buf2,@name,@value,$n,$v,*name,*value ); 

#2.0.3#    if ( $ENV{'QUERY_STRING'} ){ $buf = $ENV{'QUERY_STRING'}; }
#2.0.3#    else         { read(STDIN, $buf, $ENV{'CONTENT_LENGTH'}); }
	$buf1 = $ENV{'QUERY_STRING'};                                     #2.0.3#
	read(STDIN, $buf2, $ENV{'CONTENT_LENGTH'});                       #2.0.3#

#2.0.3#    @buf = split(/[&;]/,$buf);
    @buf1 = split(/[&;]/,$buf1);                                      #2.0.3#
    @buf2 = split(/[&;]/,$buf2);                                      #2.0.3#
    undef @name;
    undef @value; 
#2.0.3#    foreach $buf(@buf){ 
    foreach $buf( @buf1,@buf2 ){                                      #2.0.3#
        $buf =~ s/\+/ /g;
        ($n,$v) = split(/=/,$buf,2);
        $n =~ s/%(..)/pack("c",hex($1))/ge;
        $v =~ s/%(..)/pack("c",hex($1))/ge;
		push( @name,$n ); 
		push( @value,$v );
	}
	
	&kanji_conv( *in,*name,*value ); 
}

#----------------------------------------------------------------------------#
#     sub mainencode : x-www-form-urlencoded �Υǥ�������ʬ�Τ�        #2.1.3#
#----------------------------------------------------------------------------#
#     input  : (1) ɸ�����Ϥޤ���QUERY_STRING��������������ϥǡ���
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub mainencode { 
	local( $wbuf ) = shift;
	local( @buf, @name, @value, $buf, $n, $v, *name, *value );

    @buf = split(/[&;]/,$wbuf);
    undef @name;
    undef @value; 
    foreach $buf( @buf ){
        $buf =~ s/\+/ /g;
        ($n,$v) = split(/=/,$buf,2);
        $n =~ s/%(..)/pack("c",hex($1))/ge;
        $v =~ s/%(..)/pack("c",hex($1))/ge;
		push( @name,$n ); 
		push( @value,$v );
	}
	
	&kanji_conv( *in,*name,*value ); 
}

#----------------------------------------------------------------------------#
#     sub formdata : multipart/form-data �Υǥ�����
#----------------------------------------------------------------------------#
#     input  : (1) ���ϥǡ�������Ǽ������ΰ�Υϥå���
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub formdata {
    local( *in ) = @_; 
    local( $buffer,@name,@value,*name,*value,$name,$value ); 
    local( $header,$cr,$sp ); 

    undef @name;
    undef @value; 

    read(STDIN,$buffer,$ENV{'CONTENT_LENGTH'});
    if ( $buffer =~ /^----+(\w+)\r\n/ ||
         $buffer =~ /^----+(\w+)\n/   ||
         $buffer =~ /^----+(\w+)\r/ ){
        $buffer = $';
		$sp = $&; 
		if    ( $sp =~ /\r\n$/ ) { $cr = "\r\n"; }
        elsif ( $sp =~ /\r$/ )   { $cr = "\r"; }
        else                     { $cr = "\n"; }
        if ( $buffer =~ /($cr)?----+\w+-+($cr)+$/ ){ $buffer = $`; }
        @data = split(/$cr----+\w+$cr/,$buffer); 
		foreach $data(@data){
            if ( $data =~ /$cr$cr/ ){
				$header = $`;
				$value  = $';
				$header =~ s/$cr/ /g; 
				if ( $header =~ /\s+name=\"([^\"]+)\"/i ){ 
					$name = $1;
					push( @name,$name ); 
					push( @value,$value ); 
					if ( $header =~ /\s+filename=\"([^\"]+)\"/i ){
						push( @name,"${name}_name" );
						push( @value,$1 ); 
						if ( $header =~ /Content-Type: ([\w\/-]+)/i ){ 
							push( @name,"${name}_type" );
							push( @value,$1 ); 
						}
						else { 
							push( @name, "${name}_type");
							push( @value,"Unknown" ); 
						}
					}
				}
			}
        }
    }
    &kanji_conv( *in,*name,*value ); 
}

#----------------------------------------------------------------------------#
#     sub kanji_conv : �����������Ѵ� TO EUC
#----------------------------------------------------------------------------#
#     input  : (1) �ִ����Υǡ����ʥϥå����
#     input  : (2) �ִ�����name������ˤ�����Ρʥϥå����
#     input  : (3) �ִ�����value������ˤ�����Ρʥϥå����
#----------------------------------------------------------------------------#
#     output : (1) �ִ���Υǡ���
#----------------------------------------------------------------------------#
sub kanji_conv { 
    local( *in,*name,*value ) = @_; 
    local( %wk,%code,$n_code,$v_code,$code,$max,$a,$b,$n,$v,$i,$join_d ); 

#2.0.2#    undef %wk; 
#2.0.2#    for ( $i=0;$i<=$#name;$i+=1 ){ 
#2.0.2#        $n = $name[$i]; 
#2.0.2#		$v = $value[$i]; 
#2.0.2#        $n_code = &jcode::getcode(*n);
#2.0.2#        $v_code = &jcode::getcode(*v);
#2.0.2#        $code{$n_code} += 1 if $n_code;
#2.0.2#        $code{$v_code} += 1 if $v_code;
#1.0.1#	$wk{$name} = $value; 
#2.0.2#		$wk{$n} = $v;                                              #1.0.1#
#2.0.2#    }
#2.0.2#    undef $code;
#2.0.2#    undef $max ;
#2.0.2#    while( ($a,$b) = each %code ){
#2.0.2#        if ( $b > $max ){ $max = $b; $code = $a; }
#2.0.2#    }

	undef %wk; 
    for ( $i=0;$i<=$#name;$i+=1 ){                                     #2.0.2#
        $n = $name[$i];                                                #2.0.2#
		$v = $value[$i];                                               #2.0.2#
		$wk{$n} = $v;                                                  #2.0.2#
	}                                                                  #2.0.2#
	undef $join_d;                                                     #2.0.2#
    for ( $i=0;$i<=$#name;$i+=1 ){                                     #2.0.2#
        $n = $name[$i];                                                #2.0.2#
		$v = $value[$i];                                               #2.0.2#
        if ( $wk{$n.'_name'} && $wk{$n.'_type'} ){}                    #2.0.2#
		else {                                                         #2.0.2#
			$join_d .= $n;                                             #2.0.2#
			$join_d .= $v;                                             #2.0.2#
		}                                                              #2.0.2#
	}                                                                  #2.0.2#
	( $code )  = Jcode::getcode( $join_d );                            #2.0.2#
	
    undef %in;
    undef @in;
    undef $in; 
    for ( $i=0;$i<=$#name;$i+=1 ){ 
        $n = $name[$i]; 
		$v = $value[$i]; 

#1.0.1#        if ( $wk{$name.'_name'} && $wk{$name.'_type'} ){}
        if ( $wk{$n.'_name'} && $wk{$n.'_type'} ){}                    #1.0.1#
        else {
#2.0.2#            if ( $code eq 'jis' ){
#2.0.2#                &jcode::h2z_jis(*n);
#1.0.2#	        &jcode::convert(*n,'euc');
#2.0.2#				&jcode::convert(*n,'euc',$code);                   #1.0.2#
#2.0.2#				&jcode::h2z_jis(*v);
#1.0.2#	        &jcode::convert(*v,'euc');
#2.0.2#				&jcode::convert(*v,'euc',$code);                   #1.0.2#
#2.0.2#			}
#2.0.2#            elsif ( $code eq 'euc' ){
#2.0.2#                &jcode::h2z_euc(*n);
#1.0.2#	        &jcode::convert(*n,'euc');
#2.0.2#				&jcode::convert(*n,'euc',$code);                   #1.0.2#
#2.0.2#				&jcode::h2z_euc(*v);
#1.0.2#	        &jcode::convert(*v,'euc');
#2.0.2#				&jcode::convert(*v,'euc',$code);                   #1.0.2#
#2.0.2#			}
#2.0.2#            elsif ( $code eq 'sjis' ){
#2.0.2#                &jcode::h2z_sjis(*n);
#1.0.2#				&jcode::convert(*n,'euc');
#2.0.2#				&jcode::convert(*n,'euc',$code);                   #1.0.2#
#2.0.2#				&jcode::h2z_sjis(*v);
#1.0.2#				&jcode::convert(*v,'euc');
#2.0.2#				&jcode::convert(*v,'euc',$code);                   #1.0.2#
#2.0.2#			}
#2.0.2#            else {
#2.0.2#                &jcode::convert(*n,'euc');
#2.0.2#				&jcode::convert(*v,'euc');
#2.0.2#            }

			$n = Jcode->new( $n,$code )->h2z->euc;                     #2.0.2#
			$v = Jcode->new( $v,$code )->h2z->euc;                     #2.0.2#
		}

		#--- 2.2.3 START ------------------------------------------------#
		#--- name��ʬ��CSS�к� ------------------------------------------#
		$n =~ s/"//g;
		$n =~ s/'//g;
		$n =~ s/<//g;
		$n =~ s/>//g;
		$n =~ s/&//g;
		#--- 2.2.3 END --------------------------------------------------#

        $in{$n} .= "\x00" if ( defined($in{$n}) ); $in{$n} .= $v;
		push ( @in,"$n\x00$v" );
		$in += 1;
    }

    return( *in ); 
}

#----------------------------------------------------------------------------#
#     sub default_conv : ʸ������������
#----------------------------------------------------------------------------#
#     input  : (1) �ִ����Υǡ��������ä��ѿ�
#----------------------------------------------------------------------------#
#     output : (1) �ִ���Υǡ��������ä��ѿ�
#----------------------------------------------------------------------------#
sub default_conv { 
    local( $d ) = shift; 

    $d =~ s/\r\n/<br>/g;
    $d =~ s/\r/<br>/g;
    $d =~ s/\n/<br>/g;
    $d =~ s/,/��/g; 
    $d =~ s/'/��/g; 
    $d =~ s/"/��/g; 
    $d =~ s/\t/ /g; 
	
    return( $d ); 
}

#----------------------------------------------------------------------------#
#     sub default_conv_hash : ʸ������������ʥϥå����ǡ�
#----------------------------------------------------------------------------#
#     input  : (1) �ִ�����ǡ��������ä�����ʥϥå����
#----------------------------------------------------------------------------#
#     output : �ʤ�
#----------------------------------------------------------------------------#
sub default_conv_hash { 
    local( *in ) = shift; 
    local( $n,$v,$i ); 

    while ( ($n,$v) = each %in ){ 
        if ( defined $in{$n.'_name'} && defined $in{$n.'_type'} ){}
        else { 
            $v = &default_conv( $v ); 
			$in{$n} = $v; 
		}
    }
    for( $i=0;$i<=$#in;$i+=1 ){
        ( $n,$v ) = split(/\0/,$in[$i]); 
        if ( defined $in{$n.'_name'} && defined $in{$n.'_type'} ){}
        else {
            $v = &default_conv( $v ); 
            $in[$i] = $n . "\x00" . $v; 
        }
    }
}

1;
