package SessionDB;
#-----------------------------------------------------------------------------#
#      Client Name     : ����
#      Project Name    : SessionContainer��DB�ǥ饤�֥�� Ver.2
#      Program Name    : SessionDB2.pl
#      Create Date     : 2003.11.13
#      Programmer      : Y.Sugioka (Pro.DigitalCom.DNP)
#      Entry Server    : All Sever
#      Called By       : All Programs
#      Notice          : This File Code is EUC.
#      Copyright       : 2003 DNP.DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#      version 1.0.0   : 2003.11.13 (Y.Sugioka)  New Create
#      version 1.0.1   : 2006.08.22 (ysakurai)   255 byte ��Ķ���� user_agent �б�
#      version 2.0.0   : 2014.10.16 (y.washizu) MGCLOUD�ܹԤ�ȼ��Date::DateCalc�λ��Ѥ�ػ�
#-----------------------------------------------------------------------------#
#
# [Comment]
#��
#  ���å��������饤�֥�� DB��
#  ���å���������ˡ�ˤĤ��Ƥ϶�ͭʸ��򤴻��Ȥ���������
#  
#-----------------------------------------------------------------------------#
# [1] session_start : Session����Start!!
#  my ($rtn,$s_id) = &SessionDB::session_start($dbh,$s_name,$term);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $term : Session Term
# [Output]
#  $rtn : ���(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:Session IDȯ�ԥ��顼)
#��$s_id : Session ID
#-----------------------------------------------------------------------------#
# [2] session_check : Session Check!!
#  my ($rtn) = &SessionDB::session_check($dbh,$s_name,$s_id,$term);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $term : Session Term
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�,-3:�۾ｪλ)
#-----------------------------------------------------------------------------#
# [3] container_get : Get Container Data!!
#  my ($rtn,$code,$data) = &SessionDB::container_get($dbh,$s_name,$s_id,$term);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $term : Session Term
# [Output]
#  $rtn : ���(1:����,0:ͭ�������ڤ�,-1:������Session ID,-2:����ƥ��Ժ�,-3:�۾ｪλ)
#  $code : �ǡ���������
#  $data : Container Data(Scalar)
#-----------------------------------------------------------------------------#
# [4] container_set : Set Container Data
#  my $rtn = &SessionDB::container_set($dbh,$s_name,$s_id,$code,$d_area,$term);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
#  $code : Data Code
#  $d_area : Data (Scalar)
#  $term : Session Term
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
# [5] scalar2hash : Scalar To Hash
#  my %hash = &SessionDB::scalar2hash($scalar);
# [Input]
#  $scalar : Scalar
# [Output]
#  %hash : Hash
#-----------------------------------------------------------------------------#
# [6] hash2scalar : Hash To Scalar
#  my $scalar = &SessionDB::hash2scalar(%hash);
# [Input]
#  %hash : Hash
# [Output]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
# [7] session_change : Change Session ID
#  my ($rtn,$new_s_id) = &SessionDB::session_change($dbh,$s_name,$s_id,$term);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Old Session ID
#  $term : Session Term
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼,-4:�Ķ������ߥ�)
#  $new_s_id : New Session ID
#-----------------------------------------------------------------------------#
# [8] session_end : Session End
#  my $rtn = &SessionDB::session_end($dbh,$s_name,$s_id);
# [Input]
#  $dbh : DB Handler
#  $s_name : Session Name
#  $s_id : Session ID
# [Output]
#  $rtn : ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

use Jcode;
use DBD::mysql;
#2.0.0#use Date::DateCalc qw(check_date calc_new_date_time);
use Date::Calc qw( check_date Add_Delta_DHMS );#2.0.0#
use Time::Local;

&initial_setting();

#-----------------------------------------------------------------------------#
#    sub init : Initial Setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	if($ENV{SCRIPT_FILENAME} =~ m#[\w+]/(CGI|SCGI)/([^/]+)#){
		$hin_dir = $2;
	}elsif($2 =~ /-bin/){
		$hin_dir = $`;
	}else{
		print "Content-typej:text/plain;charset=Shift_JIS\n\n";
		print "Can't execute SessionContainer.pl!!\n";
	}
	
	$s_length = 39; # Session ID's Length
	
	
	@fields = qw(
		session_id start_date last_reference_date last_update_date
		get_cnt set_cnt data_code user_agent data_area
	); # Container's Data Fields
	
	#---- Check carrier ----#
	$carrier = 'WWW';
	$table_flg = '_w';
	if($ENV{HTTP_USER_AGENT} =~ /^DoCoMo/){
		$carrier = 'IMODE';
		$table_flg = '_i';
	}elsif($ENV{HTTP_X_JPHONE_COLOR} ne ''){
		$carrier = 'SKY';
		$table_flg = '_j';
	}elsif($ENV{HTTP_X_UP_SUBNO} ne ''){
		$carrier = 'WAP';
		$table_flg = '_e';
	}

	#---- HTTP_USER_AGENT ��Ƭ���� 255 byte ����� ----#
	$http_user_agent = substr( $ENV{HTTP_USER_AGENT}, 0, 255 );         #1.0.1#
}

#-----------------------------------------------------------------------------#
#    sub session_start : Session����Start!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:Session IDȯ�ԥ��顼)
#��  output : (2) Session ID
#-----------------------------------------------------------------------------#
sub session_start {
	my ($dbh,$s_name,$term) = @_;
	my $now = &now();

	#---- Check Param ----#
	#-- Session Name --#
	if($s_name eq ''){
		return(0);
	}
	
	#-- Term --#
	my $s_term = &setTerm($now,$now,$term);
	if($now > $s_term){
		return(-1);
	}
	
	#---- Make Session ID ----#
	my $s_id = &makeSessionID();
	if(length($s_id) != $s_length){
		return(-2);
	}

	#---- ���բ�timestamp���Ѵ� ----#
	$now = &chg_timestamp($now, 1);

	#---- Make Session Container ----#
	my $sql = "insert into $s_name$table_flg set ";
	$sql .= "session_id = " . $dbh->quote($s_id) . ",";
	$sql .= 'start_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_reference_date = ' . $dbh->quote($now) . ",";
	$sql .= 'last_update_date = ' . $dbh->quote($now) . ",";
	$sql .= 'get_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'set_cnt = ' . $dbh->quote(0) . ",";
	$sql .= 'data_code = ' . $dbh->quote('asc') . ",";
#1.0.1#	$sql .= 'user_agent = ' . $dbh->quote($ENV{HTTP_USER_AGENT}) . ",";
	$sql .= 'user_agent = ' . $dbh->quote($http_user_agent) . ",";      #1.0.1#
	$sql .= 'data_area = ' . $dbh->quote('');
	
	my $sth = &execQuery($dbh,$sql) ||
		return(0);
	$sth->finish;
	
	return(1,$s_id);
}

#-----------------------------------------------------------------------------#
#    sub session_check : Session Check!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#    input  : (4) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�,-3:�۾ｪλ)
#-----------------------------------------------------------------------------#
sub session_check {
	my ($dbh,$s_name,$s_id,$term) = @_;
	my $now = &now();

	#---- Check Session ID ----#
	if($s_id eq '' || ($s_id ne '' && length($s_id) != $s_length)){
		return(-2);
	}else{
		#---- Search Session Container ----#
		my ($rtn,$rs) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn == 0){return(-3);}
		if($rs ne ''){

			#---- ͭ�����¤�׻� ----#
			my $s_term = &setTerm($$rs{start_date},$$rs{last_reference_date},$term);

			if($now > $s_term)  { return(0); }
#1.0.1#			if($ENV{HTTP_USER_AGENT} ne $$rs{user_agent}){return(-1);}
			if( $http_user_agent ne $$rs{'user_agent'} ) {return(-1);}  #1.0.1#
			return(1);
		}else{ # Not Found
			return(-2);
		}
	}
}

#-----------------------------------------------------------------------------#
#    sub container_get : Get Container Data!!
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#    input  : (4) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:����,0:ͭ�������ڤ�,-1:������Session ID,-2:����ƥ��Ժ�,-3:�۾ｪλ)
#    output : (2) �ǡ���������
#    output : (3) Container Data(Scalar)
#-----------------------------------------------------------------------------#
sub container_get {
	my ($dbh,$s_name,$s_id,$term) = @_;
	my $rtn;
	my $now = &now;

	#---- Check Session ----#
	my $chk = &session_check($dbh,$s_name,$s_id,$term);
	if($chk != 1){
		return($chk); # Error
	}else{
		my ($rtn,$data) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn == 0){
			return(-3);
		} # Abend
		if($data eq ''){
			return(-2);
		} # Not Found

		#---- ͭ�����¤�׻� ----#
		my $s_term = &setTerm($$data{start_date},$$data{last_reference_date},$term);

		if($now > $s_term){
			return(0);
		} # Time is Over.
		
		#---- Set Attribute ----#
		$$data{get_cnt} ++;
		$$data{last_reference_date} = $now;
		
		my $s_rtn = &setSessionData($dbh,$s_name,$s_id,$data);
		if($s_rtn == -1){return(-3);} # Abend
		if($s_rtn == 0){return(-2);} # Not Found
		
		return(1,$$data{data_code},$$data{data_area});
	}
}

#-----------------------------------------------------------------------------#
#    sub container_set : Set Container Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#    input  : (4) Data Code
#    input  : (5) Data (Scalar)
#    input  : (6) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
sub container_set {
	my ($dbh,$s_name,$s_id,$code,$d_area,$term) = @_;
	my $rtn;
	my $now = &now(); 

	#---- Check Session ----#
	my $chk = &session_check($dbh,$s_name,$s_id,$term);
	if($chk != 1){
		return($chk);
	}else{
		my ($rtn,$data) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn != 1){
			return(-3);
		} # Abend
		if($data eq ''){
			return(-2);
		} # Not Found

		#---- ͭ�����¤�׻� ----#
		my $s_term = &setTerm($$data{start_date},$$data{last_reference_date},$term);

		if($now > $s_term){
			return(0);
		} # Time is over.
		
		#---- Set Attribute ----#
		$$data{set_cnt} ++;
		$$data{last_reference_date} = $now;
		$$data{last_update_date} = $now;
		$$data{data_code} = $code;
		$$data{data_area} = $d_area;
		
		my $s_rtn = &setSessionData($dbh,$s_name,$s_id,$data);
		if($s_rtn == -1){return(-3);} # Abend
		if($s_rtn == 0){return(-2);} # Not Found
		
		return(1);
	}
}

#-----------------------------------------------------------------------------#
#    sub scalar2hash : Scalar To Hash
#-----------------------------------------------------------------------------#
#    input  : (1) Scalar
#-----------------------------------------------------------------------------#
#    output : (1) Hash
#-----------------------------------------------------------------------------#
sub scalar2hash {
	my ($scalar) = @_;
	my %hash;

	foreach my $row(split(/\n/,$scalar)){
		$row =~ /^([^=]*)=([^\n]*)/;
		my ($n,$v) = ($1,$2);
		if($n =~ /^([^\n]*)\[([^\n]*)\]/){
			if($2 =~ /[^0-9]*/){ # Hash
				$hash{$1}->{$2} = $v;
			}else{ # Array
				$hash{$1}->[$2] = $v;
			}
		}else{
			$hash{$n} = $v;
		}
	}
	
	return(%hash);
}

#-----------------------------------------------------------------------------#
#    sub hash2scalar : Hash To Scalar
#-----------------------------------------------------------------------------#
#    input  : (1) Hash
#-----------------------------------------------------------------------------#
#    output : (1) Scalar
#-----------------------------------------------------------------------------#
sub hash2scalar {
	my (%hash) = @_;
	my $scalar;

	while(my ($n,$v) = each(%hash)){
		if($v =~ /^ARRAY\([^\0]*\)/){
			for(my $i = 0;$i < (@$v);$i ++){
				$scalar .= "$n\[$i\]=$v->[$i]\n";
			}
		}elsif($v =~ /^HASH\([^\0]*\)/){
			while(my ($nn,$vv) = each(%$v)){
				$scalar .= "$n\{$nn\}=$vv\n";
			}
		}else{
			$scalar .= "$n=$v\n";
		}
	}
	
	return($scalar);
}

#-----------------------------------------------------------------------------#
#    sub session_change : Change Session ID
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Old Session ID
#    input  : (4) Session Term
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:ͭ�������ڤ�,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼,-4:�Ķ������ߥ�)
#    output : (2) New Session ID
#-----------------------------------------------------------------------------#
sub session_change {
	my ($dbh,$s_name,$s_id,$term) = @_;
	my $now = &now();
	my $rtn;

	my $chk = &session_check($dbh,$s_name,$s_id,$term);
	if($chk != 1){
		return($chk);
	}else{
		my ($rtn,$data) = &getSessionData($dbh,$s_name,$s_id);
		if($rtn == 0){
			return(-4);
		} # Abend
		if($data eq ''){
			return(-2);
		} # Not Found

		#---- ͭ�����¤�׻� ----#
		my $s_term = &setTerm($$data{start_date},$$data{last_reference_date},$term);

		if($now > $s_term){
			return(0);
		} # Time is over.
		
		my $new_s_id = &makeSessionID();
		if(length($new_s_id) != $s_length){return(-3);}
		
		$$data{session_id} = $new_s_id;
		
		my $s_rtn = &setSessionData($dbh,$s_name,$s_id,$data);
		if($s_rtn == -1){return(-4);} # Abend
		if($s_rtn == 0){return(-2);} # Not Found
		
		return(1,$new_s_id);
	}
}

#-----------------------------------------------------------------------------#
#    sub session_end : Session End
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#
sub session_end {
	my ($dbh,$s_name,$s_id) = @_;
	my $now = &now;

	if(length($s_id) != $s_length){return(-1);}
	
	my $sql = "delete from $s_name$table_flg ";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	
	my $sth = &execQuery($dbh,$sql) ||
		return(0);
	
	if($sth->rows == 0){
		$rtn = -2;
	}else{
		$rtn = 1;
	}
	$sth->finish;
	
	return($rtn);
}

#-----------------------------------------------------------------------------#
#    Local Subroutines
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
#    sub getSessionData : Get Session Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#-----------------------------------------------------------------------------#
#    output : (1) Result(1:OK,0:NG)
#    output : (2) ResultSet
#-----------------------------------------------------------------------------#
sub getSessionData {
	my ($dbh,$s_name,$s_id) = @_;

	#---- �ǡ�������� ----#
	my $sql = "select " . join(',',@fields) . " from $s_name$table_flg";
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &execQuery($dbh,$sql) ||
		return(0);
	my $rs = $sth->fetchrow_hashref;
	$sth->finish;

	#---- timestamp���Ѵ������� ----#
	$rs->{'start_date'} = &chg_timestamp($rs->{'start_date'}, 2);
	$rs->{'last_update_date'} = &chg_timestamp($rs->{'last_update_date'}, 2);
	$rs->{'last_reference_date'} = &chg_timestamp($rs->{'last_reference_date'}, 2);
	
	return(1,$rs);
}

#-----------------------------------------------------------------------------#
#    sub setSessionData : Set Session Data
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) Session Name
#    input  : (3) Session ID
#    input  : (4) Data
#-----------------------------------------------------------------------------#
#    output : (1) Result(1:OK,0:Can't Set,-1:Abend)
#-----------------------------------------------------------------------------#
sub setSessionData {
	my ($dbh,$s_name,$s_id,$data) = @_;

	#---- ���բ�timestamp���Ѵ� ----#
	$data->{'start_date'} = &chg_timestamp($data->{'start_date'}, 1);
	$data->{'last_update_date'} = &chg_timestamp($data->{'last_update_date'}, 1);
	$data->{'last_reference_date'} = &chg_timestamp($data->{'last_reference_date'}, 1);

	#---- �ǡ����򹹿� ----#
	my $sql = "update $s_name$table_flg set ";
	foreach(@fields){
		$sql .= " $_ = " . $dbh->quote($$data{$_}) . ",";
	}
	chop($sql);
	$sql .= " where session_id = " . $dbh->quote($s_id);
	my $sth = &execQuery($dbh,$sql) ||
		return(-1);
	if($sth->rows == 0){
		$rtn = 0;
	}else{
		$rtn = 1;
	}
	$sth->finish;
	
	return($rtn);
}

#-----------------------------------------------------------------------------#
#    sub makeSessionID : Make Session ID
#-----------------------------------------------------------------------------#
#    output : (1) Session ID
#-----------------------------------------------------------------------------#
sub makeSessionID {

	my $s_id;
	foreach(split(/\./,$ENV{SERVER_ADDR})){
		$s_id .= sprintf("%02x",$_);
	}
	srand(time ^ ($$ + ($$ << 15)));
	$s_id .= sprintf("%02d",int(rand(100)));
	$s_id .= sprintf("%02d",int(rand(100)));
	foreach(split(/\./,$ENV{REMOTE_ADDR})){
		$s_id .= sprintf("%02x",$_);
	}
	if($ENV{UNIQUE_ID} ne '' &&
		length($ENV{UNIQUE_ID}) == 19){ # UNIQUE ID��¸�ߤ�19��ΤȤ�
		$s_id .= $ENV{UNIQUE_ID};
	}else{ # ����¾
		$s_id .= sprintf("%011d",time);
		$s_id .= sprintf("%08d",$$);
	}
	
	return($s_id);
}

#-----------------------------------------------------------------------------#
#    sub setTerm : ���ꤷ��ͭ�����¤�����
#-----------------------------------------------------------------------------#
#    input  : (1) Session������
#    input  : (2) �ǽ�������������
#    input  : (3) ͭ������
#-----------------------------------------------------------------------------#
#    output : (1) ͭ����������
#-----------------------------------------------------------------------------#
sub setTerm{
	my ($s_date,$a_date,$term) = @_;

	if(length($term) == 14){ # ���ջ���
		$term =~ /(....)(..)(..)(..)(..)(..)/;
		if(check_date($1,$2,$3)){
			if(($4 >= 0 && $4 < 24) && ($5 >= 0 && $5 < 60) && ($6 >= 0 && $6 < 60)){
				return($term);
			}
		}
	}else{ # ���л���
		$term =~ /^(S|L)([0-9]*)(D|H|M|S)$/;
		if($1 ne '' && $3 ne ''){
			my $date;
			if($1 eq 'S'){
				$date = $s_date;
			}elsif($1 eq 'L'){
				$date = $a_date;
			}
			my ($dd,$dh,$dm,$ds) = (0,0,0,0);
			if($3 eq 'D'){
				$dd = $2;
			}elsif($3 eq 'H'){
				$dh = $2;
			}elsif($3 eq 'M'){
				$dm = $2;
			}elsif($3 eq 'S'){
				$ds = $2;
			}
			$date =~ /^(....)(..)(..)(..)(..)(..)/;
#2.0.0#			my ($y,$m,$d,$hh,$mm,$ss) = calc_new_date_time($1,$2,$3,$4,$5,$6,$dd,$dh,$dm,$ds);
			my ($y,$m,$d,$hh,$mm,$ss) = &Date::Calc::Add_Delta_DHMS($1,$2,$3,$4,$5,$6,$dd,$dh,$dm,$ds);#2.0.0#
			return(sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss));
		}
	}
}

#-----------------------------------------------------------------------------#
#    sub now : �����֤����
#-----------------------------------------------------------------------------#
#    output : (1) ������(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub now {
	my ($ss,$mm,$hh,$d,$m,$y,$wd,$yd,$ist) = localtime(time);

	$y = $y + 1900;
	$m ++;
	my $now = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	return($now);
}

#-----------------------------------------------------------------------------#
#    sub chg_timestamp : ���բ���timestamp�� �Ѵ�
#-----------------------------------------------------------------------------#
#    input  : (1) ����(YYYYMMDDhhmmss) or timestamp��
#    input  : (2) 1 = ���բ�timestamp�� �� 2 = timestamp�͢�����
#-----------------------------------------------------------------------------#
#    output : (1) timestamp�� or ����(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub chg_timestamp {
	my( $win, $flg ) = @_;
	my( $ss, $mm, $hh, $d, $m, $y, $wd, $yd, $ist, $wot );

	if( $flg == 1 ) {
		($y,$m,$d,$hh,$mm,$ss) = ( $win =~ /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/ );
		$y -= 1900;
		$m --;
		$wot = timelocal($ss,$mm,$hh,$d,$m,$y);
	} else {
		($ss,$mm,$hh,$d,$m,$y,$wd,$yd,$ist) = localtime($win);
		$y += 1900;
		$m ++;
		$wot = sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss);
	}

	return $wot;
}

#-----------------------------------------------------------------------------#
#    sub execQuery : �����꡼�¹�
#-----------------------------------------------------------------------------#
#    input  : (1) DB Handler
#    input  : (2) SQL
#-----------------------------------------------------------------------------#
#    output : (1) Statement Handler
#-----------------------------------------------------------------------------#
sub execQuery {
	my ($dbh,$sql) = @_;
	my $sth;

	if(($sth = $dbh->prepare($sql)) && ($sth->execute)){
		return($sth);
	}
}

1;
