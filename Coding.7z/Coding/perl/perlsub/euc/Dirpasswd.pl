#---------------------------------------------------------------------------
#     Client Name    :  $B<RMQ(B
#     Project Name   :  htpasswd$B4XO"%i%$%V%i%j(B
#     Program Name   :  Dirpasswd.pl
#     Create Date    :  99.06.01
#     Programmer     :  Ayako Nakamura  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all program
#     Notice         :  This File Code is EUC
#     Copyright      :  1999 DNP DigitalCom CO.,LTD.
#---------------------------------------------------------------------------
#     version 1.0.0  : 1999.06.01 (Ayako.N)  New Create  (CPS1.0)
#     version 1.0.1  : 1999.09.07 (Ayako.N)  Bug.1$BJ8;zL\$,(B0$B$N>l9g=EJ#(B
#     version 1.1.1  : 1999.11.01 (wara)     Null $B%G!<%?$N>l9g%(%i!<$H$9$k(B
#     version 1.2.1  : 1999.11.01 (wara)     $B%f!<%6$N:o=|5!G=DI2C(B
#     version 1.3.1  : 2004.12.02 (maru)     $B%Q%9%o!<%I:n@.;~(Bsalt$B;XDj$rDI2C(B
#                                            $B%Q%9%o!<%IIU$N%f!<%68!:wDI2C(B
#     version 1.4.1  : 2005.04.12 (wara)     $B%m%C%/%U%!%$%k:o=|5!G=(B&strict$B=$@5(B
#     version 1.5.1  : 2005.04.12 (wara)     $B%m%C%/;n9T2s?t(B 5->15$B$XJQ99(B
#---------------------------------------------------------------------------
#  [1] add_user $B%G%#%l%/%H%j%Q%9%o!<%IDI2C(B
#      $file_nm....$B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $user.......$B%f!<%6L>(B
#      $passwd.....$B%Q%9%o!<%I(B
#      $BLa$jCM(B......1:$B@5>o=*N;(B 0:$B0[>o=*N;(B
#
#      $B!v%U%!%$%k$,B8:_$7$J$$>l9g!"?75,:n@.(B
#---------------------------------------------------------------------------
#  [2] upd_user $B%G%#%l%/%H%j%Q%9%o!<%I99?7(B
#      $file_nm....$B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $user.......$B%f!<%6L>(B
#      $passwd.....$B%Q%9%o!<%I(B
#      $BLa$jCM(B......1:$B@5>o=*N;(B  0:$B0[>o=*N;(B
#
#      $B!v%f!<%6$,B8:_$7$J$$>l9g!"DI2C!#%U%!%$%k$,B8:_$7$J$$>l9g?75,:n@.(B
#-----------------------------------------------------------------------------#
#  [3] del_user $B%G%#%l%/%H%j%Q%9%o!<%I:o=|(B
#      $file_nm....$B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $user.......$B%f!<%6L>(B
#      $BLa$jCM(B......1:$B@5>o=*N;(B  0:$B0[>o=*N;(B
#---------------------------------------------------------------------------
#  [4] find_user $B%f!<%68!:w(B
#      $file_nm....$B%Q%9%o!<%I%U%!%$%k$N%Q%9(B
#      $user.......$B%f!<%6L>(B
#      $BLa$jCM(B......1:$B9gCW(B 0:$B9gCW$7$J$$(B -1:$B0[>o=*N;(B
#---------------------------------------------------------------------------
#  [5] get_user  $B%Q%9%o!<%I%U%!%$%k$N9T$+$i%f!<%6L>$r<hF@(B
#      $line.......$B%Q%9%o!<%I%U%!%$%k$N9T%G!<%?(B
#      $BLa$jCM(B......$B%f!<%6L>(B
#---------------------------------------------------------------------------
#  [6] get_password $B0E9f2=%Q%9%o!<%I$r<hF@(B
#      $pw.........$B%Q%9%o!<%I(B
#      $salt.......salt
#      $rtn........$BLa$jCM!#0E9f2=$7$?J8;zNs(B
#---------------------------------------------------------------------------

package Dirpasswd;
#------------------------------------------------------------------------------
#   add_user : $B%G%#%l%/%H%j%Q%9%o!<%IDI2C(B
#------------------------------------------------------------------------------
sub add_user {
    my ( $file_nm, $user, $passwd ) = @_;                               #1.4.1#
    my ( $cpw );                                                        #1.4.1#

    if ( length( $user ) > 0 && length( $passwd ) > 0 ){                #1.1.1#
        $file_nm = &passwd_path($file_nm);
        $cpw = &Dirpasswd::get_password($passwd);
        if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }        #1.5.1#
        if ( ! (open( TFP, ">>$file_nm" ) ) ){
			&passwd_file_unlock("$file_nm.lk");
			return(0);
        }
        else {                                                          #1.1.1#
            print TFP "$user:$cpw\n"; 
            close TFP;
            &passwd_file_unlock("$file_nm.lk");
            return(1);
		}                                                               #1.1.1#
    }                                                                   #1.1.1#
    else { return(0); }                                                 #1.1.1#
}

#------------------------------------------------------------------------------
#     upd_user : $B%G%#%l%/%H%j%Q%9%o!<%I99?7(B
#------------------------------------------------------------------------------
sub upd_user {
    my ( $file_nm, $user, $passwd ) = @_;                               #1.4.1#
    my ( $tmp_file, $i, $cpw, $find, $c, $w );                          #1.4.1#

    if ( length( $user ) == 0 || length( $passwd ) == 0 ){ return(0); } #1.1.1#

    $file_nm = &passwd_path( $file_nm );
    $tmp_file = $file_nm . '.tmp';                                      #1.1.1#

#1.1.1#    @dir = split(/\//,$file_nm);
#1.1.1#    if ( $#dir == 0 ){ $tmp_file = 'tmp.txt'; }
#1.1.1#    else {
#1.1.1#        for($i=0; $i<$#dir; $i++) {
#1.1.1#            $tmp_file .= "$dir[$i]\/";
#1.1.1#        }
#1.1.1#        $tmp_file .= 'tmp.txt';
#1.1.1#        $tmp_file = $file_nm . '.tmp';
#1.1.1#    }

    if ( &passwd_file_lock( "$file_nm.lk",15 ) ){ return(0); }          #1.5.1#
    
    if ( ! ( open(TFP, ">>$tmp_file" ) ) ){        # Temporary file open 
		&passwd_file_unlock( "$file_nm.lk" );
		return(0);
    }
	
    if ( ! ( open(READ, "$file_nm" ) ) ){
		close TFP;
		unlink( $tmp_file );
		
		if ( ! ( open(TFP, ">$file_nm" ) ) ){
			&passwd_file_unlock( "$file_nm.lk" );
			return(0);
		}
        else { 
			$cpw = &Dirpasswd::get_password( $passwd );
			print TFP "$user:$cpw\n";
			close TFP;
			&passwd_file_unlock( "$file_nm.lk" );
			return(1);
        }
    }
    else { 
        undef $find; 
        while (<READ>) {
            $c = substr($_,0,1);
#1.2.1#  	    if ($find || ($c eq '#') || $c eq '') {
			if ( ($c eq '#') || $c eq '') {                             #1.2.1#
				print TFP "$_";
				next;
            }
			$w = &Dirpasswd::get_user($_);
			if ( $user ne $w ){
				print TFP "$_";
				next;
			} else {
				$cpw = &Dirpasswd::get_password($passwd);
				print TFP "$user:$cpw\n";
				$find = 1;
			}
        }
        if ( ! $find ){
			$cpw = &Dirpasswd::get_password( $passwd );
			print TFP "$user:$cpw\n";
        }
        close READ;
        close TFP;
		
        unlink( $file_nm );
        rename( $tmp_file,$file_nm );
        &passwd_file_unlock( "$file_nm.lk" );
        return( 1 );
    }
}

#------------------------------------------------------------------------------
#     del_user : $B%G%#%l%/%H%j%Q%9%o!<%I:o=|(B                            V1.2.1
#------------------------------------------------------------------------------
sub del_user {                                                          #1.2.1#
    my ( $file_nm, $user  ) = @_;                               #1.2.1# #1.4.1#
    my ( $tmp_file, $i, $cpw, $find, $c, $w );                  #1.2.1# #1.4.1#
                                                                        #1.2.1#
    if ( length( $user ) == 0 ){ return(0); }                           #1.2.1#
                                                                        #1.2.1#
    $file_nm = &passwd_path( $file_nm );                                #1.2.1#
    $tmp_file = $file_nm . '.tmp';                                      #1.2.1#
                                                                        #1.2.1#
    if ( &passwd_file_lock( "$file_nm.lk",15 ) ){ return(0); }          #1.5.1#
                                                                        #1.2.1#
    if ( ! ( open(TFP, ">>$tmp_file" ) ) ){                             #1.2.1#
		&passwd_file_unlock( "$file_nm.lk" );                           #1.2.1#
		return(0);                                                      #1.2.1#
    }                                                                   #1.2.1#
    else {                                                              #1.2.1#
        if ( ! ( open(READ, "$file_nm" ) ) ){                           #1.2.1#
			close TFP;                                                  #1.2.1#
			unlink( $tmp_file );                                        #1.2.1#
			return(0);                                                  #1.2.1#
		}                                                               #1.2.1#
        else {                                                          #1.2.1#
            undef $find;                                                #1.2.1#
            while (<READ>) {                                            #1.2.1#
                $c = substr($_,0,1);                                    #1.2.1#
				if ( ( $c eq '#' ) || $c eq '' ){                       #1.2.1#
					print TFP "$_";                                     #1.2.1#
					next;                                               #1.2.1#
                }                                                       #1.2.1#
				$w = &Dirpasswd::get_user($_);                          #1.2.1#
				if ( $user ne $w ){                                     #1.2.1#
					print TFP "$_";                                     #1.2.1#
					next;                                               #1.2.1#
				} else {                                                #1.2.1#
					#----delete-----#                                   #1.2.1#
					$find = 1;                                          #1.2.1#
				}                                                       #1.2.1#
            }                                                           #1.2.1#
            if ( ! $find ){                                             #1.2.1#
                close READ;                                             #1.2.1#
                close TFP;                                              #1.2.1#
				unlink( $tmp_file );                                    #1.2.1#
                &passwd_file_unlock( "$file_nm.lk" );                   #1.2.1#
                return( 0 );                                            #1.2.1#
            }                                                           #1.2.1#
            else {                                                      #1.2.1#
                close READ;                                             #1.2.1#
                close TFP;                                              #1.2.1#
                unlink( $file_nm );                                     #1.2.1#
                rename( $tmp_file,$file_nm );                           #1.2.1#
                &passwd_file_unlock( "$file_nm.lk" );                   #1.2.1#
                return( 1 );                                            #1.2.1#
            }                                                           #1.2.1#
        }                                                               #1.2.1#
    }                                                                   #1.2.1#
}                                                                       #1.2.1#

#------------------------------------------------------------------------------
#   find_user : $B%f!<%68!:w(B
#------------------------------------------------------------------------------
sub find_user {
    my ($file_nm, $user) = @_;                                          #1.4.1#
    my ($find, $c, $w);                                                 #1.4.1#
	
    if ( length( $user ) == 0 ){ return(0); }                           #1.1.1#

    if ( ! ( open(READ,"$file_nm") ) ){ return(-1); }
	
    while (<READ>){
        $c = substr($_,0,1);
        if ( ($c eq '#') || !($c) ){
            next;
        }
        $w = &Dirpasswd::get_user($_);
        if ( $user eq $w ) {
            $find = 1;
            last;
        }
    }
    close READ;
	
    if ( !$find ){ return(0); }

    return(1);    
}

#------------------------------------------------------------------------------
#   get_user : $B%Q%9%o!<%I%U%!%$%k$N9T$+$i%f!<%6L>$r<hF@(B
#------------------------------------------------------------------------------
sub get_user {
    my ($line) = @_;                                                    #1.4.1#
    my (@data);                                                         #1.4.1#
	
    @data = split(/:/,$line);

    if ($#data != 1) {
        '';
    } else {
        $data[0];
    }
}

#-----------------------------------------------------------------------------#
#   find_user_check : $B%f!<%68!:w!J%Q%9%o!<%I%A%'%C%/M-$j!K(B              #1.3.1#
#-----------------------------------------------------------------------------#
#   input(1)  : $B%Q%9%o!<%I%U%!%$%k%Q%9(B
#   input(2)  : $B%f!<%6L>(B
#   input(3)  : $B%Q%9%o!<%I(B
#-----------------------------------------------------------------------------#
#   output(1) : 0$B!&!&!&%"%s%^%C%A(B  1$B!&!&!&%^%C%A(B
#-----------------------------------------------------------------------------#
sub find_user_check {
    my ($file_nm, $user, $pass) = @_;                                   #1.4.1#
    my ($find, $c, $w, $x, $xx, $salt);                                 #1.4.1#
	
    if ( length( $user ) == 0 || length( $pass ) == 0 ){ return(0); }

    if ( ! ( open(READ,"$file_nm") ) ){ return(-1); }

    while (<READ>){
        chomp;
        $c = substr($_,0,1);
        if ( ($c eq '#') || !($c) ){
            next;
        }
        ( $w, $x ) = &Dirpasswd::get_user_check($_);
		$salt = substr($x,0,2);
		$xx = &Dirpasswd::get_password($pass,$salt);
        if ( $user eq $w && $x eq $xx ) {
            $find = 1;
            last;
        }
    }
    close READ;

    if ( !$find ){ return(0); }

    return(1);    
}

#-----------------------------------------------------------------------------#
#   get_user_check : $B%f!<%6L>$H%Q%9%o!<%I$r<hF@(B                         #1.3.1#
#-----------------------------------------------------------------------------#
#   input(1)  : 1$B%l%3!<%I$N%G!<%?(B
#-----------------------------------------------------------------------------#
#   output(1) : $B%f!<%6L>(B
#   output(2) : $B%Q%9%o!<%I(B
#-----------------------------------------------------------------------------#
sub get_user_check {
    my ($line) = @_;                                                    #1.4.1#
    my (@data);                                                         #1.4.1#

    @data = split(/:/,$line);

    if ($#data != 1) {
        return('');
    } else {
        return($data[0],$data[1]);
    }
}

#------------------------------------------------------------------------------
#   get_passwd : $B%Q%9%o!<%I$r0E9f2=(B
#------------------------------------------------------------------------------
sub get_password {
#1.3.1#    local($pw) = @_;
    my ($pw,$s) = @_;                                           #1.3.1# #1.4.1#
    my ($salt, @itoa64, $v, $n, $arr_no, $rtn);                         #1.4.1#
    @itoa64 = ('.','/','0','1','2','3','4','5','6','7','8','9',
               'A','B','C','D','E','F','G','H','I','J','K','L','M',
               'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
               'a','b','c','d','e','f','g','h','i','j','k','l','M',
               'n','o','p','q','r','s','t','u','v','w','x','y','z');	

	if ( length($s) == 2 ) {                                            #1.3.1#
		$salt = $s;                                                     #1.3.1#
	} else {                                                            #1.3.1#
        srand();
		$v = int(rand()*100000);
		$n = 2;
		while (--$n >= 0) {
	        $arr_no = $v & hex("3F");
			$salt .= $itoa64[$arr_no];
			$v >>= 6;
		}
	}                                                                  #1.3.1#
	
    $rtn = crypt($pw, $salt);
    return($rtn);
}

#------------------------------------------------------------------------------
#   passwd_file_lock : $B@lMQ(B $B%U%!%$%k%m%C%/(B
#------------------------------------------------------------------------------
sub passwd_file_lock {
    my ($lock_file)   = $_[0];                                          #1.4.1#
    my ($in_alarm_interval)   = $_[1];                                  #1.4.1#

#1.4.1#    while(!symlink(".",$lock_file)){
#1.4.1#        if(--$alarm_interval == 0 ){
#1.4.1#                return(-1);
#1.4.1#        }
#1.4.1#        sleep(1);
#1.4.1#    }
#1.4.1#    return(0);

    my @dirs = split('/',$lock_file);                                   #1.4.1#
    my $file_name = pop( @dirs );                                       #1.4.1#
    my $file_dir  = join('/',@dirs);                                    #1.4.1#
    my $real_name = ".filelock_${file_name}";                           #2.3.2#

    if ( -d $file_dir && -r $file_dir && -w $file_dir ){                #1.4.1#
		                                                                #1.4.1#
        if ( ! -r "$file_dir/$real_name" ){                             #1.4.1#
            `/bin/touch $file_dir/$real_name`;                          #1.4.1#
            unlink( $lock_file );                                       #1.4.1#
        }                                                               #1.4.1#
		my $alarm_interval = 5;                                         #1.4.1#
        if ( $in_alarm_interval =~ /^\d+$/ && $in_alarm_interval > 0 ){ #1.4.1#
            $alarm_interval = $in_alarm_interval;                       #1.4.1#
        }                                                               #1.4.1#
		my $maxlock_sec = 600;                                          #1.4.1#
		                                                                #1.4.1#
        while( ! symlink( $real_name,$lock_file ) ) {                   #1.4.1#
            if ( --$alarm_interval <= 0 ){                              #1.4.1#
                return( -1 );                                           #1.4.1#
            }                                                           #1.4.1#
            else {                                                      #1.4.1#
                my $timestmp = &Dirpasswd_timestmp( $lock_file );    #1.4.1#
                if ( $maxlock_sec > 0                                   #1.4.1#
                     && ( time - $timestmp > $maxlock_sec ) ){          #1.4.1#
                    passwd_file_unlock( $lock_file );                   #1.4.1#
                    $alarm_interval = $in_alarm_interval;               #1.4.1#
                }                                                       #1.4.1#
				else { sleep( 1 ); }                                    #1.4.1#
			}                                                           #1.4.1#
        }                                                               #1.4.1#
        return( 0 );                                                    #1.4.1#
    }                                                                   #1.4.1#
    else { return ( -1 ); }                                             #1.4.1#
}

#------------------------------------------------------------------------------
#   passwd_file_unlock : Dirpasswd.pl$B@lMQ(B $B%U%!%$%k%"%s%m%C%/(B
#------------------------------------------------------------------------------
sub passwd_file_unlock {
    my ($unun) = unlink($_[0]);                                         #1.4.1#
    return($unun);
}

#------------------------------------------------------------------------------
#   passwd_path : Dirpasswd.pl$B@lMQ(B $B%U%!%$%k%Q%9%A%'%C%/(B
#------------------------------------------------------------------------------
sub passwd_path ($) {
    my ( $in ) = shift;                                                 #1.4.1#

    $in =~ s/[^\w-_\.\/]//g;
    $in =~ s/\.\.+//g;
    return( $in );
}

#------------------------------------------------------------------------------
#   Dirpasswd_timestmp : Dirpasswd.pl$B@lMQ(B $B%U%!%$%k%?%$%`%9%?%s%W(B  V1.3.0
#------------------------------------------------------------------------------
sub Dirpasswd_timestmp (){
	my( $file ) = shift;
    my( $dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$time_stmp,
        $mtime,$ctime,$blksize,$blocks ) = lstat( $file );
    return( $mtime );
}

1;
