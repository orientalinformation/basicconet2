package Html_escape;
#----------------------------------------------------------------------------#
#     Client Name    :  ����
#     Project Name   :  �����Ѵ��ʥ��˥������󥰡�
#     Program Name   :  Html_escape.pl
#     Create Date    :  2004.05.31
#     Programmer     :  maru  (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs 
#     Notice         :  This File Code is EUC
#     Copyright      :  2004 DNP DigitalCom CO.,LTD.
#----------------------------------------------------------------------------#
#     version 1.0.0  :  2004.05.31 (maru)  New Create
#----------------------------------------------------------------------------#
#
#     ���ͳ���
#             �ǡ������ " ' < > & �򥵥˥������󥰡�̵�ǲ��ˤ�Ԥ���
#             �ޤ������Ѵ���Ԥ���
#
#     �ѥå�����������ˡ
#
#             [1] ʸ�����Ѵ�
#                 $rtn = &Html_escape::string_change( $scala ); 
#
#             [2] �ϥå����Ѵ�
#                 &Html_escape::hash_change( \%in ); 
#
#             [3] ʸ������Ѵ�
#                 $rtn = &Html_escape::string_return( $scala ); 
#
#             [4] �ϥå�����Ѵ�
#                 &Html_escape::hash_return( \%in ); 
#
#     �֤��ͤ�����
#             %in  -> name��key�Ȥ���Ϣ������
#
#     ���˥������󥰡�̵�ǲ���
#             & -> &amp;
#             " -> &quot;
#             ' -> &#39;
#             < -> &lt;
#             > -> &gt;
#
#     ���Ѵ�
#             &quot; -> "
#             &#39;  -> '
#             &lt;   -> <
#             &gt;   -> >
#             &amp;  -> &
#
#----------------------------------------------------------------------------#

use strict;
my $Html_escape_version;
&initial_setting unless defined $Html_escape_version; 

#----------------------------------------------------------------------------#
#     initial_setting : initial setting 
#----------------------------------------------------------------------------#
sub initial_setting (){ 

	$Html_escape_version = "1.0.0"; 

}

#----------------------------------------------------------------------------#
#     string_change : ʸ�����Ѵ�
#----------------------------------------------------------------------------#
sub string_change {

	my ( $d ) = @_ ; 

	$d =~ s/&/&amp;/g ;
	$d =~ s/"/&quot;/g ;
	$d =~ s/'/&#39;/g ;
	$d =~ s/</&lt;/g ;
	$d =~ s/>/&gt;/g ;

	#--- IE��&nbsp;��Ⱦ�ѥ��ڡ�����̤�Ѵ��Х��б� ---------------------------#
	$d =~ s/&amp;nbsp;/ /g ;

	return( $d ); 

}

#----------------------------------------------------------------------------#
#     string_return : ʸ������Ѵ�
#----------------------------------------------------------------------------#
sub string_return {

	my ( $d ) = @_ ; 

	$d =~ s/&quot;/"/g ;
	$d =~ s/&#39;/'/g ;
	$d =~ s/&lt;/</g ;
	$d =~ s/&gt;/>/g ;
	$d =~ s/&amp;/&/g ;

	return( $d ); 

}

#----------------------------------------------------------------------------#
#     hash_change : �ϥå����Ѵ�
#----------------------------------------------------------------------------#
sub hash_change { 
	my ( $in ) = @_; 
	my ( $n,$v ); 

    my %image_name;
    my %image_type;
    my @keys = sort keys %$in;
    foreach my $n ( @keys ) {
        if ( defined $in->{$n.'_name'} && defined $in->{$n.'_type'} ) {
            $image_name{$n.'_name'} = $n;
            $image_type{$n.'_type'} = $n;
        } elsif ( $image_name{$n} ne '' && $in->{$n} ) {
        } elsif ( $image_type{$n} ne '' && $in->{$n} ) {
        } else {
            $v = &string_change( $in->{$n} );
            $in->{$n} = $v;
        }
    }

}

#----------------------------------------------------------------------------#
#     hash_return : �ϥå�����Ѵ�
#----------------------------------------------------------------------------#
sub hash_return { 
	my ( $in ) = @_; 
	my ( $n,$v ); 

    my %image_name;
    my %image_type;
    my @keys = sort keys %$in;
    foreach my $n ( @keys ) {
        if ( defined $in->{$n.'_name'} && defined $in->{$n.'_type'} ) {
            $image_name{$n.'_name'} = $n;
            $image_type{$n.'_type'} = $n;
        } elsif ( $image_name{$n} ne '' && $in->{$n} ) {
        } elsif ( $image_type{$n} ne '' && $in->{$n} ) {
        } else {
            $v = &string_return( $in->{$n} );
            $in->{$n} = $v;
        }
    }

}

1;
