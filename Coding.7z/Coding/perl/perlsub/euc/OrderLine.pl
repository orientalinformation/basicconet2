package OrderLine;
#----------------------------------------------------------------------------#
#     Client Name    :  ����
#     Project Name   :  ���������饤���ѥ饤�֥��
#     Program Name   :  OrderLine.pl 
#     Create Date    :  2001.10.22
#     Programmer     :  Ayako Nakamura (DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  ��Ѥ�Ԥ��ץ������
#     Notice         :  This File Code is EUC
#     Copyright      :  2001 DNP DigitalCom CO.,LTD.
#----------------------------------------------------------------------------#
#     version 1.0.0  :  2001.10.22 (ayako)       New Created
#     version 1.0.1  :  2002.01.28 (ayako)       ODRDETAIL�Υ�����ȤΥХ�
#     version 1.0.2  :  2002.03.16 (ayako)       =������ȥǡ��������å����顼
#     version 1.0.3  :  2003.02.04 (ayako)       �����Ѥ�CPS�饤�֥��Ϥ���
#     version 2.0.0  :  2003.02.04 (ayako)       �Ź沽�ؿ��ɲ�
#     version 2.0.1  :  2003.02.26 (ayako)       sopen��������
#     version 3.0.0  :  2008.10.06 (Y.Nagaoka)   ��MG�ܹ��б�
#     version 3.1.0  :  2014.10.15 (y.washizu)   MGCLOUD�ܹԤ�ȼ��Date::DateCalc�λ��Ѥ�ػ�
#----------------------------------------------------------------------------#
#     comment : 2003.02 �����饤�֥�����Ͽ
#
#     ������ǻ��Ѥ��Ƥ���CPS�饤�֥��
#     CgiError.pl Security.pl
#
#     ������ǻ��Ѥ��Ƥ���perl�⥸�塼��
#     Date::DateCalc
#     MD5
#     IO::Handle 
#----------------------------------------------------------------------------#
# [1] make_order_file
#     �ʶ��ѥ쥸�ѡ˥��������ե�������������
#     IN1  �������륪�������ե�����Υѥ�
#     IN2  �������������Ϣ������Υ�ե����
#     IN3  ���ʾ����Ϣ������Υ�ե����
#     OUT1 ���顼��å�������̵�����Ϻ���OK��
#----------------------------------------------------------------------------#
# [2] chk_order_file
#     �ʶ��ѥ쥸�ѡ˥��������ե�����Υե����ޥåȤ�����å�����
#     IN1  �����å����륪�������ե�����Υѥ�
#     OUT1 ���顼��å�������̵�����ϥ����å�OK��
#----------------------------------------------------------------------------#
# [3] md5_regi
#     �ʶ��ѥ쥸�ѡ��̿��ѰŹ沽
#     IN1  SHOPNUM
#     IN2  ORDERID
#     IN3  SHOPID
#     OUT1 �Ź沽����
#----------------------------------------------------------------------------#
# [4] md5_pos
#     ��POSľ����³�ѡ��̿��ѰŹ沽
#     IN2  ORDERID
#     IN3  SHOPID
#     OUT1 �Ź沽����
#----------------------------------------------------------------------------#

#---------------------------------------------------------------------------
#   ��MG��-��������													  #3.0.0#
#---------------------------------------------------------------------------
# CPAN�⥸�塼������
BEGIN {
    my $dir;
	if($ENV{'DOCUMENT_ROOT'}){
		$dir = $ENV{'DOCUMENT_ROOT'};
	}else{
		$dir = $0;	
	}
    my ($root) = $dir =~ /^(\/[^\/]+\/[^\/]+)/;
    my $libpath = "$root/lib/cpan/lib";
    if (!(grep /$libpath/, @INC)) {
        push(@INC,$libpath);
    }
}
# ���ܥǥ��쥯�ȥ�����
my ($server_root, $hinmoku) = &get_hinmoku ();
if ($server_root eq "" || $hinmoku eq "") {
	print STDERR "hinmoku error\n";
	exit;
}

use MD5;	#3.0.0# ��MG��MD5�򥤥󥹥ȡ��뤹��ɬ�פ����롣
use IO::Handle; #2.0.1#
#2.0.1#require '/WWW/CGI/perlsub/Security.pl';
#3.0.0#require '/WWW/CGI/perlsub/CgiError.pl';
require "$server_root/$hinmoku/perl/perlsub/euc/CgiError.pl";				#3.0.0#
#----------------------------------------------------------------------------#
#     make_order_file      : ���������ե������������� 
#----------------------------------------------------------------------------#
#   $file ... �������륪�������ե�����Υѥ�
#   $order_data ... �������������Ϣ������Υ�ե����
#   $detail_data ... ���ʾ����Ϣ������Υ�ե����
#                    ���ʤ�ʣ�������硢������˹���̾������NO��Ĥ���
#----------------------------------------------------------------------------#
sub make_order_file {
    my( $file, $order_data, $detail_data) = @_;
    my($oh,$bc,$st,$sc,$dv,$od,$nn,$ln,$ty);
    my(@oh,@bc,@st,@sc,@dv,@od,%notnull,%length,%type);
    my(%order, %detail, $tbl, $name,$value,@detail_cnt,$detail_no);
    my($FH);

    #---- ���������饤��Υơ��֥륹�������������� ----#
    ($oh,$bc,$st,$sc,$dv,$od,$nn,$ln,$ty) = &get_order_interface;
    @oh = @$oh;
    @bc = @$bc;
    @st = @$st;
    @sc = @$sc;
    @dv = @$dv;
    @od = @$od;
    %notnull = %$nn;
    %length = %$ln;
    %type = %$ty;

    %order = %$order_data;
    %detail = %$detail_data;
        
    if ( -s $file ) {
        return('���˥��������ե����뤬¸�ߤ��Ƥ��ޤ���');        
    }

    $FH = new IO::Handle; #2.0.1#
#2.0.1#    &sopen('OTF','>',$file) || &CgiError::abend("file open error : $file");
    &main::sopen($FH,'>',$file) || &CgiError::abend("file open error : $file"); #2.0.1#

    foreach $tbl ('ODRHEADER','BCUSTOMER','SETTLEMENT',
             'SCUSTOMER','DELIVERY') {
#2.0.1#        print OTF "<$tbl>\n";
        print $FH "<$tbl>\n"; #2.0.1#

        undef @head;
        
        if ( $tbl eq 'ODRHEADER' ) {
            @head = @oh;
        } elsif ( $tbl eq 'BCUSTOMER' ) {
            @head = @bc;
        } elsif ( $tbl eq 'SETTLEMENT' ) {
            @head = @st;
        } elsif ( $tbl eq 'SCUSTOMER' ) {
            @head = @sc;
        } elsif ( $tbl eq 'DELIVERY' ) {
            @head = @dv;
        } else {
            &CgiError::abend("order tbl error : $tbl");
        }

        foreach $kmk(@head) {
            if ( $notnull{$tbl.':'.$kmk} eq '1' ) {
                #---- ɬ�� ----#
#2.0.1#                print OTF "$kmk=$order{$kmk}\n";
                print $FH "$kmk=$order{$kmk}\n"; #2.0.1#
            } elsif ( $order{$kmk} ne '' ) {
                #---- ɬ�ܤǤϤʤ����ǡ�������Ǽ����Ƥ��� ----#
#2.0.1#                print OTF "$kmk=$order{$kmk}\n";
                print $FH "$kmk=$order{$kmk}\n"; #2.0.1#
            }
        }

#2.0.1#        print OTF "</$tbl>\n";
        print $FH "</$tbl>\n"; #2.0.1#
    }

    #---- ���ʿ����İ� ----#
    undef @detail_cnt;
    while(($name,$value) = each %detail ) {
        if ( $name =~ /^([\d]+)/ ) {
            $detail_no = $1;
 
#1.0.1#            if ( !grep(/$detail_no/,@detail_cnt) ) {
#1.0.1#                push(@detail_cnt, $detail_no);
#1.0.1#            }
            $much_flg=0;                            #1.0.1#
            foreach $detail_cnt( @detail_cnt ) {    #1.0.1#
                if ( $detail_cnt == $detail_no ) {  #1.0.1#
                    $much_flg=1;                    #1.0.1#
                    last;                           #1.0.1#
                }                                   #1.0.1#
            }                                       #1.0.1#
            if ( !$much_flg ) {                     #1.0.1#
                push(@detail_cnt, $detail_no);      #1.0.1#
            }                                       #1.0.1#
        } else {
            return('ODRDETAIL���оݳ��Υǡ�������Ǽ����Ƥ��ޤ���');
        }
    }
    @detail_cnt = sort {$a <=> $b;} @detail_cnt;

    #---- ���ʾܺ٥ǡ����κ��� ----#
    $tbl = 'ODRDETAIL';
    @head = @od;
    foreach $detail_no(@detail_cnt) {
#2.0.1#        print OTF "<$tbl>\n";
        print $FH "<$tbl>\n"; #2.0.1#
        foreach $kmk(@head) {
            if ( $notnull{$tbl.':'.$kmk} eq '1' ) {
                #---- ɬ�� ----#
#2.0.1#                print OTF "$kmk=$detail{$detail_no.$kmk}\n";
                print $FH "$kmk=$detail{$detail_no.$kmk}\n"; #2.0.1#
            } elsif ( $detail{$detail_no.$kmk} ne '' ) {
                #---- ɬ�ܤǤϤʤ����ǡ�������Ǽ����Ƥ��� ----#
#2.0.1#                print OTF "$kmk=$detail{$detail_no.$kmk}\n";
                print $FH "$kmk=$detail{$detail_no.$kmk}\n"; #2.0.1#
            }
        }
#2.0.1#        print OTF "</$tbl>\n";
        print $FH "</$tbl>\n"; #2.0.1#
    }

#2.0.1#    close OTF;
    close $FH; #2.0.1#

    return;
}

#----------------------------------------------------------------------------#
#     chk_order_file  : ���������ե�����Υ����å�
#----------------------------------------------------------------------------#
#   $file ... �����å����륪�������ե�����
#----------------------------------------------------------------------------#
sub chk_order_file {
    my( $file ) = @_;
    my($oh,$bc,$st,$sc,$dv,$od,$nn,$ln,$ty);
    my(@oh,@bc,@st,@sc,@dv,@od,%notnull,%length,%type);
    my($line, $cnt, @err, $start_tag, $chk_kmk, $chk_value);
    my($kmk, $value, %chk_data, $detail_cnt, $tbl, $name, $i, $err);
    my( $FH );

    ($oh,$bc,$st,$sc,$dv,$od,$nn,$ln,$ty) = &get_order_interface;
    @oh = @$oh;
    @bc = @$bc;
    @st = @$st;
    @sc = @$sc;
    @dv = @$dv;
    @od = @$od;
    %notnull = %$nn;
    %length = %$ln;
    %type = %$ty;

    if (!( -s $file) ) {
        return('���������ե����뤬¸�ߤ��Ƥ��ޤ���');
    }

    $FH = new IO::Handle; #2.0.1#
#2.0.1#    &sopen('INF','<',$file) || &CgiError::abend("file open error : $file");
    &main::sopen($FH,'<',$file) || &CgiError::abend("file open error : $file"); #2.0.1#
#2.0.1#    while(<INF>) {
    while(<$FH>) { #2.0.1#
        $cnt++;
        $line = $_;
        if ( $line =~ /\n$/ && !($line =~ /\r\n$/) ) {
            chomp($line);
#1.0.2#            if ( $line =~ /(.*)=(.*)/ ) {
            if ( $line =~ /([\d\w]+)=(.*)/ ) { #1.0.2#
                #---- �ǡ����� ----#
                $chk_kmk = $1;
                $chk_value = $2;

                if ( $start_tag eq 'ODRDETAIL' ) {
                    $chk_data{$start_tag.':'.$detail_cnt.$chk_kmk} = $chk_value;
                } else {
                    $chk_data{$start_tag.':'.$chk_kmk} = $chk_value;
                }

            } elsif ( $line =~ /^<\/(.*)>$/ ) {
                #---- ����ɥ��� ----#
                if ( $start_tag eq $1 ) {
                    undef $start_tag;
                } else {
                    push(@err,"$cnt����:".'�ơ��֥륿���˸��꤬����ޤ���');
                }
            } elsif ( $line =~ /^<(.*)>$/ ) {
                #---- �������ȥ��� ----#
                if ( $start_tag eq '' ) {
                    $start_tag = $1;

                    if ( $start_tag eq 'ODRDETAIL' ) {
                        $detail_cnt++;
                    }
                } else {
                    push(@err,"$cnt����:".'�ơ��֥륿���˸��꤬����ޤ���');
                }
            } else {
                push(@err,"$cnt����:".'�ǡ��������˸��꤬����ޤ���');
            }
        } else {
            push(@err,"���ԥ����ɤ�LF�ǤϤ���ޤ���");
        }
    }
#2.0.1#    close INF;
    close $FH; #2.0.1#

    #---- ɬ�ܥ����å� ----#
    while(($kmk,$value) = each %notnull ) {
        if ( $value eq '1' ) {
            if ( $kmk =~ /(.*):(.*)/ ) {
                $tbl = $1;
                $name = $2;
                
                if ( $tbl eq 'ODRDETAIL' ) {
                    for($i=1; $i<=$detail_cnt; $i++) {
                        if ( $chk_data{$tbl.':'.$i.$name} ne '' ) {} 
                        else {
                            push(@err,"$tbl�ơ��֥롡$name��ɬ�ܹ��ܤǤ���");
                        }
                    }
                } else {
                    if ( $chk_data{$kmk} ne '' ) {}
                    else {
                        push(@err,"$tbl�ơ��֥롡$name��ɬ�ܹ��ܤǤ���");
                    }
                }
            } else {
                push(@err,"�����å����顼");
            }
        }
    }

    #---- ��󥰥��Υ����å� ----#
    while(($kmk,$value) = each %length ) {
        if ( $kmk =~ /(.*):(.*)/ ) {
            $tbl = $1;
            $name = $2;

            if ( $tbl eq 'ODRDETAIL' ) {
                for($i=1; $i<=$detail_cnt; $i++) {

                    #---- �������ο��ͤξ�� ----#
                    if ( $value =~ /([\d]+)\.([\d]+)/ ) {
                        $value = $1 + $2 + 1;
                    }

                    if ( length($chk_data{$tbl.':'.$i.$name}) > $value ) {
                        push(@err,"$tbl�ơ��֥롡$name���Х��ȿ���Ķ���Ƥ��ޤ���");
                    }
                }
            } else {
                if ( length($chk_data{$kmk}) > $value ) {
                    push(@err,"$tbl�ơ��֥롡$name���Х��ȿ���Ķ���Ƥ��ޤ���");
                }
            }
        } else {
            push(@err,"�����å����顼");
        }
    }

    #---- ���Υ����å� ----#
    while(($kmk,$value) = each %type ) {
        if ( $kmk =~ /(.*):(.*)/ ) {
            $tbl = $1;
            $name = $2;

            if ( $tbl eq 'ODRDETAIL' ) {
                for($i=1; $i<=$detail_cnt; $i++) {
                    $err = &chk_type($value,$chk_data{$tbl.':'.$i.$name});
                    if ( $err ) {
                        push(@err,"$tbl�ơ��֥롡$name��$err");
                    }
                }
            } else {
                $err = &chk_type($value,$chk_data{$kmk});
                if ( $err ) {
                    push(@err,"$tbl�ơ��֥롡$name��$err");
                }
            }
        } else {
            push(@err,"�����å����顼");
        }
    }
        
    return @err;
}

#----------------------------------------------------------------------------#
#     get_order_interface  : ���������ե�����Υ��󥿡��ե����������
#----------------------------------------------------------------------------#
#     2001/10/23 
#     ���ѥ쥸�����Х����ƥࡡDB����������ͽ� ver1.2.1 ��������
#
#     ������Ū��ɬ�ܡ�Ǥ�դι��ܤΤߺ�����
#     ���ǡ������å��ԲĹ��ܤϰʲ����󥿡��ե������˵��ܤʤ���
#     ��SCUSTOMER.SHOPNUM,ODRDETAIL.SHOPNUM,BCUNSTOMER.SHOPNUM,
#       DERYVERY.SHONUM,SETTLEMENT.SHOPNUM ��ODRHEADER.SHOPNUM��Ʊ���ʤΤ�
#       �ǡ������å����פʤΤǵ��ܤʤ���
#----------------------------------------------------------------------------#
sub get_order_interface {
    my( @orderheader, @bcustomer, @scustomer, @delivery, @orderdetail );
    my( @settlement );
    my( $notnull, $length, $type, %notnull, %length, %type );

    # ����̾ / ɬ�� / MAX�Х��ȿ� / ��
    @orderheader = ('SHOPNUM',      '1',  '9' ,  'int',   
                    'ORDERID',      '1',  '40',  'char',
                    'CATID',        '0',  '9',   'int',
                    'ORDERTKNDATE', '0',  '10',  'date',
                    'NUMOFITEM',    '1',  '9',   'int',
                    'NUMOFDEST',    '1',  '9',   'int',
                    'OHOPTION1',    '0',  '400', 'char',
                    'OHOPTION2',    '0',  '400', 'char',
                    'TESTFLAG',     '0',  '9',   'int'
                    );
    
    undef $head;
    undef $notnull;
    undef $length;
    undef $type;
    ($head, $notnull, $length, $type) = &get_arr('ODRHEADER',\@orderheader);
    @orderheader_head = @$head;
    %notnull = (%notnull, %$notnull);
    %length = (%length, %$length);
    %type = (%type, %$type);


    # ����̾ / ɬ�� / MAX�Х��ȿ� / ��
    @bcustomer = ('CATID',          '0',  '9',   'int',
                  'BCUSTOMERNUM',   '1',  '9',   'int',
                  'BCUSTOMERID',    '0',  '40',  'char',
                  'BPASSWORD',      '0',  '15',  'char',
                  'EMAIL',          '1',  '50',  'char',
                  'HANDYPHONEFLAG', '0',  '9',   'int',
                  'BCUSTOMERURL',   '0',  '255', 'char',
                  'BNAME',          '1',  '40',  'char',
                  'BNAMEKANA',      '1',  '40',  'char',
                  'NICKNAME',       '0',  '40',  'char',
                  'BIRTHDAY',       '0',  '9',   'int',
                  'SEX',            '0',  '9',   'int',
                  'TEL1',           '1',  '15',  'char',
                  'TEL2',           '0',  '15',  'char',
                  'BJCODE',         '0',  '9',   'int',
                  'BZIP',           '1',  '9',   'int',
                  'BPREFECTURE',    '1',  '10',  'char',
                  'BADDRESS',       '1',  '130', 'char',
                  'COMPNAME',       '0',  '40',  'char',
                  'COMPNAMEKANA',   '0',  '50',  'char',
                  'COMPTEL',        '0',  '15',  'char',
                  'COMPJCODE',      '0',  '9',   'int',
                  'COMPZIP',        '0',  '9',   'int',
                  'COMPPREFECTURE', '0',  '10',  'char',
                  'COMPADDRESS',    '0',  '130', 'char',
                  'DELIVERYDVSN',   '1',  '2',   'int',
                  'DMDVSN',         '0',  '2',   'int',
                  'POINT',          '0',  '9',   'int',
                  'POINTUSEFLAG',   '0',  '9',   'int',
                  'CUSLANK',        '0',  '9',   'int',
                  'CNCUPDATEFLAG',  '0',  '9',   'int',
                  'BOPTION1',       '0',  '400', 'char',
                  'BOPTION2',       '0',  '400', 'char',
                  'LASTVISIT',      '0',  '10',  'date'
                  );

    undef $head;
    undef $notnull; 
    undef $length;
    undef $type;
    ($head, $notnull, $length, $type) = &get_arr('BCUSTOMER',\@bcustomer);
    @bcustomer_head = @$head;
    %notnull = (%notnull, %$notnull);
    %length = (%length, %$length);
    %type = (%type, %$type);

    @settlement = ('CATID',         '0',  '9',   'int',
                   'SETTLEMENTID',  '0',  '9',   'int',
                   'STDATE',        '0',  '10',  'date',
                   'EDDATE',        '0',  '10',  'date',
                   'CURRENCY',      '1',  '40',  'char',
                   'TAXCODE',       '1',  '2',   'int',
                   'ORDERTKNVALUE', '0',  '9',   'int',
                   'DISCOUNTVALUE', '0',  '9',   'int',
                   'NETORDERVALUE', '1',  '9',   'int',
                   'SALESTAX',      '1',  '9',   'int',
                   'PAYMENTFEE',    '1',  '9',   'int',
                   'CARRIAGE',      '1',  '9',   'int',
                   'AMOUNT',        '1',  '9',   'int',
                   'FIRSTAMOUNT',   '0',  '9',   'int',
                   'INCOMEVALUE',   '0',  '9',   'int',
                   'CHARGEVALUE',   '0',  '9',   'int',
                   'PAYMETHODNUM',  '1',  '9',   'int',
                   'RIBOCOUNT',     '1',  '9',   'int',
                   'CARDNO',        '0',  '16',  'char',
                   'EXPIREDATE',    '0',  '9',   'int',
                   'CREDITCOMPANYNUM','0','9',   'int',
                   'SERVERNAME',    '0',  '64',  'char',
                   'AUTHNO',        '0',  '64',  'char',
                   'SETOPTION1',    '0',  '400', 'char',
                   'SETOPTION2',    '0',  '400', 'char'    
                   );

    undef $head;
    undef $notnull;
    undef $length;
    undef $type;
    ($head, $notnull, $length, $type) = &get_arr('SETTLEMENT',\@settlement);
    @settlement_head = @$head;
    %notnull = (%notnull, %$notnull);
    %length = (%length, %$length);
    %type = (%type, %$type);

    @scustomer = ('CATID',          '0',  '9',   'int',
                  'SCUSTOMERNUM',   '1',  '9',   'int',
                  'SCUSTOMERID',    '0',  '40',  'char',
                  'SNAME',          '1',  '40',  'char', 
                  'SNAMEKANA',      '0',  '40',  'char',
                  'STEL',           '1',  '20',  'char',
                  'SJCODE',         '0',  '9',   'int',
                  'SZIP',           '1',  '9',   'int',
                  'SPREFECTURE',    '1',  '10',  'char',
                  'SADDRESS',       '1',  '130', 'char',
                  'SEMAIL',         '0',  '50',  'char',
                  'SOPTION1',       '0',  '400', 'char',
                  'SOPTION2',       '0',  '400', 'char'
                  );
    undef $head;
    undef $notnull;
    undef $length;
    undef $type;
   ($head, $notnull, $length, $type) = &get_arr('SCUSTOMER',\@scustomer);
    @scustomer_head = @$head;
    %notnull = (%notnull, %$notnull);
    %length = (%length, %$length);
    %type = (%type, %$type);

    @delivery = ('CATID',           '0',  '9',   'int',
                 'DELIVERYNUM',     '1',  '9',   'int',
                 'DELIVERYID',      '0',  '40',  'char',
                 'DCOMNUM',         '1',  '9',   'int',
                 'EXPRESSFLAG',     '0',  '2',   'int',
                 'DELIVERYDATE',    '0',  '9',   'int',
                 'NIGHTFLAG',       '0',  '2',   'int',
                 'DELIVERYDVSN',    '0',  '2',   'int',
                 'DOPTION1',        '0',  '400', 'char',
                 'DOPTION2',        '0',  '400', 'char' 
                 );

    undef $head;
    undef $notnull;
    undef $length;
    undef $type;
    ($head, $notnull, $length, $type) = &get_arr('DELIVERY',\@delivery);
    @delivery_head = @$head;
    %notnull = (%notnull, %$notnull);
    %length = (%length, %$length);
    %type = (%type, %$type);

    @orderdetail = ('CATID',        '0',  '9',   'int',
                    'SCUSTOMERNUM', '1',  '9',   'int',
                    'ITEMNUM',      '1',  '9',   'int',
                    'DELIVERYNUM',  '1',  '9',   'int',
                    'SUBID',        '0',  '9',   'int',
                    'ITEMCODE',     '0',  '40',  'char',
                    'OPTIONCODE1',  '0',  '40',  'char',
                    'OPTIONCODE2',  '0',  '40',  'char',
                    'OPTIONCODE3',  '0',  '40',  'char',
                    'UNITPRICE',    '1',  '9.2', 'num',
                    'QTY',          '1',  '9',   'int',
                    'TOTALPRICE',   '1',  '9',   'char',
                    'TAXCODE',      '1',  '9.2', 'num',
                    'CATNAME',      '0',  '200', 'char',
                    'ITEMNAME',     '1',  '60',  'char',
                    'ITEMNAMEKANA', '0',  '60',  'char',
                    'OPTIONNAME1',  '0',  '40',  'char',
                    'OPTIONNAME2',  '0',  '40',  'char',
                    'OPTIONNAME3',  '0',  '40',  'char',
                    'CATEGORY1',    '0',  '40',  'char',
                    'CATEGORY2',    '0',  '40',  'char',
                    'CATEGORY3',    '0',  '40',  'char',
                    'ODOPTION1',    '0',  '400', 'char',
                    'ODOPTION2',    '0',  '400', 'char'
                    );

    undef $head;
    undef $notnull;
    undef $length;
    undef $type;
    ($head, $notnull, $length, $type) = &get_arr('ODRDETAIL',\@orderdetail);
    @orderdetail_head = @$head;
    %notnull = (%notnull, %$notnull);
    %length = (%length, %$length);
    %type = (%type, %$type);

    return(\@orderheader_head,
           \@bcustomer_head,
           \@settlement_head,
           \@scustomer_head,
           \@delivery_head,
           \@orderdetail_head,
           \%notnull,
           \%length,
           \%type);
}               


#----------------------------------------------------------------------------#
#     get_arr : ���󥿡��ե����������Ϣ������ˤ���
#----------------------------------------------------------------------------#
sub get_arr {
    my ( $tbl, $getarr ) = @_;
    my ( @arr, $i, $c, %null, %length, %type, @tbl_arr );

    @arr = @$getarr;
    for( $i=0; $i<=$#arr; $i++ ) {
        if ( $i%4 == 0 ) {
            push(@tbl_arr,$arr[$i]);
            $c = $arr[$i];
        } elsif ( $i%4 == 1 ) {
            $null{$tbl.':'.$c} = $arr[$i];
        } elsif ( $i%4 == 2 ) {
            $length{$tbl.':'.$c} = $arr[$i];
        } else {
            $type{$tbl.':'.$c} = $arr[$i];
        }
    }

    return (\@tbl_arr, \%null, \%length, \%type);
}

#----------------------------------------------------------------------------#
#     chk_type : ���Υ����å�
#----------------------------------------------------------------------------#
#     int... ����  num... ���͡ʾ����� char... ʸ���� date...����(yyyy-mm-dd)
#----------------------------------------------------------------------------#
sub chk_type {
    my($type,$chk_value) = @_;

    if ( $type eq 'char' ) {}
    elsif ( $type eq 'int' ) {
        if ( $chk_value ne '') {
#1.0.3#            if ( &Formchk::num($chk_value) ) {            
            if ( $chk_value !~ /^[\d]+$/ ) { #1.0.3#
                return ('���������������åȤ���Ƥ��ޤ���');
            }
        }
    } 
    elsif ( $type eq 'num' ) {
        if ( $chk_value ne '') {
            if ( &is_point($chk_value)) {
                return ('���ͤ����������åȤ���Ƥ��ޤ���');
            }
        }
    }
    elsif ( $type eq 'date' ) {
        if ( $chk_value ne '') {
            if ( $chk_value =~ /^(\d\d\d\d)\/(\d\d)\/(\d\d)$/ ) {
#3.1.0#                use Date::DateCalc qw( leap check_date compress );
                use Date::Calc qw(check_date);#3.1.0#
                if (!(&check_date( $1,$2,$3))) {
                    return ('���դ����������åȤ���Ƥ��ޤ���');
                }
            }
            else {
                return ('���դ����������åȤ���Ƥ��ޤ���');
            }
        }
    }
    else {
        return("�оݳ��Υ����å����顼");
    }

    return 0;
}

#-----------------------------------------------------------------------------#
#  ���������å��ʾ������ʲ�2��ޤǤΥ����å���
#-----------------------------------------------------------------------------#
sub is_point {
    my($para) = @_;
    my($wflg,@arr);

    $wflg = 0;

    $para *= 100;
    @arr = split(/\./,$para);
    if ($#arr == 0) {
        $wflg = 0;
    } else {
        $wflg = 1;
    }
    
    return $wflg;
}

#-----------------------------------------------------------------------------#
#  sub md5_regi : �Ź沽�����ѥ쥸��������
#-----------------------------------------------------------------------------#
sub md5_regi {
    my($param1, $param2, $param3) = @_;
    my ($digest, $hex,$hex1,$hex2);
    my $md5 = new MD5;

    if ( length($param1) > 0 && length($param2) > 0 && length($param3) > 0 ) {

        #---- ���ν��֤ǰŹ沽 ----#
        $md5->add("$param2"); # ORDERID
        $md5->add("$param1"); # SHOPNUM
        $md5->add("$param3"); # SHOPID

        $digest = $md5->digest();
        $hex = unpack("H*", $digest);

        $hex1 = substr($hex,0,length($hex)/2);
        $hex2 = substr($hex,length($hex)/2,length($hex)/2);
        $hex = "$hex2$hex1";

    }
    return $hex;
}

#-----------------------------------------------------------------------------#
#  sub md5_pos : �Ź沽��JCN-POS��
#-----------------------------------------------------------------------------#
sub md5_pos {
    my($param1, $param2) = @_;
    my ($digest, $hex,$hex1,$hex2);
    my $md5 = new MD5;

    if ( length($param1) > 0 && length($param2) > 0 ) {

        $md5->add("$param1");
        $md5->add("$param2");

        $digest = $md5->digest();
        $hex = unpack("H*", $digest);

        $hex1 = substr($hex,0,length($hex)/2);
        $hex2 = substr($hex,length($hex)/2,length($hex)/2);
        $hex = "$hex2$hex1";

    }
    return $hex;
}


#>>>>> get_hinmoku (version 1.0.0) >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#3.0.0#
#-----------------------------------------------------------------------------#
#   get_hinmoku : ���ܥǥ��쥯�ȥ�����
#-----------------------------------------------------------------------------#
#   output  : ���ܥǥ��쥯�ȥ�
#-----------------------------------------------------------------------------#
sub get_hinmoku
{
    my $dir;
	if($ENV{'DOCUMENT_ROOT'}){
		$dir = $ENV{'DOCUMENT_ROOT'};
	}else{
		$dir = $0;	
	}
    my $libpath = $dir.'/lib/cpan/lib';
    if (!(grep /$libpath/, @INC)) {
        push(@INC,$libpath);
    }
    my ($root, $hinmoku) = $dir =~ /^\/([^\/]+)\/([^\/]+)/;
    return ("/$root", $hinmoku);
}
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#

1;

