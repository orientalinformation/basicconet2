package SessionContainer;
#-----------------------------------------------------------------------------#
#      Client Name     : ���� (****)
#      System Name     : CPS���ѥ饤�֥��
#      Project Name    : ���å���󥳥�ƥ�����饤�֥��
#      Program Name    : SessionContainer_wc.pl
#      Create Date     : 2009.01.13
#      Programmer      : S.Yamakawa (Pro.DigitalCom.DNP)
#      Entry Server    : All
#      Called By       : All Programs
#      File Code       : EUC
#      Execute Env     : EUC
#      Copyright       : 2009 DNP.DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#      version 1.0.0   : 2009.01.13 (S.Yamakawa) willcom�б��Ѥ�New Create
#      version 2.0.0  :  2014.10.16 (y.washizu)  MGCLOUD�ܹԤ�ȼ��Date::DateCalc�λ��Ѥ�ػ�
#-----------------------------------------------------------------------------#
#      history         : /WWW/CGI/perlsub/SessionContainer.pl
#-----------------------------------------------------------------------------#
#
# [Comment]
#��
#�����å���󥳥�ƥ�����饤�֥��
#  ���å���������ˡ�ˤĤ��Ƥ϶�ͭʸ��򤴻��Ȥ���������
#  SessionContainer.pl��willcom���б���������ΤǤ���
#-----------------------------------------------------------------------------#
# [1] session_start : ���å���󥹥�����
#  my ($code,$s_id) = &SessionContainer::session_start($s_name,$term);
#  ������  �ǥ��쥯�ȥ�ϼ�ư�������ޤ��������ܥǥ��쥯�ȥ�Ϻ������ޤ���Τ�
#          ���餫�����Ѱդ��Ƥ����Ƥ������������ܥǥ��쥯�ȥ�ϡ�
#          /PUBDATA/[���ܥǥ��쥯�ȥ�]/MG_Session/V1/ �ˤʤ�ޤ���
# [Input]
#  $s_name�����å����Name
#  $term��ͭ������
# [Output]
#  $code��������(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:SessionIDȯ�ԥ��顼)
#  $s_id��SessionID
#-----------------------------------------------------------------------------#
# [2] session_check : ���å��������å�
#  my $rtn = &SessionContainer::session_check($s_name,$s_id);
# [Input]
#  $s_name : SessionName
#  $s_id : SessionID
# [Output]
#  $rtn : ������(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�)
#-----------------------------------------------------------------------------#
# [3] container_get : ����ƥʤ���Υǡ�������
#  my ($rtn,$code,$data) = &SessionContainer::container_get($s_name,$s_id[,$term]);
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#  $term : ͭ������(��ά��)
# [Output]
#  $rtn : ������(1:����,0:ͭ�������ڤ�,-1:�����ʥ��å����ID,-2:����ƥ��Ժ�)
#  $code : �ǡ���ʸ��������
#  $data : ����ƥʥǡ���(��������)
#-----------------------------------------------------------------------------#
# [4] container_set : ����ƥʥǡ���������
#  my $rtn = &SessionContainer::container_set($s_name,$s_id,$code,$data[,$term]);
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#  $code : ʸ��������
#  $data : �ǡ���(��������)
#  $term : ͭ������(��ά��)
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:SessionContainer��¸�ߤ��ʤ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
# [5] scalar2hash : �������ͤ�ϥå�����Ѵ�
#  my %hash = &SessionContainer::scalar2hash($scalar);
# [Input]
#  $scalar : Scalar
# [Output]
#  %hash : Hash
#-----------------------------------------------------------------------------#
# [6] hash2scalar : �ϥå���򥹥����ͤ��Ѵ�
#  my $scalar = &SessionContainer::hash2scalar(%hash);
# [Input]
#  %hash : Hash
# [Output]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
# [7] session_change : Session ID�ѹ�
#  my ($rtn,$new_s_id) = &SessionContainer::session_change($s_name,$s_id);
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�:,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼)
#  $new_s_id : New Session ID
#-----------------------------------------------------------------------------#
# [8] session_end : Session ��λ
#  my ($rtn) = &SessionContainer::session_end($s_name,$s_id);
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
# [Output]
#  $rtn : ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#

use Jcode;
#2.0.0#use Date::DateCalc qw(check_date calc_new_date_time);
use Date::Calc qw( check_date Add_Delta_DHMS );#2.0.0#

&initial_setting();

#-----------------------------------------------------------------------------#
# initial_setting : Initial Setting
#-----------------------------------------------------------------------------#
# [Input]
#  None
#-----------------------------------------------------------------------------#
# [Output]
#  None
#-----------------------------------------------------------------------------#
sub initial_setting{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my($server_root, $hinmei) = &get_hinmoku ();

	if($hinmei ne ''){
		$hin_dir = $hinmei;
	}else{
		print "Content-typej:text/plain;charset=Shift_JIS\n\n";
		print "Can't execute SessionContainer.pl!!\n";
	}
	
	$s_length = 39; # Session ID's Length
	$con_dir = "$server_root/$hin_dir/data/MG_Session/V1/";
	
	@fields = qw(
		start_date last_reference_date last_update_date get_cnt set_cnt
		data_code user_agent data_area
	); # Container's Data Fields
	
	#---- Check carrier ----#
	$carrier = 'WWW';
	if($ENV{HTTP_USER_AGENT} =~ /^DoCoMo/){
		$carrier = 'IMODE';
	}elsif($ENV{HTTP_USER_AGENT} =~ /^J-PHONE/
		   || $ENV{HTTP_USER_AGENT} =~ /^Vodafone/
		   || $ENV{HTTP_USER_AGENT} =~ /^MOT-/
		   || $ENV{HTTP_USER_AGENT} =~ /^SoftBank/
		  ){
		$carrier = 'SKY';
	}elsif($ENV{HTTP_USER_AGENT} =~ /^UP\.Browser/
		   || $ENV{HTTP_USER_AGENT} =~ /^KDDI-/){
		$carrier = 'WAP';
	}
	elsif(   ($ENV{HTTP_USER_AGENT} =~ /^Mozilla\// && $ENV{HTTP_USER_AGENT} =~ /\(WILLCOM;|\(DDIPOCKET;/)
		   || $ENV{HTTP_USER_AGENT} =~ /^JV-Lite2WE\//
		  ){
		$carrier = 'WILLCOM';
	}

	#---- ����μ����� ----#
	srand(time ^ ($$ + ($$ << 15)));
}

#-----------------------------------------------------------------------------#
# session_start : ���å���������������
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name�����å����Name
#  $term��ͭ������
#-----------------------------------------------------------------------------#
# [Output]
#  $code��������(1:����,0:�۾ｪλ,-1:ͭ�����»��ꥨ�顼,-2:SessionIDȯ�ԥ��顼)
#  $s_id��SessionID
#-----------------------------------------------------------------------------#
sub session_start{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$term) = @_;
	my $now = &now();

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#
	
	#---- Check item ----#
	#-- Session Name --#
	if($s_name eq ''){return(0);}
	#-- Term --#
	my $s_term = &setTerm($now,$now,$term);
	if($now > $s_term){return(-1);}
	
	#-- Make Session ID & Check --#
	my ($s_id,$s_path) = &makeSessionID($s_name);
	if(length($s_id) != $s_length){return(-2);}
	
	#---- Make Container File ----#
	#-- Set Attribute --#
	my %c;
	$c{start_date} = sprintf("%014s",$now);
	$c{last_reference_date} = sprintf("%014s",$now);
	$c{last_update_date} = sprintf("%014s",$s_term);
	$c{get_cnt} = '000000';
	$c{set_cnt} = '000000';
	$c{data_code} = 'asc ';
	$c{user_agent} = $ENV{HTTP_USER_AGENT};
	$c{carrier} = $carrier;
	$c{data_area} = '';
	
	&setSessionData($s_name,$s_id,\%c) ||
		return(0);
	
	return(1,$s_id);

}

#-----------------------------------------------------------------------------#
# session_check : ���å��������å�
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : SessionName
#  $s_id : SessionID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ������(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:����ƥʤ�¸�ߤ��ʤ�)
#-----------------------------------------------------------------------------#
sub session_check{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#-- Check Session ID ---#
	if($s_id eq '' || ($s_id ne '' && length($s_id) != $s_length)){return(-2);}
	
	#-- Search For Session Container --#
	my $data = &getSessionData($s_name,$s_id);
	if($data eq ''){return(-2);} # Not Found
	if(&now() > $$data{last_update_date}){return(0);} # Time is onver.
	return(1);
	

}

#-----------------------------------------------------------------------------#
# container_get : ����ƥʤ���Υǡ�������
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#  $term : ͭ������(��ά��)
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ������(1:����,0:ͭ�������ڤ�,-1:�����ʥ��å����ID,-2:����ƥ��Ժ�)
#  $code : �ǡ���ʸ��������
#  $data : ����ƥʥǡ���(��������)
#-----------------------------------------------------------------------------#
sub container_get{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id,$term) = @_;
	my $rtn;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#---- Check Session ----#
	my $chk = &session_check($s_name,$s_id);
	if($chk != 1){return($chk);}
	
	#---- Get Session Data ----#
	my $data = &getSessionData($s_name,$s_id);
	if($data eq ''){return(-2);} # Not Found
	if(&now() > $$data{last_update_date}){return(0);} # Time is over.
	
	#-- Set Attribute --#
	$$data{get_cnt} ++;
	$$data{last_reference_date} = &now;
	if($term ne ''){
		$$data{last_update_date} = &setTerm($$data{start_date},$$data{last_reference_date},$term);
	}
	&setSessionData($s_name,$s_id,$data);
	
	return(1,$$data{data_code},$$data{data_area});

}

#-----------------------------------------------------------------------------#
# container_set : ����ƥʥǡ���������
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#  $code : ʸ��������
#  $data : �ǡ���(��������)
#  $term : ͭ������(��ά��)
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�,-1:������SessionID,-2:SessionContainer��¸�ߤ��ʤ�,-3:����¾���顼)
#-----------------------------------------------------------------------------#
sub container_set{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id,$code,$data,$term) = @_;
	my $rtn;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#-- Check Session --#
	my $chk = &session_check($s_name,$s_id);
	if($chk != 1){return($chk);}
	
	#-- Get Session Data --#
	my $ref = &getSessionData($s_name,$s_id);
	if($ref eq ''){return(-2);} # Not Found
	if(&now() > $$ref{last_update_date}){return(0);} # Time is over.
	
	#-- Set Attribute --#
	$$ref{last_reference_date} = &now;
	$$ref{set_cnt} ++;
	$$ref{data_code} = $code;
	$$ref{data_area} = $data;
	if($term ne ''){
		$$ref{last_update_date} = &setTerm($$ref{start_date},$$ref{last_reference_date},$term);
	}
	&setSessionData($s_name,$s_id,$ref);
	return(1);
	

}

#-----------------------------------------------------------------------------#
# scalar2hash : Scalar To Hash
#-----------------------------------------------------------------------------#
# [Input]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
# [Output]
#  %hash : Hash
#-----------------------------------------------------------------------------#
sub scalar2hash{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($scalar) = @_;
	my %hash;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#
	
	foreach my $row(split(/\n/,$scalar)){
		$row =~ /^([^=]*)=([^\n]*)/;
		my ($n,$v) = ($1,$2);
		if($n =~ /^([^\n]*)\[([^\n]*)\]/){
			if($2 =~ /[^0-9]*/){ # Hash
				$hash{$1}->{$2} = $v;
			}else{ # Array
				$hash{$1}->[$2] = $v;
			}
		}else{
			$hash{$n} = $v;
		}
	}
	
	return(%hash);

}

#-----------------------------------------------------------------------------#
# hash2scalar : Hash To Scalar
#-----------------------------------------------------------------------------#
# [Input]
#  %hash : Hash
#-----------------------------------------------------------------------------#
# [Output]
#  $scalar : Scalar
#-----------------------------------------------------------------------------#
sub hash2scalar{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my (%hash) = @_;
	my $scalar;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	while(my ($n,$v) = each(%hash)){
		if($v =~ /^ARRAY\([^\0]*\)/){
			for(my $i = 0;$i < (@$v);$i ++){
				$scalar .= "$n\[$i\]=$v->[$i]\n";
			}
		}elsif($v =~ /^HASH\([^\0]*\)/){
			while(my ($nn,$vv) = each(%$v)){
				$scalar .= "$n\{$nn\}=$vv\n";
			}
		}else{
			$scalar .= "$n=$v\n";
		}
	}
	
	return($scalar);

}


#-----------------------------------------------------------------------------#
# session_change : Session ID�ѹ�
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:ͭ�������ڤ�:,-1:������Session ID,-2:Container�Ժ�,-3:Session IDȯ�ԥ��顼)
#  $new_s_id : New Session ID
#-----------------------------------------------------------------------------#
sub session_change{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#-- Check Session --#
	my $chk = &session_check($s_name,$s_id);
	if($chk != 1){return($chk);}
	
	#-- Get Session Data --#
	my $data = &getSessionData($s_name,$s_id);
	if($data eq ''){return(-2);}
	if(&now > $$data{last_update_date}){return(0);}
	
	#-- Make Session ID --#
	my ($new_s_id,$s_path) = &makeSessionID($s_name);
	if(length($new_s_id) != $s_length){return(-3);}
	
	#-- Set Attribute --#
	$$data{session_id} = $new_s_id;
	&setSessionData($s_name,$new_s_id,$data);
	&session_end($s_name,$s_id);
	
	return(1,$new_s_id);

}

#-----------------------------------------------------------------------------#
# session_end : Session ��λ
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(1:OK,0:�۾ｪλ,-1:������Session ID,-2:Container�Ժ�)
#-----------------------------------------------------------------------------#
sub session_end{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if(length($s_id) != $s_length){return(-1);}
	
	my $s_path = &getSessionPath($s_name,$s_id);
	if(-s $s_path){
		unlink($s_path);
		return(1);
	}else{
		return(-2);
	}

}

#-----------------------------------------------------------------------------#
#  �饤�֥�����ѥ饤�֥��
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# getSessionPath : Session�ե�����ѥ������
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session̾
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $path : �ե�����ѥ�
#-----------------------------------------------------------------------------#
sub getSessionPath{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my $path = "$con_dir$s_name/Container/$carrier/" .
		substr($s_id,0,8) . "/" .
		substr($s_id,8,2) . "/" .
		substr($s_id,10,2) . "/" .
		substr($s_id,12) . ".txt";
	
	return($path);

}

#-----------------------------------------------------------------------------#
# setTerm : ���ꤷ��ͭ�����¤�����
#-----------------------------------------------------------------------------#
# [Input]
#  $s_date : Session������
#  $a_date : �ǽ�������������
#  $term : ͭ������
#-----------------------------------------------------------------------------#
# [Output]
#  $t_date : ͭ����������
#-----------------------------------------------------------------------------#
sub setTerm{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_date,$a_date,$term) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if(length($term) == 14){ # ���ջ���
		$term =~ /(....)(..)(..)(..)(..)(..)/;
		if(check_date($1,$2,$3)){
			if(($4 >= 0 && $4 < 24) && ($5 >= 0 && $5 < 60) && ($6 >= 0 && $6 < 60)){
				return($term);
			}
		}
	}else{ # ���л���
		$term =~ /^(S|L)([0-9]*)(D|H|M|S)$/;
		if($1 ne '' && $3 ne ''){
			my $date;
			if($1 eq 'S'){
				$date = $s_date;
			}elsif($1 eq 'L'){
				$date = $a_date;
			}
			my ($dd,$dh,$dm,$ds) = (0,0,0,0);
			if($3 eq 'D'){
				$dd = $2;
			}elsif($3 eq 'H'){
				$dh = $2;
			}elsif($3 eq 'M'){
				$dm = $2;
			}elsif($3 eq 'S'){
				$ds = $2;
			}
			$date =~ /^(....)(..)(..)(..)(..)(..)/;
#2.0.0#			my ($y,$m,$d,$hh,$mm,$ss) = calc_new_date_time($1,$2,$3,$4,$5,$6,$dd,$dh,$dm,$ds);
			my ($y,$m,$d,$hh,$mm,$ss) = &Date::Calc::Add_Delta_DHMS($1,$2,$3,$4,$5,$6,$dd,$dh,$dm,$ds);#2.0.0#
			return(sprintf("%04d%02d%02d%02d%02d%02d",$y,$m,$d,$hh,$mm,$ss));
		}
	}

}

#-----------------------------------------------------------------------------#
# getSessionData : Session����ƥʥǡ�������
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session Name
#  $s_id : Session ID
#-----------------------------------------------------------------------------#
# [Output]
#  $ref : ����ƥʥǡ���(Hash Ref)
#-----------------------------------------------------------------------------#
sub getSessionData{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id) = @_;
	my $s_path = &getSessionPath($s_name,$s_id);

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	if(-s $s_path){
		
		&session_sopen(IN,'<',$s_path) ||
			return();
		my %ref;
		my $cnt = 0;
		while(<IN>){
			s/(\r|\n)//g;
			if($cnt < (@fields) - 1){
				$ref{$fields[$cnt]} = $_;
				$ref{$fields[$cnt]} =~ s/([\s]*)$//g;
				$cnt ++;
			}else{
				$ref{data_area} .= $_ . "\n";
			}
		}
		close(IN);
		return(\%ref);
	}

}

#-----------------------------------------------------------------------------#
# setSessionData : Session����ƥʥǡ�������
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session̾
#  $s_id : Session ID
#  $data : �ǡ���
#-----------------------------------------------------------------------------#
# [Output]
#  $rtn : ���(0:NG,1:OK)
#-----------------------------------------------------------------------------#
sub setSessionData{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name,$s_id,$data) = @_;
	my $s_path = &getSessionPath($s_name,$s_id);

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#
	
	$$data{start_date} = sprintf("%014s      ",$$data{start_date});
	$$data{last_reference_date} = sprintf("%014s      ",$$data{last_reference_date});
	$$data{last_update_date} = sprintf("%014s      ",$$data{last_update_date});
	$$data{get_cnt} = sprintf("%06d",$$data{get_cnt});
	$$data{set_cnt} = sprintf("%06d",$$data{set_cnt});
	$$data{data_code} = sprintf("%- 4s",$$data{data_code});
	$$data{user_agent} = sprintf("%- 255s",$$data{user_agent});
	my $buf;
	foreach(@fields){
		$buf .= $$data{$_} . "\n";
	}
	chomp($buf);
	
	&session_sopen(OUT,'>',$s_path) ||
		return(0);
	print OUT $buf;
	close(OUT);
	
	return(1);

}

#-----------------------------------------------------------------------------#
# makeSessionID : Make Session ID
#-----------------------------------------------------------------------------#
# [Input]
#  $s_name : Session Name
#-----------------------------------------------------------------------------#
# [Output]
#  $s_id : Session ID
#  $s_path : Session Path
#-----------------------------------------------------------------------------#
sub makeSessionID{

    #-------------------------------------------------------------------------#
    #                            Local Configration                           #
    #-------------------------------------------------------------------------#

	my ($s_name) = @_;

    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	#-- Make Basic Directory --#
	my $s_path;
	foreach("$con_dir$s_name/","Container/","$carrier/"){
		$s_path .= $_;
		unless(-d $s_path){
			mkdir($s_path,0777) ||
				return(0);
		}
	}
	
	#---- Make Session ID ----#
	my $s_id;
	foreach(split(/\./,$ENV{SERVER_ADDR})){
		$s_id .= sprintf("%02x",$_);
	}
	my $r = int(rand("10000"));
	$s_id .= sprintf("%04d",int("$r"));
	foreach(split(/\./,$ENV{REMOTE_ADDR})){
		$s_id .= sprintf("%02x",$_);
	}

	if($ENV{UNIQUE_ID} ne '' &&
		length($ENV{UNIQUE_ID}) == 19){ # UNIQUE_ID is Alive & Length is 19.
		$s_id .= $ENV{UNIQUE_ID};
	}else{ # Other
		$s_id .= sprintf("%011d",time);
		$s_id .= sprintf("%08d",$$);
	}
	
	#---- Make Session Container's Directory ----#
	my $ss = 0;
	foreach("8","2","2"){
		$s_path .= substr($s_id,$ss,$_) . "/";
		unless(-d $s_path){
			mkdir($s_path,0777) ||
				return(0);
		}
		$ss += $_;
	}
	$s_path = &getSessionPath($s_name,$s_id);
	if(-s $s_path){return(0);}
	
	return($s_id,$s_path);
	
}

#-----------------------------------------------------------------------------#
# now : �����֤����
#-----------------------------------------------------------------------------#
# [Input]
#  None
#-----------------------------------------------------------------------------#
# [Output]
#  $now : ������(YYYYMMDDhhmmss)
#-----------------------------------------------------------------------------#
sub now{


    #-------------------------------------------------------------------------#
    #                               Local Process                             #
    #-------------------------------------------------------------------------#

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
	
	$year += 1900;
	$mon ++;
	return(sprintf("%04d%02d%02d%02d%02d%02d",$year,$mon,$mday,$hour,$min,$sec));
	

}


#-----------------------------------------------------------------------------#
#  ��¸�饤�֥�꤫��Υѥ���
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
#    sub session_sopen : �������ƥ��ݸǽ�����ե�����OPEN
#-----------------------------------------------------------------------------#
#    input  : (1) �ե�����ϥ�ɥ�
#    input  : (2) �����ϥ�����쥯�ȡ� <,>,>>,| ��
#    input  : (3) �оݥե�����̾
#    input  : (4) �ѥ��ץ��ޥ��( 1..n : ���֤˵�ư�����
#-----------------------------------------------------------------------------#
#    output : (1) �꥿���󥳡���( 1:����,0:�۾ｪλ ��
#-----------------------------------------------------------------------------#
sub session_sopen {
	my( $fhd, $io, $in_file, @in_com ) = @_;
	my( $file, $com, @com, $wk, $rtn );

	$file = &session_path( $in_file ); 
	foreach $com(@in_com){ push( @com,&session_meta($com) ); }
	undef $wk;
	undef $rtn; 
	if ( $io eq '<' ){
		if ( @com ){
			$com = shift( @com ); 
			$wk .= "$com $file |";
			foreach $com( @com ){ $wk .= "$com |"; }
		}
		else { $wk .= "$file"; }
	}
	elsif ( $io eq '>' || $io eq '>>' ){
		if ( @com ){
			foreach $com( @com ){ $wk .= "| $com "; }
			$wk .= "$io $file";
		}
		else { $wk .= "$io $file"; }
	}
	elsif ( $io eq '|' ){
		$com = shift( @com ); 
		$wk .= "| $com";
		if ( @com ){
			foreach $com( @com ){ $wk .= " | $com"; }
		}
	}
	if ( $wk ){ $rtn = open( $fhd,$wk ); }

	return( $rtn ); 
}

#-----------------------------------------------------------------------------#
#    sub session_meta : �ǡ����椫������ʥ᥿ʸ������
#-----------------------------------------------------------------------------#
#    input  : (1) �Ѵ���ʸ����
#-----------------------------------------------------------------------------#
#    output : (1) �Ѵ���ʸ����
#-----------------------------------------------------------------------------#
sub session_meta {
	my( $in ) = shift; 
     
	$in =~ s/([;<>\*\|&\$!#\(\)\[\]\{\}:\'\"])//g;
	return( $in );
}

#-----------------------------------------------------------------------------#
#    sub session_path : �ե�����ѥ��Ȥ��ƻ��Ѳ�ǽ��ʸ����ʳ���ʸ�����������
#-----------------------------------------------------------------------------#
#    input  : (1) �Ѵ���ʸ����
#-----------------------------------------------------------------------------#
#    output : (1) �Ѵ���ʸ����
#-----------------------------------------------------------------------------#
sub session_path {
	my( $in ) = shift; 
    
	$in =~ s/[^\w\-_\.\/\@]//g;
	$in =~ s/\.\.+//g;
	return( $in ); 
}

#------------------------------------------------------------------------------
#   session_ssystem : �������ƥ��ݸǽ���� ���ޥ�ɵ�ư ( system )
#------------------------------------------------------------------------------
sub session_ssystem () {
	my( @in_com ) = @_;
	my( $com, @com );

	foreach $com (@in_com) {
		if ( $com eq '|' || $com eq '<' || $com eq '>' || $com eq '>>'
			 || $com eq ';' || $com eq '*' || $com eq '?' ) {
			push( @com,$com );
		}
		else { push( @com, &session_meta($com) ); }
	}
	$com = join(' ',@com);

	return ( system( $com ) );
}

#>>>>> get_hinmoku (version 1.0.0) >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#-----------------------------------------------------------------------------#
#   get_hinmoku : ���ܥǥ��쥯�ȥ�����
#-----------------------------------------------------------------------------#
#   output  : ���ܥǥ��쥯�ȥ�
#-----------------------------------------------------------------------------#
sub get_hinmoku
{
    my $dir;
	if($ENV{'DOCUMENT_ROOT'}){
		$dir = $ENV{'DOCUMENT_ROOT'};
	}else{
		$dir = $0;	
	}
    my $libpath = $dir.'/lib/cpan/lib';
    if (!(grep /$libpath/, @INC)) {
        push(@INC,$libpath);
    }
    my ($root, $hinmoku) = $dir =~ /^\/([^\/]+)\/([^\/]+)/;
    return ("/$root", $hinmoku);
}
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
1;
