package DbmDirpasswd;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  Directory Password 制御ライブラリ (DBM)
#     Program Name   :  DbmDirpasswd.pl
#     Create Date    :  2010.11.30
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.30 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ DbmDirpasswd.pl version 1.5.0 を元に
#                       リニューアル新規作成
#-----------------------------------------------------------------------------#
#  [1] add_user ディレクトリパスワード追加
#      引数1 $file_nm.... パスワードファイルのパス
#      引数2 $user....... ユーザ名
#      引数3 $passwd..... パスワード
#      戻り値............ 1:正常終了 0:異常終了
#
#      ＊ファイルが存在しない場合、新規作成
#-----------------------------------------------------------------------------#
#  [2] upd_user ディレクトリパスワード更新
#      引数1 $file_nm.... パスワードファイルのパス
#      引数2 $user....... ユーザ名
#      引数3 $passwd..... パスワード
#      戻り値............ 1:正常終了  0:異常終了
#
#      ＊ユーザが存在しない場合、追加。ファイルが存在しない場合新規作成
#-----------------------------------------------------------------------------#
#  [3] del_user ディレクトリパスワード削除
#      引数1 $file_nm.... パスワードファイルのパス
#      引数2 $user....... ユーザ名
#      戻り値............ 1:正常終了  0:異常終了
#-----------------------------------------------------------------------------#
#  [4] find_user ユーザ検索
#      引数1 $file_nm.... パスワードファイルのパス
#      引数2 $user....... ユーザ名
#      戻り値............ 1:合致 0:合致しない -1:異常終了
#-----------------------------------------------------------------------------#
#  [5] get_password 暗号化パスワードを取得 (※メインからは通常呼び出さない)
#      引数1 $pw........ パスワード
#      戻り値 .......... 暗号化した文字列
#-----------------------------------------------------------------------------#
#  [6] password_check DBMに設定されているパスワードの正当性チェック
#      引数1 $file_nm.... パスワードファイルのパス
#      引数2 $user....... ユーザ名
#      引数3 $pass ...... パスワード 
#      戻り値............ 1:正当 0:不当 -1:ユーザ設定なし -2:異常終了
#-----------------------------------------------------------------------------#
use utf8;
use Encode;

my $version = "1.0.0";
my $library_name = 'DbmDirpasswd.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#------------------------------------------------------------------------------
#   add_user : ディレクトリパスワード追加
#------------------------------------------------------------------------------
sub add_user {
	my ($file_nm, $user, $passwd) = @_;
	my ($cpw, %kmk);

	if ( length( $user ) > 0 && length( $passwd ) > 0 ){
		$file_nm = &passwd_path( $file_nm );
		$cpw = &get_password( $passwd );
		if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			&passwd_file_unlock("$file_nm.lk");
			return(0);
		}
		else {
			$kmk{$user} = Encode::encode('utf8', "$cpw");
			dbmclose %kmk;
			&passwd_file_unlock("$file_nm.lk");
			return(1);
		}
	}
	else { return(0); }
}

#------------------------------------------------------------------------------
#   upd_user : ディレクトリパスワード更新
#------------------------------------------------------------------------------
sub upd_user {
	my ($file_nm, $user, $passwd) = @_;
	my ($cpw, %kmk);

	if ( length( $user ) > 0 && length( $passwd ) > 0 ){
		$file_nm = &passwd_path($file_nm);
		$cpw = &get_password($passwd);
		if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			&passwd_file_unlock("$file_nm.lk");
			return(0);
		}
		else {
			$kmk{$user} = Encode::encode('utf8', "$cpw");
			dbmclose %kmk;
			&passwd_file_unlock("$file_nm.lk");
			return(1);
		}
	}
	else { return(0); }
}

#------------------------------------------------------------------------------
#   del_user : ディレクトリパスワード削除
#------------------------------------------------------------------------------
sub del_user {
	my ( $file_nm, $user ) = @_;
	my ( $cpw, %kmk );

	if ( length( $user ) > 0 ){
		$file_nm = &passwd_path( $file_nm );
		if ( &passwd_file_lock("$file_nm.lk",15) ){ return(0); }
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			&passwd_file_unlock("$file_nm.lk");
			return(0);
		}
		else {
			delete $kmk{$user};
			dbmclose %kmk;
			&passwd_file_unlock("$file_nm.lk");
			return(1);
		}
	}
	else { return(0); }
}

#------------------------------------------------------------------------------
#   find_user : ユーザ検索
#------------------------------------------------------------------------------
sub find_user {
	my ( $file_nm, $user ) = @_;
	my ( $rtn, %kmk );

	if ( length( $user ) > 0  ){
		$file_nm = &passwd_path($file_nm);
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			return( -1 );
		}
		else { 
			$rtn = 0; 
			if ( $kmk{$user} ){ $rtn = 1; }
			else              { $rtn = 0; }
		}
		dbmclose %kmk;
		return($rtn);
	}
	else { return(0); }
}

#------------------------------------------------------------------------------
#   password_check : パスワードの正当性チェック
#------------------------------------------------------------------------------
sub password_check {
	my ( $file_nm, $user, $pass ) = @_;
	my ( $rtn, %kmk );

	if ( length( $user ) > 0 && length( $pass ) > 0 ){
		$file_nm = &passwd_path( $file_nm );
		if ( ! ( dbmopen( %kmk,"$file_nm",0666 ) ) ) {
			return( -2 );
		}
		else {
			if ( defined $kmk{$user} ){
				if ( crypt( $pass, $kmk{$user}) eq $kmk{$user} ){
					$rtn = 1;	# パスワードが正当
				}
				else {
					$rtn = 0;	# パスワードが間違っている
				}
			}
			else {
				$rtn = -1;		# ユーザが存在しない場合
			}
		}
		dbmclose %kmk;
		return( $rtn );
	}
	else { return( -2 ); }
}

#------------------------------------------------------------------------------
#   get_password : パスワードを暗号化
#------------------------------------------------------------------------------
sub get_password {
	my ($pw) = @_;
	my ($salt, @itoa64, $v, $n, $arr_no, $rtn);

	@itoa64 = ('.','/','0','1','2','3','4','5','6','7','8','9',
			   'A','B','C','D','E','F','G','H','I','J','K','L','M',
			   'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
			   'a','b','c','d','e','f','g','h','i','j','k','l','M',
			   'n','o','p','q','r','s','t','u','v','w','x','y','z');

	$v = int(rand()*100000);
	$n = 2;
	while (--$n >= 0) {
		$arr_no = $v & hex("3F");
		$salt .= $itoa64[$arr_no];
		$v >>= 6;
	}

	$rtn = crypt($pw, $salt);
	return($rtn);
}

#------------------------------------------------------------------------------
#   passwd_file_lock : 専用 ファイルロック
#------------------------------------------------------------------------------
sub passwd_file_lock {
	my ($lock_file)   = $_[0];
	my ($in_alarm_interval)   = $_[1];

	my @dirs = split('/',$lock_file);
	my $file_name = pop( @dirs );
	my $file_dir  = join('/',@dirs);
	my $real_name = ".filelock_${file_name}";

	if ( -d $file_dir && -r $file_dir && -w $file_dir ){
		if ( ! -r "$file_dir/$real_name" ){
			`/bin/touch $file_dir/$real_name`;
			unlink( $lock_file );
		}
		my $alarm_interval = 5;
		if ( $in_alarm_interval =~ /^[0-9]+$/ && $in_alarm_interval > 0 ){
			$alarm_interval = $in_alarm_interval;
		}
		my $maxlock_sec = 600;

		while( ! symlink( $real_name,$lock_file ) ) {
			if ( --$alarm_interval <= 0 ){
				return( -1 );
			}
			else {
				my $timestmp = &DbmDirpasswd_timestmp( $lock_file );
				if ( $maxlock_sec > 0 
						&& ( time - $timestmp > $maxlock_sec ) ){
					passwd_file_unlock( $lock_file );
					$alarm_interval = $in_alarm_interval;
				}
				else { sleep( 1 ); }
			}
		}
		return( 0 );
	}
	else { return ( -1 ); }
}

#------------------------------------------------------------------------------
#   passwd_file_unlock : DbmDirpasswd.pl専用 ファイルアンロック
#------------------------------------------------------------------------------
sub passwd_file_unlock {
	my ($unun) = unlink($_[0]);
	return($unun);
}

#------------------------------------------------------------------------------
#   passwd_path : DbmDirpasswd.pl専用 ファイルパスチェック
#------------------------------------------------------------------------------
sub passwd_path () {
	my ( $in ) = shift;

	$in =~ s/[^a-zA-Z0-9\-_\.\/]//g;
	$in =~ s/\.\.\+//g;

	return( $in );
}

#------------------------------------------------------------------------------
#   DbmDirpasswd_timestmp : DbmDirpasswd.pl専用 ファイルタイムスタンプ
#------------------------------------------------------------------------------
sub DbmDirpasswd_timestmp (){
	my( $file ) = shift;
	my( $dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$time_stmp,
		$mtime,$ctime,$blksize,$blocks ) = lstat( $file );
	return( $mtime );
}

1;
