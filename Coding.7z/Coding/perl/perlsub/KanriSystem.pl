package KanriSystem;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  管理画面個人情報利用ライブラリ
#     Program Name   :  KanriSystem.pl
#     Create Date    :  2010.11.30
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.30 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ KanriSystem.pl version 1.2.0 を
#                       UTF-8 にしてリニューアル新規作成
#-----------------------------------------------------------------------------#
#     comment : 
#
#     <処理概要>
#
#        管理画面において動作させるプログラムについては、必ず当ライブラリを
#        利用する運用とする。（個人情報流出対策）
#        また、個人情報を扱う場合には必ず個人情報利用フラグに「1」を設定する。
#
#     <利用方法>
#
#        require '/WWW/[品目dir]/perl/perlsub/KanriSystem.pl';
#
#        &KanriSystem::check(1);
#
#     <注意点>
#
#        当ライブラリはブラウザから呼ばれるプログラムを前提とします。
#        クローンなどのバッチプログラムで呼ばれるプログラムでは利用できません。
#
#        個人情報を利用するプログラムの動作環境は、SSLで/System/ディレクトリ
#        配下である必要があります。
#
#     <処理関数詳細>
#
#        [1] 動作環境チェック
#
#        &KanriSystem::check( 個人情報利用フラグ );
#
#        個人情報利用フラグ
#          0・・・個人情報の利用なし
#          1・・・個人情報の利用あり
#
#-----------------------------------------------------------------------------#
use utf8;
use Encode;

my $version = "1.0.0";
my $library_name = 'KanriSystem.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#     check : 動作環境チェック
#-----------------------------------------------------------------------------#
#     input(1) : 個人情報利用フラグ
#-----------------------------------------------------------------------------#
sub check {

	my ( $flg ) = @_;
	my ( $html, $s_name );

	$s_name = $ENV{'SCRIPT_FILENAME'};

	if ( $flg == 1 && ( $s_name !~ /\/https\/CGI\// || $s_name !~ /\/System.*\// ) ) {
		$html  = "<html><head><title>動作環境エラー"; 
		$html .= "</title></head>\n";
		$html .= "<body>\n"; 
		$html .= "<hr>\n"; 
		$html .= "<br>この環境では閲覧することができません。<br><br>\n"; 
		$html .= "<hr>\n"; 
		$html .= "</body></html>\n";

		print "Content-Type: text/html; charset=UTF-8\n\n";
		print Encode::encode('utf8', "$html");

		exit;
	}

}

1;
