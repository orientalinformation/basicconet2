package StringConvert;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  データ変換ライブラリ
#     Program Name   :  StringConvert.pl
#     Create Date    :  2010.11.11
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (H.Noguchi) New Create
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ StringConvert.pl version 1.1.1 を元に
#                       リニューアル新規作成
#-----------------------------------------------------------------------------#
#
#     仕様概要
#             フォームから送信されたデータに対し、データの変換を行う。
#             各項目に対し、指定されたオプションで変換や削除を行う。
#             項目中のデータ全てがNULLの場合は無条件に削除を行う。
#
#     パッケージ使用方法
#
#             [1] データ変換（ハッシュ版）
#                 &StringConvert::hash( \%in, \%opt, \%notkmk );
#                   input (1) \%in     .......... WWWDecodeからの入力データ
#                   input (2) \%opt    .......... 変換指定オプション
#                   input (3) \%notkmk .......... 変換除外指定オプション
#
#             [2] データ変換（文字列版）
#                 $data = &StringConvert::string( $scala, \%opt );
#                   input (1) $scala ............ 変換元データ
#                   input (2) \%opt  ............ 変換オプション
#                   output(1) $data  ............ 変換後データ
#
#
#-----------------------------------------------------------------------------#

use strict;
use utf8;

my $version = "1.0.0";
my $library_name = 'StringConvert.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#   sub hash : データ変換（ハッシュ版）
#-----------------------------------------------------------------------------#
#   input  : (1) WWWDecodeからの入力データ
#   input  : (2) 変換指定オプション
#   input  : (3) 変換除外指定オプション
#-----------------------------------------------------------------------------#
sub hash {

	my ( $in, $opt_hash, $notkmk_hash ) = @_;

	my %image_name;
	my %image_type;
	my @keys = sort keys %$in;
	foreach my $n ( @keys ) {
		if ( defined $in->{$n.'_name'} && defined $in->{$n.'_type'} ) {
			$image_name{$n.'_name'} = $n;
			$image_type{$n.'_type'} = $n;
		} elsif ( $image_name{$n} ne '' && $in->{$n} ) {
		} elsif ( $image_type{$n} ne '' && $in->{$n} ) {
		} else {
			#--- 除外項目の抽出 ----------------------------------------------#
			my ( %notkmk );
			my @notkmk_keys = keys %$notkmk_hash;
			foreach my $n2 ( @notkmk_keys ) {
				my @work = split(/\//, $notkmk_hash->{$n2});
				foreach my $notkmk_name ( @work ) {
					if ( $n eq $notkmk_name ) {
						$notkmk{$n2} = 1;
					}
				}
			}

			my $v = &string( $in->{$n}, $opt_hash, \%notkmk );
			$in->{$n} = $v;
		}
	}


}

#-----------------------------------------------------------------------------#
#   sub string : データ変換（文字列版）
#-----------------------------------------------------------------------------#
#   input  : (1) 変換元データ
#   input  : (2) 変換指定オプション
#   input  : (3) 変換除外指定オプション
#-----------------------------------------------------------------------------#
#   output : (1) 変換後データ
#-----------------------------------------------------------------------------#
sub string {

	my ( $scala, $opt_hash, $notkmk_hash ) = @_;

	#--- ASCII制御コードを削除（NULL,改行,TABは除く）
	$scala =~ s/[\x01-\x08]|[\x0B-\x0C]|[\x0E-\x1F]|\x7F//g;

	#--- C1集合制御コードを削除
	$scala =~ s/[\x80-\xA0]|\xAD//g;

	#--- 全てがNULLは無条件に削除
	$scala =~ s/^\0+$//;

	#--- データ中のタブの変換
	if ( defined $opt_hash->{'in_tab'} && $notkmk_hash->{'in_tab'} != 1 ) {
		$scala =~ s/\t/$opt_hash->{'in_tab'}/g;
	}

	#--- 全てが半角スペースならば変換
	if ( defined $opt_hash->{'all_h_sp'} && $notkmk_hash->{'all_h_sp'} != 1 ) {
		$scala =~ s/^ +$/$opt_hash->{'all_h_sp'}/o;
	}

	#--- 全てが全角スペースならば変換
	if ( defined $opt_hash->{'all_z_sp'} && $notkmk_hash->{'all_z_sp'} != 1 ) {
		$scala =~ s/^\x{3000}+$/$opt_hash->{'all_z_sp'}/o;
	}

	#--- 全てが半角と全角スペースならば変換
	if ( defined $opt_hash->{'all_hz_sp'} && $notkmk_hash->{'all_hz_sp'} != 1 ) {
		$scala =~ s/^\s+$/$opt_hash->{'all_hz_sp'}/o;
	}

	#--- 先頭の半角スペースを変換
	if ( defined $opt_hash->{'top_h_sp'} && $notkmk_hash->{'top_h_sp'} != 1 ) {
		$scala =~ s/^ +/$opt_hash->{'top_h_sp'}/o;
	}

	#--- 先頭の全角スペースを変換
	if ( defined $opt_hash->{'top_z_sp'} && $notkmk_hash->{'top_z_sp'} != 1 ) {
		$scala =~ s/^\x{3000}+/$opt_hash->{'top_z_sp'}/o;
	}

	#--- 先頭の半角と全角スペースを変換
	if ( defined $opt_hash->{'top_hz_sp'} && $notkmk_hash->{'top_hz_sp'} != 1 ) {
		$scala =~ s/^\s+/$opt_hash->{'top_hz_sp'}/o;
	}

	#--- 末尾の半角スペースを変換
	if ( defined $opt_hash->{'end_h_sp'} && $notkmk_hash->{'end_h_sp'} != 1 ) {
		$scala =~ s/ +$/$opt_hash->{'end_h_sp'}/o;
	}

	#--- 末尾の全角スペースを変換
	if ( defined $opt_hash->{'end_z_sp'} && $notkmk_hash->{'end_z_sp'} != 1 ) {
		$scala =~ s/\x{3000}+$/$opt_hash->{'end_z_sp'}/o;
	}

	#--- 末尾の半角と全角スペースを変換
	if ( defined $opt_hash->{'end_hz_sp'} && $notkmk_hash->{'end_hz_sp'} != 1 ) {
		$scala =~ s/\s+$/$opt_hash->{'end_hz_sp'}/o;
	}

	#--- データ中の半角スペースを変換
	if ( defined $opt_hash->{'in_h_sp'} && $notkmk_hash->{'in_h_sp'} != 1 ) {
		$scala =~ s/ +/$opt_hash->{'in_h_sp'}/g;
	}

	#--- データ中の全角スペースを変換
	if ( defined $opt_hash->{'in_z_sp'} && $notkmk_hash->{'in_z_sp'} != 1 ) {
		$scala =~ s/\x{3000}+/$opt_hash->{'in_z_sp'}/g;
	}

	#--- データ中の半角と全角スペースを変換
	if ( defined $opt_hash->{'in_hz_sp'} && $notkmk_hash->{'in_hz_sp'} != 1 ) {
		$scala =~ s/\s+/$opt_hash->{'in_hz_sp'}/g;
	}

	# --- 改行コードをまとめて別の変数に格納
	my $str = $scala;
	$str =~ s/\x0D\x0A/\x0A/g;
	$str =~ s/\x0D/\x0A/g;
	# --- すべてが改行ならば変換
	if ( defined $opt_hash->{'all_cr'} && $notkmk_hash->{'all_cr'} != 1 ) {
		if ($str =~ /^\x0A+$/) {
			$scala = $opt_hash->{'all_cr'};
		}
	}

	# --- 先頭の改行を変換
	if ( defined $opt_hash->{'top_cr'} && $notkmk_hash->{'top_cr'} != 1 ) {
		if ($str =~ /^\x0A+/) {
			$scala =~ s/^[\x0D\x0A|\x0D|\x0A]+/$opt_hash->{'top_cr'}/;
		}
	}

	#--- 末尾の改行を変換
	if ( defined $opt_hash->{'end_cr'} && $notkmk_hash->{'end_cr'} != 1 ) {
		if ($str =~ /\x0A+$/) {
			$scala =~ s/[\x0D\x0A|\x0D|\x0A]+$/$opt_hash->{'end_cr'}/;
		}
	}

	#--- データ中の改行コードの変換
	if ( defined $opt_hash->{'in_cr'} && $notkmk_hash->{'in_cr'} != 1 ) {
		$scala =~ s/\x0D\x0A/\x0A/g;
		$scala =~ s/\x0D/\x0A/g;
		$scala =~ s/\x0A/$opt_hash->{'in_cr'}/g;
	}

	return ( $scala );

}

1;
