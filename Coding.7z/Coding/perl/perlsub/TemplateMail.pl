package TemplateMail;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  汎用メール送信ライブラリ
#     Program Name   :  TemplateMail.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#     version 1.1.0  :  2011.08.03 (YU) UTF8コード送信オプション追加
#     version 1.2.0  :  2018.03.20 (y.washizu) Encode.pmバージョンアップに伴いencodeの変更
#-----------------------------------------------------------------------------#
#
#  仕様概要
#    詳細は「管理者宛やユーザ宛に都度送信するシステムの制作規約」を
#    参照のこと。
#    また、このライブラリを使用するときはCGIの方で必ずSecurity.plを
#    コールしておくこと。
#
#  雛形：PCはUTF8 / 携帯はSJIS
#  半角カナは当ライブラリでは処理を行わない。
#
#  パッケージ使用方法
#
#    [1] 起動環境設定(&initialze_setting)
#      プログラムが起動されているときの起動環境を設定する。
#      &set_and_sentを利用するときはコールする必要はない
#
#      引数(1) 起動環境(DEBUG/TEST/HONBAN)
#              CGIプログラムの場合、&MG_ENV::server_envの戻り値を渡すこと。
#              バッチプログラムの場合、開発環境(DEBUG)、検証環境(TEST)、
#              本番環境(HONBAN)のいずれかを起動環境に合わせて渡す。
#
#      戻値(1) エラーがあった場合、エラーメッセージの配列が戻される
#
#      if (my @errmsg = &TemplateMail::initialize_setting(&MG_ENV::server_env)) {
#          &CgiError::abend(@errmsg);
#      }
#
#    [2] メール送信(&set_and_sent_limit)
#      メール送信を行う。
#      検証、本番環境では、アドレスリストに指定したメールアドレスにしか
#      メール送信を行わない。（PHPと同機能）
#      &set_and_sent関数の流用
#
#      引数(1) メールひな型のファイルフルパス
#      引数(2) 起動環境(DEBUG/TEST/HONBAN)
#              CGIプログラムの場合、&MG_ENV::server_envの戻り値を渡すこと。
#              バッチプログラムの場合、開発環境(DEBUG)、検証環境(TEST)、
#                本番環境(HONBAN)のいずれかを起動環境に合わせて渡す。
#      引数(3) アドレスリストのパス名
#      引数(4) 置換用のハッシュのリファレンス（省略可能）
#      引数(5) 入力ファイル文字コード [S:SJIS / それ以外:UTF-8]（省略可）
#
#      戻値(1) エラーがあった場合、エラーメッセージの配列が戻される
#
#      my $env = &MG_ENV::server_env;
#      if ( my @errmsg = &TemplateMail::set_and_sent_limit
#                                     ( $mail_txt, $env, $path, \%hash ) {
#          &CgiError::abend(@errmsg);
#      }
#
#    [3] メールテキスト整形(&data_set)
#      メールのテキストを整形する。この関数を独自に使用するときは
#      [1]起動環境設定を最初にコールすること。
#
#      引数(1) メールひな型のファイルフルパス
#      引数(2) 置換用のハッシュ（省略可能）
#      引数(3) 入力ファイル文字コード [S:SJIS / それ以外:UTF-8]（省略可）
# 
#      戻値(1) メールテキスト（char)
#      戻値(2) エラーがあった場合、エラーメッセージの配列が戻される
#
#      my @errmsg;
#      if (@errmsg = &TemplateMail::initialize_setting(&MG_ENV::server_env)) {
#          &CgiError::abend(@errmsg);
#      }
#      ($mail_txt,@errmsg) = &TemplateMail::data_set($mail_txt,\%hash);
#      if (@errmsg) {
#          return(@errmsg);
#      }
#
#    [4] メール送信（テキスト用）(&mail_sent)
#      メール送信を行う。この関数を独自に使用するときは[1]起動環境設定を
#      最初にコールすること。
#
#      引数(1) メールテキスト（char)
#      引数(2) 入力ファイル文字コード [S:SJIS / それ以外:UTF-8]（省略可）
#
#      戻値(1) エラーがあった場合、エラーメッセージの配列が戻される
#
#      my @errmsg;
#      if (@errmsg = &TemplateMail::initialize_setting(&MG_ENV::server_env)) {
#          &CgiError::abend(@errmsg);
#      }
#      if (@errmsg = &TemplateMail::mail_sent($mail_txt)) {
#          &CgiError::abend(@errmsg);
#      }
#
#    [5] メール本文チェック (&check_mailtxt)
#      メール本文の適正チェックを行う。
#      この関数を独自に使用するときは[1]起動環境設定を最初にコールすること。
#
#      引数(1) メールテキスト（char)
#      引数(2) 起動環境(DEBUG/TEST/HONBAN)
#      引数(3) アドレスリストのパス名
#
#      戻値(1) エラーがあった場合、エラーメッセージの配列が戻される
#
#      my @errmsg;
#      if (@errmsg = &TemplateMail::initialize_setting(&MG_ENV::server_env)) {
#          &CgiError::abend(@errmsg);
#      }
#      if (@errmsg = &TemplateMail::check_mailtxt($mail_txt)) {
#          &CgiError::abend(@errmsg);
#      }
#

#-----------------------------------------------------------------------------#
use utf8;
use Encode;
use HTML::Template;
use IO::Handle;
my $FH = new IO::Handle;
use MIME::Base64;														#1.1.0#
use Unicode::Japanese;

my $server_env;
my $server_root = '/WWW';
my (@getpwuid, $hinmei);
@getpwuid = getpwuid($>);
$hinmei = $getpwuid[0];

my $version = "1.1.0";
my $library_name = 'TemplateMail.pl';

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#-----------------------------------------------------------------------------#
#   sub initialize_setting : 起動環境設定
#-----------------------------------------------------------------------------#
#   input   : (1) 起動環境(DEBUG/TEST/HONBAN)
#-----------------------------------------------------------------------------#
#   output  : (1) エラーがあったときabend用の配列
#-----------------------------------------------------------------------------#
sub initialize_setting {
	$env = shift;
	# --- 起動環境の設定
	if ($env ne 'DEBUG' && $env ne 'TEST' && $env ne 'HONBAN') {
		return("[$library_name]",'Starting environment is unknown.');
	}
	$server_env = $env;
	return;
}

#-----------------------------------------------------------------------------#
#   sub set_and_sent_limit : メール送信（アドレスリスト機能バージョン）
#-----------------------------------------------------------------------------#
#   input   : (1) メール本文のひな型のファイルパス
#   input   : (2) 起動環境(DEBUG/TEST/HONBAN)
#   input   : (3) アドレスリストのパス名（省略不可）
#   input   : (4) テンプレート用のハッシュ（省略可）
#   input   : (5) 入力ファイル文字コード [S:SJIS / それ以外:UTF-8]（省略可）
#   input   : (6) 送信時の文字コード [U:UTF-8 / それ以外:JIS]（省略可）	#1.1.0#
#-----------------------------------------------------------------------------#
#   output  : (1) エラーがあったときabend用の配列
#-----------------------------------------------------------------------------#
sub set_and_sent_limit {
#1.1.0#		my ( $mail_txt, $env, $path, $hash, $code ) = @_;
	my ( $mail_txt, $env, $path, $hash, $code, $send_code ) = @_;		#1.1.0#
	my @errmsg;

	# --- アドレスリストのチェック
	if ( $env ne 'HONBAN' && $path eq '' ) {
		return("[$library_name]", "Address List error !");
	}

	# --- 起動環境の設定
	if (@errmsg = &initialize_setting($env)) {
		return(@errmsg);
	}
	# --- ひな型の整形
	($mail_txt,@errmsg) = &data_set($mail_txt,$hash, $code);
	if (@errmsg) {
		return(@errmsg);
	}
	# --- メール本文のチェック
	if ( @errmsg = &check_mailtxt( $mail_txt, $env, $path ) ) {
		return(@errmsg);
	}
	# --- メール送信
#1.1.0#	return &mail_sent($mail_txt, $code);
	return &mail_sent($mail_txt, $send_code);							#1.1.0#

}

#-----------------------------------------------------------------------------#
#   sub data_set : メールテキスト整形
#-----------------------------------------------------------------------------#
#   input   : (1) メール本文（テキスト）
#   input   : (2) テンプレート用のハッシュ（省略可）
#   input   : (3) 入力ファイル文字コード [S:SJIS / それ以外:UTF-8]（省略可）
#-----------------------------------------------------------------------------#
#   output  : (1) 整形後のメール本文（テキスト）。エラーの場合、空白
#   output  : (2) エラーがあったときabend用の配列
#-----------------------------------------------------------------------------#
sub data_set {
	my ($mail_txt,$hash, $code) = @_;
	my %hash;

	if($hash){
		%hash = %$hash;
	}

	# --- ひな型を読み込む
	&main::sopen($FH,'<',$mail_txt)
		or return('','[File-03]',$mail_txt,'read error');
	undef $mail_txt;
	my ($body_flg,$header_flg);

	while (<$FH>) {
		my $line = $_;
		if($code eq 'S'){
			$line = Unicode::Japanese->new($line,'sjis')->getu;
		}else{
			$line = Encode::decode('utf8', $line);
		}

		$line =~ s/\r\n/\n/g;
		$line =~ s/\r/\n/g;

		if ($body_flg) {
			unless ($header_flg) {
				# --- 本文はどこか？
				unless ($line =~ /^[a-zA-Z0-9_\-]+:/) {
					$header_flg = 1;
					# --- 改行ではないのでエラー
					unless ($line =~ /^\n/) {
						close($FH);
						return('',"[$library_name]",
							'A blank line is required between a mail header'
							.' and the text.');
					}
				}
			}
		} else {
			# --- コメントは無視する
			next	if (/^#/);
			next	if (/^\n$/);
			if ($line =~ /^[a-zA-Z0-9_\-]+:/) {
				# --- ヘッダが始まったと見なす
				$body_flg = 1;
			}
		}
		$mail_txt .= $line;
	}
	close($FH);

	# --- body_flgが立っていなければエラーと見なす
	unless ($body_flg) {
		return('',"[$library_name]",
			'It seems that the form of the model of mail is not right.');
	}
	# --- メールヘッダを改修する
	while ($mail_txt =~ /X-$server_env-([^:\s]*)/i) {
		my $target = $1;
		$mail_txt =~ s/X-$server_env-$target/$target/i;
		$mail_txt =~ s/X\-[a-zA-Z0-9_]*-$target[^\n]*\n//gi;
	}
	# --- あまったX-***を消しておく
	$mail_txt =~ s/^X-[^\n]*\n//g;
	# --- 先頭の空白行を削除する
	while ($mail_txt =~ /^\n/) {
		$mail_txt =~ s/^\n//;
	}

	# --- テンプレート用タグを置換する
	$mail_txt = HTML::Template->new_scalar_ref(
			\$mail_txt,
			die_on_bad_params => 0,
			loop_context_vars => 1
		);
	my @params = $mail_txt->param;
	foreach (@params) {
		if($mail_txt->query(name => $_) eq 'LOOP'){
			$mail_txt->param($_,$hash{$_});
		}else{
			$mail_txt->param($_,"$hash{$_}");
		}
	}
	return $mail_txt->output;
}

#-----------------------------------------------------------------------------#
#   sub mail_sent : メール送信
#-----------------------------------------------------------------------------#
#   input   : (1) メール本文（テキスト）
#   input   : (2) 送信時の文字コード [U:UTF-8 / それ以外:JIS]（省略可）	#1.1.0#
#-----------------------------------------------------------------------------#
#   output  : (1) エラーがあったときabend用の配列
#-----------------------------------------------------------------------------#
sub mail_sent {
#1.1.0#	my $mail_txt = shift;
	my ($mail_txt,$send_code) = @_;										#1.1.0#

	# --- 無視IPアドレスリストの対応
	my $ignore_dir 	= "/WWW/WEB_SECURITY/ignore.txt";
	if ( -e $ignore_dir && -f $ignore_dir ) {
		my $ignore_list = &ignore_setting($ignore_dir);
		my @ignore_list = @$ignore_list;
		my $remote_addr = $ENV{'REMOTE_ADDR'};
		if(@ignore_list){
			foreach my $ip (@ignore_list) {
				if($ip eq $remote_addr){
					return;
				}
			}
		}
	}

	# --- ヘッダと本文を\n\nでざっくり分ける
	my ($header) = split(/\n\n+/,$mail_txt);
	# --- 本文の部分を抜き出す
	my $header_length = length($header);
	my $body = substr($mail_txt,$header_length,
		length($mail_txt) - $header_length);

	# --- sendmailの設定
	my $sendmail = '/usr/lib/sendmail';
	my $from_address;
	if ($header =~ /Sender\s*:\s*([^\n]*)/i) {
		$from_address = $1;
	} elsif ($header =~ /From\s*:\s*([^\n]*)/i) {
		$from_address = $1;
	}
	if ($from_address eq '') {
		return("[$library_name]",
			'A transmitting agency mail address is not right.');
	} else {
		# --- 1つ目のメールアドレスを抜き出す
		($from_address) = split(',',$from_address);
		$from_address =~ s/\s//g;
		for ($from_address) {
			s/"(?:[^"]|\")*"//g;
			s/\([^()]*\)//g;
			$_ = $1 if /<([^>]*)>/;
			s/^\s+|\s+$//g;
		}
	}
	$sendmail  = "$sendmail -f $from_address -t -oi";
	# --- Senderヘッダは消す
	$header =~ s/Sender\s*:\s*[^\n]*\n//ig;
	# --- mime_encode。判定が難しいので全部変換する
	foreach $item ('To','From','Subject','Bcc','Cc') {
		# --- 重複しているヘッダはエラーと見なす
		if (grep(/^$item\s*:\s*/i,split("\n",$header)) > 1) {
			return("[$library_name]",$item,'The mail header overlaps.');
		}
		if ($header =~ /$item\s*:\s*([^\n]*)/i) {
			my $value = $1;
			my $modify = $value;
			$modify =~ s/([^\s])</$1 </g;
			my $mime_value = $modify;

#1.1.0#		substr($header,index($header,$value),length($value)) = $mime_value;
#1.2.0#			substr($header,index($header,$value),length($value)) = encode('MIME-Header',$mime_value);	#1.1.0#
			substr($header,index($header,$value),length($value)) = encode('MIME-Header-ISO_2022_JP',$mime_value);	#1.2.0#

		}
	}

	$mail_txt = $header.$body;

	if($send_code ne 'U'){												#1.1.0#
		$mail_txt = Unicode::Japanese->new($mail_txt,'utf8')->jis;		#1.1.0#
	}																	#1.1.0#
	else{																#1.1.0#
		$mail_txt = Encode::encode('utf8', $mail_txt);					#1.1.0#
	}																	#1.1.0#

	# --- メール送信を行う
	&main::sopen($FH,'|','comy',$sendmail)
		or return('[Command-02]',$sendmail,'sendmail error');
	print $FH $mail_txt;
	close($FH);
	
	return;
}

sub sopen(){
	local( $fhd,$io,$in_file,@in_com ) = @_; 
	local( $file,$com,@com,$wk,$rtn ); 

	$file = &Security::path( $in_file ); 
	foreach $com(@in_com){ push( @com,&Security::meta($com) ); }
	undef $wk;
	undef $rtn;
	if ( $io eq '<' ){
		if ( @com ){
			$com = shift( @com ); 
			$wk .= "$com $file |";
			foreach $com( @com ){ $wk .= "$com |"; }
		}
		else { $wk .= "$file"; }
	}
	elsif ( $io eq '>' || $io eq '>>' ){
		if ( @com ){
			foreach $com( @com ){ $wk .= "| $com "; }
				$wk .= "$io $file";
			}
			else { $wk .= "$io $file"; }
		}
		elsif ( $io eq '|' ){
			$com = shift( @com ); 
			$wk .= "| $com";
		if ( @com ){
			foreach $com( @com ){ $wk .= " | $com"; }
		}
	}
	if ( $wk ){ $rtn = open( $fhd,$wk ); }

	return( $rtn ); 
}

#-----------------------------------------------------------------------------#
#   sub check_mailtxt : メール本文のチェック
#-----------------------------------------------------------------------------#
#   input   : (1) メール本文（テキスト）
#   input   : (2) 起動環境(DEBUG/TEST/HONBAN)
#   input   : (3) アドレスリストのパス名
#-----------------------------------------------------------------------------#
#   output  : (1) エラーがあったときabend用の配列
#-----------------------------------------------------------------------------#
sub check_mailtxt {
	my ( $mail_txt, $env, $path ) = @_;
	my ( %address, @ok_address );
	my @ok_domain = (
					 '@digicom.dnp.co.jp',
					 '@atlantis.digicom.dnp.co.jp',
					 '@atlantis.pro.digicom.dnp.co.jp',
					 '@ml.digicom.dnp.co.jp',
					 '@cio.dnp.co.jp',
					 '@lab.cio.dnp.co.jp',
					 '@dev.cio.dnp.co.jp',
					 '@mail.dnp.co.jp',
					 '@mediagalaxy.ne.jp',
					);

	# --- ヘッダと本文を\n\nでざっくり分ける
	my ($header,$body) = split(/\n\n+/,$mail_txt);

	my $ascii = '[\x00-\x09\x0b-\x1f]';
	if ($header =~ /$ascii/) {
		return("[$library_name]",
			'It seems that the unsuitable character is contained in the '
			.'mail header.');
	}
	my %errmsg = (
		'to',		'The address seems not to specify it.',
		'from',		'The transmitting agency seems not to specify it.',
		'subject',	'The subject seems not to specify it.'
	);

	foreach my $target ('to','from','subject') {
		my $flg;
		if ($header =~ /\n?$target\s?:\s?([^\n]*)/i && $1 eq '') {
			$flg = 1;
		} elsif ($header !~ /\n?$target\s?:/i) {
			$flg = 1;
		}
		# --- フラグが立ったものはエラー
		if ($flg) {
			return("[$library_name]",$errmsg{$target});
		}
	}

	# --- 本文が空のものはエラー
	$ascii = '[\x00-\x20]';
	$body =~ s/$ascii//g;
	if ($body eq '') {
		return("[$library_name]",
			'It seems that the mail text consists of '
			.'unsuitable characters.');
	}

	#--- アドレスリストが指定されている時は、送信可能アドレスかチェックする
	#--- チェック対象は、開発と検証環境のみ

	if ( $path ne '' && $env ne 'HONBAN' ) {
		#--- アドレスリストの存在チェック ------------------------------------#
		if ( ! -f $path || ! -e $path ) {
			return("[$library_name]", "Address List not found !", "[$path]");
		}

		&main::sopen($FH,'<',$path)
			or return('','[File-03]',$path,'read error');
		while (<$FH>) {
			s/\r\n/\n/g;
			s/\r/\n/g;
			s/\n//g;

			#--- 有効なメールアドレス部分だけを抽出 --------------------------#
			if ( $_ !~ /^#/ && length($_) > 0 ) {
				 $_ =~ s/#.+$//g;                  # #以降削除
				 $_ =~ s/\s+$//g;                  # 末尾スペース削除

				 #--- ドメインとメアドを分けて蓄積 ---------------------------#
				 if ( substr($_,0,1) eq '@' ) {
					 push( @ok_domain, $_ );
				 } else {
					 push( @ok_address, $_ );
				 }
			}
		}
		close $FH;

		#--- ヘッダーからto,cc,bcc のメールアドレスを抜き出す ----------------#
		my @work = split(/\r\n|\r|\n/, $header);
		foreach ( @work ) {
			if ( $_ =~ /^(to|cc|bcc)\s?:\s?(.*)/i ) {
				$address{$1} = $2;
			}
		}

		while ( my ($n, $v) = each %address ) {
			$v =~ s/\s//g;

			#--- 複数のアドレスを分割 ----------------------------------------#
			my @wk = split(/,/, $v);
			foreach my $email ( @wk ) {
				my $ok_flg = 0;

				#--- < ～ > の存在チェック -----------------------------------#
				my $s_idx = index($email,'<');
				my $e_idx = index($email,'>');

				#--- < ～ > があれば、その中のメールアドレスを切り出す -------#
				if ( $s_idx >= 0 && $e_idx >= 0 ) {
					my $len = $e_idx - $s_idx - 1;
					$email = substr($email, $s_idx+1, $len);
				}

				#--- 送信可能なメールアドレスかチェック ----------------------#
				foreach my $ok_email ( @ok_address ) {
					if ( $email eq $ok_email ) {
						$ok_flg = 1;
						last;
					}
				}

				#--- 送信できないメールアドレス ------------------------------#
				if ( $ok_flg == 0 ) {
					#--- 送信可能なドメインかチェック ------------------------#
					foreach my $ok_domain ( @ok_domain ) {
						if ( $email =~ /$ok_domain$/ ) {
							$ok_flg = 1;
							last;
						}
					}

					#--- 最終的に送信できないメールアドレス ------------------#
					if ( $ok_flg == 0 ) {
						return("[$library_name]", "$n に送信できないメールアドレスが存在しています。", $email);
					}
				}
			}
		}
	}
	return;
}
#-----------------------------------------------------------------------------#
#   sub ignore_setting : メール送信
#-----------------------------------------------------------------------------#
#   input   : (1) 無視IPアドレスのディレクトリパス
#-----------------------------------------------------------------------------#
#   output  : (1) 無視IPアドレス配列のリファレンス、リストがない時は空配列
#-----------------------------------------------------------------------------#
sub ignore_setting{
	my ( $ignore_dir ) = @_; 
	my @ignore_list;

	my $FH2 = new IO::Handle;
	&main::sopen ($FH2,'<',$ignore_dir) || return(\@ignore_list);
	while(<$FH2>) {
		my $line = $_;

		$line = Encode::decode('utf8', $line);
		$line =~ s/[\r\n]//g;
		if($line ne ''){
			push(@ignore_list, $line);
		}
	}
	close $FH2;
	return(\@ignore_list);
}

1;
