# テスト

ライブラリに対してユニットテストの実施とカバレッジの取得方法についてのドキュメントです。

## テストの実行方法

大まかな流れは以下となっています。

 1. 任意の環境にライブラリを配置
 2. 環境変数をセット
 3. テストコードの実行
 4. カバレッジの計算
 5. レポート出力

### 任意の環境にライブラリを配置

`~/perl/perlsub` にライブラリを配置します。

### 環境変数をセット

環境変数をセットします。この時、shellがbashであることを確認します。

 - RHEL6構成の場合

```shell
export PATH=/WWW/sfw/linux6/perl5/5.20/bin:$PATH
export PERL5LIB="/WWW/sfw/linux6/perl5/5.20/local/lib/perl5:$PERL5LIB"
```

 - RHEL8構成の場合

```shell
export PATH=/WWW/sfw/perl5/std/local/bin:$PATH;
export PERL5LIB=/WWW/sfw/perl5/std/local/lib/perl5:$PERL5LIB;
```


### テストコードを実行

単体のコードを実行する場合は`prove`にて確認できます。

```shell
cd ~/perl/perlsub/t

#テスト対象のテストコードファイルを指定
prove -rv ./holiday.t
```

成功した場合は次のようなメッセージが出力されます。

```shell
$ prove -rv ./t/CD_Modulas10w2.t 
./t/CD_Modulas10w2.t .. 
ok 1 - require '/WWW/c0039999/perl/perlsub/CD_Modulas10w2.pl';
1..1
ok
All tests successful.
Files=1, Tests=1,  0 wallclock secs ( 0.00 usr  0.00 sys +  0.04 cusr  0.00 csys =  0.04 CPU)
Result: PASS
```


失敗した場合は以下のように、`Result: FAIL`と出力されます。

```shell
$ prove -rv ./CD_Modulas10w2.t
./CD_Modulas10w2.t .. 
/WWW/c0039999/perl/perlsub/t/CD_Modulas10w2.tok 1 - require '/WWW/c0039999/perl/perlsub/CD_Modulas10w2.pl';
1..1
Failed 1/1 subtests 

Test Summary Report
-------------------
./t/CD_Modulas10w2.t (Wstat: 0 Tests: 0 Failed: 0)
  Parse errors: Bad plan.  You planned 1 tests but ran 0.
Files=1, Tests=0,  0 wallclock secs ( 0.02 usr  0.01 sys +  0.03 cusr  0.00 csys =  0.06 CPU)
Result: FAIL
```

### カバレッジの計算

`Devel::Cover`でカバレッジを計算します。以下のコマンドを打つと`t`以下のすべてのテストが実行されます。

```shell
HARNESS_PERL_SWITCHES="-MDevel::Cover=+ignore,^t" prove -lvr t
```

### レポート出力

カバレッジの計算後、以下のコマンドで結果をレポートに出力します。

```shell
cover -report html
```

この結果は `~/perl/cover_db` に出力されます。
