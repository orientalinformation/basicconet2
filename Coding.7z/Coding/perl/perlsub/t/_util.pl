use Cwd qw(abs_path realpath);
use DBI;

sub _get_test_path_root() {
    return "/WWW/c0039999/perl/perlsub";
}

sub get_test_script_path() { 
    my ($file) = shift;
    my @filePath = split('/', $file);
    my $script_name = $filePath[$#filePath];
    $script_name =~ s/\.t/\.pl/;
    return _get_test_path_root() . "/" .  $script_name;
}

sub getOrableDBConnection() {
    my ($host, $sid, $user, $passwd, $home);
    
    $host = "10.88.14.170";
    $sid = "utf8";
    $user = "c0039999";
    $passwd = "c0039999p";
    $home = "";

    $ENV{NLS_LANG} = 'Japanese_Japan.JA16SJIS';
    $ENV{ORACLE_HOME} = $home;
    my $dbh = DBI->connect("DBI:Oracle:host=$host;sid=$sid;port=1521",$user, $passwd);
    return $dbh;
}

sub getMysqlDBConnection() {
    my ( $host, $dbname, $user, $passwd );
    $host = "localhost";
    $dbname = "c0039999";
    $user = "c0039999";
    $passwd = "c0039999p";
    
    my $dbh = DBI->connect("DBI:mysql:$dbname:$host", $user, $passwd );

    return ($dbh);
}

sub getPostgresDBConnection() {
    my ( $host, $dbname, $port, $user, $passwd );
    $host = "10.98.100.129";
    $dbname = "c0039999";
    $user = "postgres";
    $passwd = "123456";
    $port = 5432;

    my $dbh = DBI->connect("DBI:Pg:dbname=$dbname;host=$host;port=$port", $user, $passwd);

    return ($dbh);
}

1;