package DigicomCryptV3;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  データ暗号ライブラリ
#     Program Name   :  DigicomCryptV3.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#-----------------------------------------------------------------------------#
#  [概要]
#      このライブラリは、データの暗号化／復号化を行います。
#      通常この暗号化では、初期ベクトルと鍵が同一であれば、暗号化
#      されたファイル同士も同一となり、復号も問題なく同一になりますが、
#      各言語毎に実装されているDESライブラリの互換性の問題で暗号化／復号化に
#      おいて，同一の初期ベクトルが使えない場合も考慮し、平文データの第１
#      ブロックをダミーデータ(ブランク)で埋めておき，復号後の第１ブロックを
#      捨てることで解決しています。※暗号データは毎回異なる物が生成されます。
#
#  [注意]
#      新規品目・Perl5.004以上の環境。
#      DigicomCryptV2.plは今後新規品目では利用不可。
#-----------------------------------------------------------------------------#
#  [1] &DigicomCryptV3::encrypt ( データを暗号化する )
#
#		my ($err,$rtn) = &DigicomCryptV3::encrypt( 
#			 $in{'crypt_key'},		#可変
#			 $in{'data'},           #可変
#			 "RIJNDAEL_256",        #指定がない限り固定
#			 "CBC",                 #指定がない限り固定
#			 "TEXT",                #TEXT or PKCS#5
#			 "1",                   #hex型1、バイナリ型2
#			 "",                    #no = UTF8フラグなし返却  no以外= UTF8フラグ付き返却
#		);
#
#      返却値1:エラー(正常:空  異常:文字列)
#      返却値2:暗号化データ
#-----------------------------------------------------------------------------#
#  [2] &DigicomCryptV3::decrypt ( データを複号化する )
#
#		my ($err,$rtn) = &DigicomCryptV3::decrypt( 
#			 $in{'crypt_key'},		#可変
#			 $in{'data'},           #可変
#			 "RIJNDAEL_256",        #指定がない限り固定
#			 "CBC",                 #指定がない限り固定
#			 "TEXT",                #TEXT or PKCS#5
#			 "1",                   #hex型1、バイナリ型2
#			 "",                    #no = UTF8フラグなし返却  no以外= UTF8フラグ付き返却
#		);
#
#      返却値1:エラー(正常:空  異常:文字列)
#      返却値2:復号化データ
#-----------------------------------------------------------------------------#
#
#   ["i_key"]      .... 暗号化/複号に必要な鍵
#
#   ["i_data"]     .... 暗号化/複号対象文字列
#
#   ["algorithms"] .... アルゴリズム(省略時は"TripleDES")
#                         "TripleDES"    .... トリプルデス
#                         "DES"          .... デス
#                         "RIJNDAEL_128" .... レインドール( Block Size 128bit)
#                         "RIJNDAEL_192" .... レインドール( Block Size 192bit)
#                         "RIJNDAEL_256" .... レインドール( Block Size 256bit)	※通常時利用
#
#   ["mode"]       .... モード
#                         "CBC" ..... Cipher Block Chaining	※通常時利用
#                         "CFB" ..... Cipher FeedBook
#                         "ECB" ..... Electronic CodeBook
#
#   ["padding"]    .... PADDING形式
#                         "PKCS#5"  ..... PKCS#5方式PADDING ※基本TEXT、画像などのバイナリファイルを扱う場合はPKCS#5を推奨
#                         "TEXT"    ..... TEXT方式PADDING
#
#   ["hexa"]       .... 文字列モード
#                         "1" ..... 入力・出力をHex表現として扱う	※通常時利用
#                         "2" ..... 入力・出力をバイナリとして扱う
#
#   ※ 初期ベクトル値( ランダム )
#
#-----------------------------------------------------------------------------#
use strict; 
use Mcrypt qw( 3DES DES CBC CFB ECB RIJNDAEL_256 RIJNDAEL_192 RIJNDAEL_128 );
use Encode;

my $version = "1.0.0";
my $library_name = 'DigicomCryptV3.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#-----------------------------------------------------------------------------#
#  MAIN処理
#-----------------------------------------------------------------------------#
#  暗号化
sub encrypt {
	my ($i_key,$i_data,$algorithms,$mode,$padding,$hexa,$flagged) = @_; 
	my $rtn = '';							# 返却値 

	# データ照合、アルゴリズム、モード取得
	my ($err,$algorithms2,$mode2) = &check($i_key,$i_data,$algorithms,$mode,$padding,$hexa);

	if($err){
		return ($err,"");
	}

	# --- 処理開始
	if ( length( $i_data ) > 0 ){ 
		my $td = Mcrypt->new( algorithm => $algorithms2,
							  mode => $mode2,
							  verbose => 0
							);

		my $key  = &create_key( $i_key,$td->{KEY_SIZE} );
		my $iv   = &create_iv( $td->{IV_SIZE} ); 	# 初期ベクトル 常にランダム
		my $encd = &create_data( $i_data,$td->{BLOCK_SIZE},$padding ); 

		$td->init($key,$iv); 
		$rtn = $td->encrypt( $encd ); 
		$td->end();
	}

	if($hexa eq '1'){
		$rtn = &moji2hex( $rtn ); 
	}
	if($flagged ne 'no'){
		$rtn = Encode::decode('utf8', $rtn);
	}
	return( '', $rtn );

}

# 復号化
sub decrypt {
	my ($i_key,$i_data,$algorithms,$mode,$padding,$hexa,$flagged) = @_; 
	my $rtn = '';							# 返却値 

	# データ照合、アルゴリズム、モード取得
	my ($err,$algorithms2,$mode2) = &check($i_key,$i_data,$algorithms,$mode,$padding,$hexa);

	if($err){
		return ($err,"");
	}

	if ( length( $i_data ) > 0 ){
		my $td = Mcrypt->new( algorithm => $algorithms2,
							  mode => $mode2,
							  verbose => 0
							);
		my $key   = &create_key( $i_key,$td->{KEY_SIZE} );
		my $iv    = "\0" x ( $td->{IV_SIZE} ); 

		$td->init($key,$iv); 

		# hex変換
		if($hexa eq '1'){
			$i_data = &hex2moji($i_data);
		}

		$rtn = $td->decrypt( $i_data ); 
		if ( length( $rtn ) > int( $td->{BLOCK_SIZE} ) ){ 
			$rtn = substr( $rtn,int( $td->{BLOCK_SIZE} ) ); 
		}
		$td->end();

		# --- パディングPKCS#5 方式
		if($padding eq 'PKCS#5'){
			my $dummy_length = sprintf( "%d", hex(  unpack("H*", substr( $rtn, -1 ) ) ) );
			$rtn = substr( $rtn, 0,( length( $rtn ) - $dummy_length ) );
		# --- テキスト 方式
		}else{
			while( length( $rtn ) > 0 && 
				substr( $rtn,-1,1 ) eq "\0" ){
				chop( $rtn );
			}
		}

	}
	if($flagged ne 'no'){
		$rtn = Encode::decode('utf8', $rtn);
	}
	return( '', $rtn );
}

sub check(){
	my ( $i_key,$i_data,$algorithms,$mode,$padding,$hexa ) = @_; 

	# --- 事前データチェック
	if ($i_key eq ''){
		return ("i_key_error","","");
	}elsif ($i_data eq ''){
		return ("i_data_error","","");
	}elsif ($algorithms ne 'TripleDES' && $algorithms ne 'DES' 
	&& $algorithms ne 'RIJNDAEL_128' && $algorithms ne 'RIJNDAEL_192' && $algorithms ne 'RIJNDAEL_256'){
		return ("algorithms_error","","");
	}elsif ($mode ne 'CBC' && $mode ne 'CFB' && $mode ne 'ECB'){
		return ("mode_error","","");
	}elsif ($padding ne 'PKCS#5' && $padding ne 'TEXT'){
		return ("padding_error","","");
	}elsif ($hexa ne '1' && $hexa ne '2'){
		return ("hexa_error","","");
	}

	# --- 暗号アルゴリズム
	my $algorithms2;
	if ($algorithms eq 'RIJNDAEL_128'){
		$algorithms2 = Mcrypt::RIJNDAEL_128;
	}elsif ($algorithms eq 'RIJNDAEL_192'){
		$algorithms2 = Mcrypt::RIJNDAEL_192;
	}elsif ($algorithms eq 'RIJNDAEL_256'){
		$algorithms2 = Mcrypt::RIJNDAEL_256;
	}elsif ($algorithms eq 'TripleDES'){
		$algorithms2 = Mcrypt::3DES;
	}elsif ($algorithms eq 'DES'){
		$algorithms2 = Mcrypt::DES;
	}

	# --- モード決定
	my $mode2;
	if ($mode eq 'CBC'){
		$mode2 = Mcrypt::CBC;
	}elsif ($mode eq 'CFB'){
		$mode2 = Mcrypt::CFB;
	}elsif ($mode eq 'ECB'){
		$mode2 = Mcrypt::ECB;
	}

	return ('',$algorithms2,$mode2);
}

sub create_data(){ 
	my ( $data,$block_size,$padding ) = @_; 
	my $rtn = ''; 

	# --- パディングPKCS#5 方式
	if($padding eq 'PKCS#5'){

		my $cnt = 0;
	    if( $block_size > length( $data ) ){
	    	$cnt = ( $block_size - length( $data ) );
	    }else{
			if( length( $data ) % $block_size != 0 ){
				$cnt = ( $block_size - ( length( $data ) % $block_size  ));
			}
		}

		if($cnt eq '0'){ $cnt = $block_size; }

		my $char;
		my $char10 = sprintf("%02d", $cnt);
		my $char16  = sprintf "%02X", $char10;

		if($cnt > 0){
			for( my $i=0;$i<$cnt;$i++){
				$char .= pack( "H*", $char16 );
			}
		}

		$rtn = join('',
					&create_iv( $block_size ),  # ランダム1ブロック詰める
					$data,
					$char );


	# --- パディングTEXT 方式
	}else{
		if ( length( $data ) > 0 ){ 
			my $amari = length( $data ) % $block_size; 
			if ( $amari == 0 ){
				$rtn = join('',
							&create_iv( $block_size ),  # ランダム1ブロック詰める
							$data
						   );
			}
			else {
				my $cnt = int( $block_size - $amari );
				$rtn = join('',
							&create_iv( $block_size ),  # ランダム1ブロック詰める
							$data,
							( "\0" x $cnt ));

			}
		}
	}

	return( $rtn ); 
}

sub create_key (){
	my ( $key,$size ) = @_; 
	my $rtn = ''; 

	if ( length( $key ) == $size ){ 
		$rtn = $key;
	}
	elsif ( length( $key ) > $size ){ 
		$rtn = substr($key,0,$size); 
	}
	else { 
		$rtn = join('',
					$key,
					( "\0" x int( $size - length($key) ) )
				   ); 
	}
	
	return( $rtn ); 
}

# 初期ベクトル生成
sub create_iv (){ 
	my $size = shift; 
	my $tbl = join('',
				   '0123456789',
				   'abcdefghijklmnopqrstuvwxyz',
				   'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
				  );
	my $rtn  = ''; 

	for ( my $i=0; $i<$size; $i+=1 ){ 
		$rtn  .= substr( $tbl,int(rand(length($tbl))),1);
	}

	return( $rtn ); 
}

# 文字→HEX
sub moji2hex (){ 
	my $moji = shift; 
	my $rtn  = ''; 

	for( my $i=0;$i<length($moji);$i+=1 ){ 
		$rtn .= unpack( 'H2',substr($moji,$i,1) );
	}

	return( $rtn ); 
}

# HEX→文字
sub hex2moji (){ 
	my $hex = shift; 
	my $rtn  = ''; 

	for( my $i=0;$i<length($hex);$i+=2 ){ 
		$rtn .= pack( 'H2',substr($hex,$i,2) );
	}

	return( $rtn ); 
}
1;



