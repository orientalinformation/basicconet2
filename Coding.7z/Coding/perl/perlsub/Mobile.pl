package Mobile;
#----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  携帯キャリア情報取得パッケージ
#     Program Name   :  Mobile.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#-----------------------------------------------------------------------------#
#
#     新MG用ライブラリ version 1.3.1 を元にリニューアル新規作成
#
#     仕様概要
#             携帯キャリア情報取得
#
#     動作環境
#             [1] Linux環境専用
#
#  [1] &Mobile::info_get
#
#      環境変数（HTTP_USER_AGENT）から各種携帯キャリア情報を取得する。
#      環境変数で判断する為、ブラウザから直接呼ばれるCGIのみ判断が可能。
#      バッチプログラムや、ＣＧＩから子プロセスで呼ばれるプログラムでは
#      判断できない。（環境変数不在の為）
#
#      $phone = &Mobile::info_get(); 
#
#      引数
#      $wc_flg ................ willcom処理フラグ(省略可) [null:OFF, else:ON]
#
#      ハッシュリファレンスで下記の情報が取得できます。
#
#      $phone->{carrier}........キャリア
#               i ............. i-mode
#               e ............. ezweb
#               v ............. vodafone
#               l ............. L-mode
#               h ............. H"
#               wc ............ willcom
#               ""(Null) ...... それ以外
#
#      $phone->{type}..........キャリアタイプ
#               pdc  ........... PDC
#               foma ........... FOMA
#               wap1 ........... WAP1.0
#               wap2 ........... WAP2.0
#
#      $phone->{name}..........機種名
#
#      $phone->{method}........送信可能形式
#               post ........... POST送信可能
#               get  ........... GET形式のみ可能
#
#      $phone->{serial}.........個体識別番号
#
#      $phone->{iccard}.........FOMAカード製造番号(i-modeのみ)
#
#  [2] &Mobile::getSerial($carrier,$foma);
#
#      指定したキャリアの個体識別番号／FOMAカード製造番号を取得する。
#      &Mobile::info_get()内で使用しているので通常はそちらを使用してください。
#
#      引数
#      $carrier.................指定キャリア(i,e,v)
#      $foma....................FOMAカード製造番号取得フラグ(0,1)
#
#      戻り値
#      $serial..................個体識別番号／FOMAカード製造番号
#
#  [3] &Mobile::checkUserAgent($carrier);
#
#      指定したキャリアのHTTP_USER_AGENTをチェックする。
#
#      引数
#      $carrier.................指定キャリア(i,e,v,l,h,wc)
#
#      戻り値
#      $rtn.....................結果(0:OK,1:NG)
#----------------------------------------------------------------------------#
use utf8;
use vars qw(%carrier %carrier_type);
sub BEGIN{
	%carrier = (
		"DoCoMo/1",   "i",
		"DoCoMo/2",   "i",
		"UP.Browser", "e",
		"KDDI-",      "e",
		"J-PHONE",    "v",
		"Vodafone",   "v",
		"MOT-",       "v",
		"SoftBank",   "v",
		"PDXGW",      "h",
		"L-mode",     "l",
		"Mozilla\/.*\\(WILLCOM;",   "wc",
		"Mozilla\/.*\\(DDIPOCKET;", "wc",
		"JV-Lite2WE\/",             "wc",
	);

	#--- キャリア詳細テーブル -----------------------------------------------#
	%carrier_type = ( "DoCoMo/1",   "pdc",
		"DoCoMo/2",   "foma",
		"UP.Browser", "wap1",
		"KDDI-",      "wap2",
		"J-PHONE",    "j-phone",
		"Vodafone",   "vodafone",
		"MOT-",       "vodafone",
		"SoftBank",   "softbank",
		"Mozilla\/.*\\(WILLCOM;",   "willcom",
		"Mozilla\/.*\\(DDIPOCKET;", "willcom",
		"JV-Lite2WE\/",             "willcom",
	);
	
}
my $version = "1.0.0";
my $library_name = 'Mobile.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#----------------------------------------------------------------------------#
#   info_get   : 各種携帯キャリア情報を取得
#----------------------------------------------------------------------------#
#   input      : (1) willcom処理フラグ(省略可) [null:OFF, else:ON]
#----------------------------------------------------------------------------#
#   output (1) : キャリア情報（ハッシュリファレンス）
#----------------------------------------------------------------------------#
sub info_get() {

	my ($wc_flg) = @_;
	my $phone;
	my $agent = $ENV{'HTTP_USER_AGENT'};

	#--- キャリアの判定を行う ----------------------------------------------#
	while ( my($key, $value) = each(%carrier) ) {
		if ( $agent =~ /^$key/ ) {
			## UAがwillcomのもので、willcomフラグがNULLの場合は処理しない
			## (※ 詳細情報取得処理にも$phone->{carrier}がないので行かない)
			if( $value eq 'wc' && $wc_flg eq ''){
			}else{
				$phone->{carrier} = $value;
			}

			if ( $phone->{carrier} eq "i" 
				 || $phone->{carrier} eq "e" 
				 || $phone->{carrier} eq "wc"
				 || $phone->{carrier} eq "v" ) {

				#--- 詳細なキャリア情報の判定を行う ------------------------#
				while ( my($key2, $value2) = each(%carrier_type) ) {
					if ( $agent =~ /^$key2/ ) {
						$phone->{type} = $value2;
					}
				}
			}
		}
	}

	if ( $phone->{carrier} eq "i" ) {
		#--- i-modeの機種名取得 --------------------------------------------#
		my ( $docomo, $ver, $name, $sub ) = split( /[\/\s\(\)]+/, $agent );
		$phone->{name} = $name;
		#--- i-modeの個体識別番号(utn)取得 ---------------------------------#
		$phone->{serial} = &getSerial($phone->{carrier});
		$phone->{iccard} = &getSerial($phone->{carrier},1);

	} elsif ( $phone->{carrier} eq "e" ) {
		#--- EZwebの機種名取得 ---------------------------------------------#
		$phone->{name} = ( $agent =~ m#^[^\-]+\-([A-Z]\w+)#i )[0];
		#--- EZwebの個体識別番号取得 ---------------------------------------#
		$phone->{serial} = &getSerial($phone->{carrier});

		#--- EZwebのPOST,GETの使用可能判定 ---------------------------------#
		if ( $phone->{type} eq 'wap2' ) { $phone->{method} = "post"; }
		else                            { $phone->{method} = "get";  }

	} elsif ( $phone->{carrier} eq "v" ) {
		#--- vodafoneの機種名取得 ------------------------------------------#
		my ( $carrier, $ver, $name ) = split( "/", $agent );
		#--- Softbankの個体識別番号取得 ------------------------------------#
		$phone->{serial} = &getSerial($phone->{carrier});

		if ( $agent =~ /^MOT-/ ) {
			$phone->{name} = $ENV{'HTTP_X_JPHONE_MSNAME'};
		} else {
			#--- 機種名に半角SPがある場合は、その前までを機種名とする ------#
			my @v_name = split(/ /, $name);
			$phone->{name} = $v_name[0];
		}

		#--- vodafoneのPOST,GETの使用可能判定 ------------------------------#
		if ( $ver eq '2.0' ) { $phone->{method} = "get";  }
		else                 { $phone->{method} = "post"; }

	} elsif ( $phone->{carrier} eq "l" ) {
		#--- L-modeの機種名取得 --------------------------------------------#
		my ( $carrier, $dum, $ver, $ver2, $name ) = split( "/", $agent );
		$phone->{name} = $name;
	}
	elsif ( $phone->{carrier} eq "wc" ) {
		#---willcom端末の機種名取得 --------------------------------------------#
		if ( $agent =~ /^Mozilla/ ) {
			my ( $mozilla, $willcom, $name, $ver, $browser_ver, $cash ) = split( "/", $agent );
			$phone->{name} = $name;
		}else{
			$agent =~ s/^JV-Lite2WE\/.*\(//;
			$agent =~ s/WILLCOM\///;
			$agent =~ s/\).*$//;
			$phone->{name} = $agent;
		}
	}
	return( $phone ); 
}

#---------------------------------------------------------------------------#
#  getSerial : 個体識別番号取得（i-mode,Softbank,EZwebのみ）
#---------------------------------------------------------------------------#
#  input : (1) キャリア
#  input : (2) FOMAカード製造番号取得フラグ (製造番号が欲しい場合は1)
#---------------------------------------------------------------------------#
#  output : (1) 個体識別番号（取得できない場合は空）
#---------------------------------------------------------------------------#
sub getSerial{
	
	my ($carrier,$foma_card) = @_;
	my $serial;
	
	#-- キャリアチェック --#
	return if &checkUserAgent($carrier);
	
	if($carrier eq 'i'){ # i-mode
		if($foma_card == 1){ # FOMAカード製造番号
			if($ENV{HTTP_USER_AGENT} =~ /(\;\sicc)(....................)/){
				$serial = 'icc' . $2;
			}
		}else{
			if($ENV{HTTP_USER_AGENT} =~ /(\/ser)(...........)/){
				$serial = 'ser' . $2;
			}elsif($ENV{HTTP_USER_AGENT} =~ /(\;ser)(...............)/){
				$serial = 'ser' . $2;
			}
		}
		return if $serial =~ /[^A-Za-z0-9]/;
		$serial =~ s/[^A-Za-z0-9]//g;
	}elsif($carrier eq 'e'){ # EZweb
		$serial = $ENV{HTTP_X_UP_SUBNO};
		return if $serial =~ /[^A-Za-z0-9_\.]/;
	}elsif($carrier eq 'v'){ # Softbank
		if($ENV{HTTP_USER_AGENT} =~ /(\/SN)([^\s]+)\s/){
			$serial = 'SN' . $2;
			return if $serial =~ /[^A-Za-z0-9]/;
		}
	}
	return($serial);
	
}

#---------------------------------------------------------------------------#
#  checkUserAgent : ユーザエージェントのチェック
#---------------------------------------------------------------------------#
#  input : (1) 指定キャリア
#---------------------------------------------------------------------------#
#  output : (1) 0:OK,1:NG
#---------------------------------------------------------------------------#
sub checkUserAgent{
	
	my $carrier = shift;
	my $rtn = 1;
	while(my ($n,$v) = each(%carrier)){
		if($ENV{HTTP_USER_AGENT} =~ /^$n/){
			if($carrier eq $v){
				$rtn = 0;
			}
		}
	}
	return($rtn);
	
}
1;

