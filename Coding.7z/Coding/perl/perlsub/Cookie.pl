package Cookie;
#-----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  Cookie ライブラリ
#     Program Name   :  Cookie.pl
#     Create Date    :  2010.11.11
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (H.Noguchi) New Create
#     version 1.1.0  :  2013.09.15 (YU) 開発環境のセキュアクッキー対応
#-----------------------------------------------------------------------------#
#     history        :  新MG用ライブラリ Cookie2.pl version 1.0.0 を元に
#                       リニューアル新規作成
#-----------------------------------------------------------------------------#
#   [1] Cookieのセット
#        &Cookie::set_cookie ( $name,$value,$expires,$domain,$path,$secure );
#            $name    : Cookie名
#            $value   : セット内容
#            $expires : 有効期限     (省略可)
#            $domain  : ドメイン     (省略可)
#            $path    : パス         (省略可)
#            $secure  : セキュア指定 (省略可)
#        ※必ずcontent-typeの前にセットする
#-----------------------------------------------------------------------------#
#   [2] Cookieの取り出し
#        $cookie = &Cookie::get_cookie ( $name,$css );
#            $name    : Cookie名
#            $css     : CSS対策　（省略可）
#
#            $cookie  : 取り出しデータ ( return ) 
#-----------------------------------------------------------------------------#
use utf8;
use Encode;
use Date::Calc qw( Delta_Days );

my $version = "1.0.0";
my $library_name = 'Cookie.pl';
#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#    set_cookie : クッキーデータのセット
#-----------------------------------------------------------------------------#
#    input(1)  :  Cookie名
#    input(2)  :  セット内容
#    input(3)  :  有効期限（省略可）
#                         D + 数値 -> 現在日時 + 加算日
#                         H + 数値 -> 現在日時 + 加算時間
#                         M + 数値 -> 現在日時 + 加算分
#                         S + 数値 -> 現在日時 + 加算秒
#                         YYYYMMDDHHMMSS -> YYYYMMDDHHMMSS形式で指定
#                         省略     -> 有効期限はセットしない（ブラウザ終了まで）
#    input(4)  :  ドメイン    （省略可）
#    input(5)  :  パス        （省略可）
#    input(6)  :  セキュア指定（省略可）
#                         1    -> secureあり
#                         省略 -> secureなし
#-----------------------------------------------------------------------------#
sub set_cookie {
	my ( $name, $value, $expires, $domain, $path, $secure ) = @_; 
	my ( $cookie, $wk_expires, @dom, @domain );

	$value = Encode::encode('utf8', $value);	# unpackする前にencode
	$value =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
	$value =~ s/ /+/g;

###	$name = Encode::encode('utf8', $name);		# unpackする前にencode
###	$name =~ s/[^0-9a-zA-Z]/"%".(unpack("H2", $&))/eg;
###	$name =~ s/ /+/g;

	#--- 有効期限の変換処理 --------------------------------------------------#
	if ( $expires && $expires =~ /^(D|H|M|S)([0-9]+)$/ ){
		$wk_expires = &get_expire( $1, $2 );
	} elsif ( $expires && $expires =~ /^[0-9]{14}$/ ){
		$wk_expires = &get_expire2( $expires );
	}

	#--- ドメイン変換処理 ----------------------------------------------------#
	if ( $domain eq '' ) {
		if ( $ENV{'HTTP_HOST'} =~ /:[0-9]+$/ ){ $domain = $`; }         
		else                               { $domain = $ENV{'HTTP_HOST'}; }    

		@dom = split(/\./,$domain);
		$domain = join( '.',splice( @dom,$#dom * -1 ) );
		$domain = '.' . $domain;
		#--- .が１つしかない場合、ドメインを空にする ------------------#
		@domain = split(/\./,$domain);
		if ( @domain <= 2 ) { $domain = ''; }
	}else{
		@domain = split(/\./,$domain);
		if ( @domain <= 1 ) { $domain = ''; }
	}

	#--- パス変換処理 --------------------------------------------------------#
	if ( $path eq '' ) { $path = "/"; }

	#--- 検証環境のセキュア指定 ----------------------------------------------#
	if ( $secure ) {
		if ( !($ENV{'HTTPS'}) ) {
			my @getpwuid = getpwuid($>);
			my $hinmei   = $getpwuid[0];
			if ( substr($hinmei,3,1) == 2 ) {
				$secure = '';
			}
			if ( substr($hinmei,3,1) == 3 ) {	#1.1.0#
				$secure = '';					#1.1.0#
			}									#1.1.0#
		}
	}

	#--- cookieのセット処理 --------------------------------------------------#
	$cookie  = "Set-Cookie: ";
	$cookie .= "$name=$value; ";
	$cookie .= "expires=$wk_expires; " if $wk_expires;
	$cookie .= "domain=$domain; " if $domain;
	$cookie .= "path=$path";
	$cookie .= "; secure" if $secure;
	$cookie .= "\n";
	$cookie  = Encode::encode('utf8', $cookie);

	print "$cookie"; 

	return( $cookie );
}

#-----------------------------------------------------------------------------#
#    get_cookie : クッキーデータの取得
#-----------------------------------------------------------------------------#
#    input(1)  :  Cookie名
#    input(2)  :  CSS対策（省略可）
#                                  1    -> CSS対策を行う
#                                  省略 -> CSS対策を行わない
#-----------------------------------------------------------------------------#
#    output(1) :  Cookie内容
#-----------------------------------------------------------------------------#
sub get_cookie {
	my ( $kmk_name, $css ) = @_;
	my ( $tmp, $name, $value ); 

	for $tmp (split(/; */, $ENV{'HTTP_COOKIE'})) {
		($name, $value) = split(/=/, $tmp);
###		$name  =~ tr/+/ /;
###		$name  =~ s/%(..)/pack("C", hex($1))/eg;
		$name  = Encode::decode('utf8', $name);
		$value =~ tr/+/ /;
		$value =~ s/%(..)/pack("C", hex($1))/eg;
		$value = Encode::decode('utf8', $value);
		if ( $name eq $kmk_name ) {
			if ( $css ne '' ) {
				$value =~ s/"/”/g;
				$value =~ s/'/’/g;
				$value =~ s/</＜/g;
				$value =~ s/>/＞/g;
			}
			return( $value );
		}
	}

	return(); 
}

#-----------------------------------------------------------------------------#
#   get_expire : 加算日時分から「Sun,22-Mar-1988 09:30:45 GMT」の形式に変換する
#-----------------------------------------------------------------------------#
#    input(1)  :  加算タイプ  
#                             D -> 日付
#                             H -> 時間
#                             M -> 分
#                             S -> 秒
#    input(2)  :  加算値
#-----------------------------------------------------------------------------#
#    output(1) :  GMT
#-----------------------------------------------------------------------------#
sub get_expire {
	my ( $type, $num ) = @_;
	my ( $sec,$min,$hour,$mday,$mon,$year,$wday );

	if ( $type eq 'D' ) {
		( $sec,$min,$hour,$mday,$mon,$year,$wday )
			= gmtime(time + int($num*60*60*24));
	} elsif ( $type eq 'H' ) {
		( $sec,$min,$hour,$mday,$mon,$year,$wday )
			= gmtime(time + int($num*60*60));
	} elsif ( $type eq 'M' ) {
		( $sec,$min,$hour,$mday,$mon,$year,$wday )
			= gmtime(time + int($num*60));
	} elsif ( $type eq 'S' ) {
		( $sec,$min,$hour,$mday,$mon,$year,$wday )
			= gmtime(time + int("$num"));
	}

	$mon = ("Jan","Feb","Mar","Apr","May","Jun"
			,"Jul","Aug","Sep","Oct","Nov","Dec")[$mon];
	$wday = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")[$wday];

	sprintf( "$wday, %2.2d-$mon-%4.4d %2.2d:%2.2d:%2.2d GMT"
			 ,$mday,$year+1900,$hour,$min,$sec);
}

#-----------------------------------------------------------------------------#
#   get_expire2 : 日付時間から「Sun,22-Mar-1988 09:30:45 GMT」の形式に変換する
#-----------------------------------------------------------------------------#
#    input(1)  :  日時（YYYYMMDDHHMMSS）
#-----------------------------------------------------------------------------#
#    output(1) :  GMT
#-----------------------------------------------------------------------------#
sub get_expire2 {
	my ( $set_date ) = @_;
	my ( $diff_days, $tm );

	#---- 年月日時分秒にわける ----#
	my ( $set_year, $set_month, $set_day, $set_hour, $set_min, $set_sec ) =
		 ( $set_date =~ /^([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})/ ); 

	#---- 総数秒を算出する（日本はGMTより9時間ずれている）----#
	$diff_days = &Date::Calc::Delta_Days
					( '1970','01','01',$set_year, $set_month, $set_day);
	$tm = $diff_days*60*60*24 + $set_hour*60*60 + $set_min*60 + $set_sec - 9*60*60;    

	my ( $sec,$min,$hour,$mday,$mon,$year,$wday ) = gmtime("$tm");

	$mon = ("Jan","Feb","Mar","Apr","May","Jun"
			,"Jul","Aug","Sep","Oct","Nov","Dec")[$mon];
	$wday = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")[$wday];

	sprintf( "$wday, %2.2d-$mon-%4.4d %2.2d:%2.2d:%2.2d GMT"
			 ,$mday,$year+1900,$hour,$min,$sec);
}

1;
