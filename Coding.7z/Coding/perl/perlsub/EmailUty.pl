package EmailUty;
#------------------------------------------------------------------------------
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  メールアドレスライブラリ
#     Program Name   :  EmailUty.pl
#     Create Date    :  2010.11.11
#     Programmer     :  YU (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#-----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (YU) New Created
#     version 1.1.0  :  2018.02.15 (y.washizu) auドメイン変更対応
#-----------------------------------------------------------------------------#
#  [1] &EmailUty::carrier
#
#      メールアドレスの携帯キャリアを判別する。
#
#      $rtn = &EmailUty::carrier( $email, $flg );
#
#      $email......チェックするメールアドレス（ひとつのみ有効)
#      $flg........WILLCOMサブドメイン(wm)を有効にする(省略可)
#      $rtn........リターンコード
#                       i ........... i-modeのメールアドレス(携帯)
#                       v ........... j-phoneのメールアドレス(携帯)
#                       e ........... ezwebのメールアドレス(携帯)
#                       t ........... ツーカースカイメッセージ(携帯)  V1.1.0
#                       p ........... パルディオEメール(PHS)          V1.1.0
#                       c ........... きゃらメール(PHS)               V1.1.0
#                       d ........... DDIポケットPメールDX(PHS)       V1.1.0
#                       a ........... アステルMOZIOサービス(PHS)      V1.1.0
#                       w ........... その他のメールアドレス
#                       "" (null) ... 入力文字列なし、またはアドレス不具合
#                       
#----------------------------------------------------------------------------
use utf8;

my $version = "1.0.0";
my $library_name = 'EmailUty.pl';

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}
#----------------------------------------------------------------------------#
#      carrier :  メールアドレスのタイプ(キャリア)を返却する
#----------------------------------------------------------------------------#
sub carrier { 
    my ( $email, $flg ) = @_;

	my $rtn = "";
 
	if ( length($email) > 0 ){ 
			#----- imodeのアドレスチェック ---------------------------------#
			if ( lc($email) =~ /\@docomo\.ne\.jp$/ ){ $rtn = "i"; }
			#----- j-phoneのアドレスチェック -------------------------------#
			elsif ( lc($email) =~ /\@jp-\w\.ne\.jp$/
					|| lc($email) =~ /\@d\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@h\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@t\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@c\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@k\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@r\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@n\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@s\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@q\.vodafone\.ne\.jp$/
					|| lc($email) =~ /\@softbank\.ne\.jp$/
					|| lc($email) =~ /\@disney\.ne\.jp$/
					){ $rtn = "v"; }
			#----- ezwebのアドレスチェック ---------------------------------#
#1.1.0#			elsif ( lc($email) =~ /\@.*ezweb\.ne\.jp$/
#1.1.0#					|| lc ($email) =~ /\@ez\w\.ido\.ne\.jp$/ ){ $rtn = "e"; }
			elsif ( lc ($email) =~ /\@au\.com$/									#1.1.0#
					|| lc($email) =~ /\@biz\.au\.com$/							#1.1.0#
					|| lc($email) =~ /\@.*ezweb\.ne\.jp$/						#1.1.0#
					|| lc($email) =~ /\@ez\w\.ido\.ne\.jp$/ ){ $rtn = "e"; }	#1.1.0#
			#----- ツーカースカイメッセージのチェック ----------------------#
			elsif ( lc($email) =~ /\@sky\.tu-ka\.ne\.jp$/
					|| lc($email) =~ /\@.*\.sky\.tu-ka\.ne\.jp$/
					|| lc($email) =~ /\@sky\.tkk\.ne\.jp$/
					|| lc($email) =~ /\@.*\.sky\.tkk\.ne\.jp$/
					|| lc($email) =~ /\@sky\.tkc\.ne\.jp$/
					|| lc($email) =~ /\@.*\.sky\.tkc\.ne\.jp$/ )
				{ $rtn = 't'; }
			#----- きゃらメールのチェック ----------------------------------#
			elsif ( lc($email) =~ /\@cmchuo\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmhokkaido\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmtohoku\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmtokai\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmkansai\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmchugoku\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmshikoku\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@cmkyusyu\.nttpnet\.ne\.jp$/ )
				{ $rtn = 'c'; }
			#----- パルディオEメールのチェック -----------------------------#
			elsif ( lc($email) =~ /\@em\.nttpnet\.ne\.jp$/
					|| lc($email) =~ /\@.*\.em\.nttpnet\.ne\.jp$/ )
				{ $rtn = 'p'; }
			#----- PメールDXのチェック -------------------------------------#
			# /\@d.\.pdx\.ne\.jp$/ はサブドメインdi,dj,dkに対応する
			elsif ( lc($email) =~ /\@pdx\.ne\.jp$/
					|| lc($email) =~ /\@d.\.pdx\.ne\.jp$/ )
				{ $rtn = 'd'; }
			elsif ( $flg eq '1' && lc($email) =~ /\@wm\.pdx\.ne\.jp$/)
				{ $rtn = 'd'; }
			#----- Willcomメールのチェック ---------------------------------#
			elsif ( $flg eq '1' && lc($email) =~ /\@willcom\.com$/ )
				{ $rtn = 'd'; }
			#----- アステルMOZIOサービスのチェック -------------------------#
			elsif ( lc($email) =~ /\@phone\.ne\.jp$/
					|| lc($email) =~ /\@.*.\.mozio\.ne\.jp$/ )
				{ $rtn = 'a'; }
			#----- 上記以外の場合 ------------------------------------------#
			else { $rtn = "w"; }
	}
	return( $rtn ); 
}
1; 
