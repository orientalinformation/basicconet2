package WWWConfig;
#----------------------------------------------------------------------------#
#     Client Name    :  社用
#     System Name    :  CPS汎用ライブラリ(Linux環境版)
#     Project Name   :  環境設定システム パッケージ
#     Program Name   :  WWWConfig.pl
#     Create Date    :  2010.11.11
#     Programmer     :  H.Noguchi (Pro.DigitalCom.DNP)
#     Entry Server   :  all server
#     Called By      :  all programs
#     File Code      :  UTF-8
#     Execute Env    :  UTF-8
#     Copyright      :  2011 DNP DigitalCom CO.,LTD.
#----------------------------------------------------------------------------#
#     version 1.0.0  :  2010.11.11 (H.Noguchi) New Create
#----------------------------------------------------------------------------#
#
#     新MG用ライブラリ version 1.A.3 を元にリニューアル新規作成
#
#     仕様概要
#             このパッケージはサーバソフトの環境変数を使用して、
#             サーバルートのパスや、品目ディレクトリのパスなどの情報を
#             返します。(SSLから呼ばれた場合には、SSL用のパスを返します)
#             バッチプログラムからは使用できません
#
#     動作環境
#             [1] Linux環境(UTF-8)専用
#
#     パッケージ使用方法
#
#             [1] サーバルートのパスの取得
#                 $s_root = &WWWConfig::server_root();
#             [2] 品目ディレクトリのパスの取得
#                 $web_dir = &WWWConfig::web_dir();
#             [3] 品目URLの取得
#                 $web_url = &WWWConfig::web_url();
#             [4] CGI URLの取得
#                 $cgi_url = &WWWConfig::cgi_url();
#             [5] DATAディレクトリパスの取得
#                 $data_dir = &WWWConfig::data_dir();
#             [6] システム共通データエリア(PUBDATA)パスの取得
#                 $pubdata_dir = &WWWConfig::pubdata_dir();
#             [7] 実行CGI URLの取得
#                 $mycgi_url = &WWWConfig::mycgi_url();
#
#-----------------------------------------------------------------------------#
use utf8;

my $version = "1.0.0";
my $library_name = 'WWWConfig.pl';

&initial_setting unless defined $initial_setting;

#-----------------------------------------------------------------------------#
#   sub initialize_return : バージョン返却
#-----------------------------------------------------------------------------#
#   output  : (1) バージョン
#   output  : (2) ライブラリ名
#-----------------------------------------------------------------------------#
sub initialize_return {
	return($version,$library_name);
}

#-----------------------------------------------------------------------------#
#     initial_setting : initial setting
#-----------------------------------------------------------------------------#
sub initial_setting {

	$initial_setting = "1";

	#--- CSS対策 -------------------------------------------------------------#
	my @env = ( 'DOCUMENT_ROOT','HTTP_HOST','HTTPS','SCRIPT_NAME' );
	foreach ( @env ) {
		$ENV{$_} =~ s/"/”/g;
		$ENV{$_} =~ s/'/’/g;
		$ENV{$_} =~ s/</＜/g;
		$ENV{$_} =~ s/>/＞/g;
	}

	$server_root = '/WWW';
	@getpwuid = getpwuid($>);
	$hinmei = $getpwuid[0];

	if ($ENV{'DOCUMENT_ROOT'} =~ m|$server_root/$hinmei/http| ||
		$ENV{'DOCUMENT_ROOT'} =~ m|$server_root/$hinmei/https|) {

		if ( $ENV{'HTTPS'} ){
			$scheme = 'https';
		}
		else { $scheme = 'http'; }

		$web_dir     = $ENV{'DOCUMENT_ROOT'};
		$web_url     = "$scheme://$ENV{'HTTP_HOST'}";
		$cgi_url     = "$scheme://$ENV{'HTTP_HOST'}/CGI";
		$data_dir    = "$server_root/$hinmei/data";
		$pubdata_dir = "$server_root/$hinmei/pubdata";
		$mycgi_url   = "$scheme://$ENV{'HTTP_HOST'}$ENV{'SCRIPT_NAME'}";
	}
	else {
		print "Content-Type: text/plain\n\n";
		print "WWWConfig.pl Enviroment Data Error !!\n";
		exit;
	}
}

#----------------------------------------------------------------------------#
#     server_root : サーバルートのパスを返す
#----------------------------------------------------------------------------#
sub server_root { return ( $server_root ); }

#----------------------------------------------------------------------------#
#     web_dir : 品目ドキュメントルートのパスを返す
#----------------------------------------------------------------------------#
sub web_dir { return ( $web_dir ); }

#----------------------------------------------------------------------------#
#     web_url : 品目のURLを返す
#----------------------------------------------------------------------------#
sub web_url { return ( $web_url ); }

#----------------------------------------------------------------------------#
#     cgi_url : 品目CGIのURLを返す
#----------------------------------------------------------------------------#
sub cgi_url { return ( $cgi_url ); }

#----------------------------------------------------------------------------#
#     data_dir : 品目データのパスを返す
#----------------------------------------------------------------------------#
sub data_dir { return ( $data_dir ); }

#----------------------------------------------------------------------------#
#     pubdata_dir : 品目共通データエリアパスを返す
#----------------------------------------------------------------------------#
sub pubdata_dir { return ( $pubdata_dir ); }

#----------------------------------------------------------------------------#
#     mycgi_url : 起動CGIのURLを返す
#----------------------------------------------------------------------------#
sub mycgi_url { return ( $mycgi_url ); }


1;

