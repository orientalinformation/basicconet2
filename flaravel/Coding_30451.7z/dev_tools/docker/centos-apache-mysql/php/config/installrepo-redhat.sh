#!/bin/sh

yumSETFuction ()
{
mkdir -p /etc/yum.repos.d/backup
chmod 777 /etc/yum.repos.d/backup
mv /etc/yum.repos.d/*.repo /etc/yum.repos.d/backup &> /dev/null
rm -f /etc/yum.repos.d/FHCM-local.repo
#Get version Redhat.
#versionRedhat=`grep -o " 6" <<<`cat /etc/redhat-release` | wc -l`
release=`cat /etc/redhat-release`
release=`grep -o " 7" <<<$release | wc -l`

if [ $release -ge 1 ]; then
	versionRedhat=7
else
	versionRedhat=6
fi

echo "
[FPT-base]
name=FPT-CentOS-$releasever - Base
baseurl=http://$IPSERVER/repository/yum-centos/$versionRedhat/os/\$basearch/
gpgcheck=0
enabled=1

[FPT-updates]
name=FPT-CentOS-$releasever - Updates
baseurl=http://$IPSERVER/repository/yum-centos/$versionRedhat/updates/\$basearch/
gpgcheck=0
enabled=0

#additional packages that may be useful
[FPT-extras]
name=FPT-CentOS-$releasever - Extras
baseurl=http://$IPSERVER/repository/yum-centos/$versionRedhat/extras/\$basearch/
gpgcheck=0
enabled=1

[FPT-ius]
name=IUS Community Packages for Enterprise Linux 7 - \$basearch
baseurl=http://$IPSERVER/repository/yum-ius/$versionRedhat/\$basearch/
enabled=1
gpgcheck=0

[FPT-epel]
name=Extra Packages for Enterprise Linux $releasever - \$basearch
baseurl=http://$IPSERVER/repository/yum-epel/$versionRedhat/\$basearch
enabled=1
gpgcheck=0

[FPT-elrepo]
name=Extra Packages for elrepo - \$basearch
baseurl=http://$IPSERVER/repository/yum-elrepo/el$versionRedhat/\$basearch
enabled=1
gpgcheck=0

[remi-safe]
name=Safe Remi's RPM repository for Enterprise Linux $releasever - $basearch
baseurl=http://$IPSERVER/repository/yum-remi/$versionRedhat/safe/\$basearch/
enabled=1
gpgcheck=0

" > /etc/yum.repos.d/FHCM-local.repo

yum clean all
}

#PATH=/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin

#repository IP address
IPSERVER=hcm-repo.fsoft.com.vn
export IPSERVER

#Check Linux OS
platform=`uname`
if [ "$platform" != "Linux" ];then
		echo "This package must be installed on Linux Platform."
		echo "Aborting installation."
		exit 1
fi

#Giá trị Mask sẽ “che đi” một số bit trong Base Permission để tạo ra quyền truy cập thực sự vào file
umask 022


#Check quyen root
user=`id | cut -d'=' -f2 | cut -d\( -f1`
if [ $user -ne 0 ]; then
    echo "Needs root authentication to install."
    exit 1
fi

#Check differentiate between Ubuntu and other Linux platforms 
if [ -f /etc/debian_version ]; then
	#Check dung la Ubuntu
	ubuntuSETFuction
	echo "Đã trỏ repo về Local FHCM Repository Ubuntu"
else
	#Check khong phai la Ubuntu
	#Con lai la Centos/Redhat
	yumSETFuction
	echo "Đã trỏ repo về Local FHCM Repository Centos"
fi
