#!/bin/sh
yumSETFuction ()
{
echo "
# Repository: https://rpms.remirepo.net

[FPT-remi-safe]
name=Safe Remi's RPM repository for Enterprise Linux \$releasever - \$basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/safe/\$basearch/
enabled=1
gpgcheck=0

[FPT-remi]
name=FSOFT Remi's RPM repository for Enterprise Linux $releasever - $basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/remi/\$basearch/
enabled=1
gpgcheck=0

[FPT-remi-php54]
name=FSOFT Remi's PHP 5.4 RPM repository for Enterprise Linux \$releasever - $basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/php54/\$basearch/
enabled=0
gpgcheck=0

[FPT-remi-php55]
name=FSOFT Remi's PHP 5.5 RPM repository for Enterprise Linux \$releasever - \$basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/php55/\$basearch/
enabled=0
gpgcheck=0

[FPT-remi-php56]
name=FSOFT Remi's PHP 5.6 RPM repository for Enterprise Linux \$releasever - \$basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/php56/\$basearch/
enabled=0
gpgcheck=0

[FPT-remi-php70]
name=FSOFT Remi's PHP 7.0 RPM repository for Enterprise Linux \$releasever - \$basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/php70/\$basearch/
# WARNING: Only available for RHEL/CentOS >= 6
enabled=0
gpgcheck=0

[FPT-remi-php71]
name=FSOFT Remi's PHP 7.1 RPM repository for Enterprise Linux $releasever - $basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/php71/\$basearch/
# WARNING: Only available for RHEL/CentOS >= 6
enabled=0
gpgcheck=0

[FPT-remi-php72]
name=FSOFT Remi's PHP 7.2 RPM repository for Enterprise Linux \$releasever - \$basearch
baseurl=http://$IPSERVER/repository/yum-remi/\$releasever/php72/\$basearch/
# WARNING: Only available for RHEL/CentOS >= 6
enabled=1
gpgcheck=0


" > /etc/yum.repos.d/FDN-remi.repo


yum clean all

}

#PATH=/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin

#repository IP address
IPSERVER=hcm-repo.fsoft.com.vn
export IPSERVER

#Check Linux OS
platform=`uname`
if [ "$platform" != "Linux" ];then
		echo "This package must be installed on Linux Platform."
		echo "Aborting installation."
		exit 1
fi

#Giá trị Mask sẽ “che đi” một số bit trong Base Permission để tạo ra quyền truy cập thực sự vào file
umask 022


#Check quyen root
user=`id | cut -d'=' -f2 | cut -d\( -f1`
if [ $user -ne 0 ]; then
    echo "Needs root authentication to install."
    exit 1
fi

#Check differentiate between Ubuntu and other Linux platforms 
if [ -f /etc/debian_version ]; then
	#Check dung la Ubuntu
	
	echo "Đây là Ubuntu, ban da sử dụng sai bản cài đặt!"
else
	#Check khong phai la Ubuntu
	#Con lai la Centos/Redhat
	yumSETFuction
	echo "Đã trỏ repo về Local Repository Centos"
fi
