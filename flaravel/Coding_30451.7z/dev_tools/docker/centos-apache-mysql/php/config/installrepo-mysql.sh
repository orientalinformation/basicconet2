#!/bin/sh

yumSETFuction ()
{
echo "
#https://dev.mysql.com/doc/mysql-yum-repo-quick-guide/en/
# Enable to use MySQL 5.5
[FPT-mysql55-community]
name=MySQL 5.5 Community Server
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-5.5-community/el/\$releasever/\$basearch/
enabled=0
gpgcheck=0

# Enable to use MySQL 5.6
[FPT-mysql56-community]
name=MySQL 5.6 Community Server
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-5.6-community/el/\$releasever/\$basearch/
enabled=0
gpgcheck=0

# Enable to use MySQL 5.7
[FPT-mysql57-community]
name=MySQL 5.7 Community Server
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-5.7-community/el/\$releasever/\$basearch/
enabled=0
gpgcheck=0

[FPT-mysql80-community]
name=MySQL 8.0 Community Server
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-8.0-community/el/\$releasever/\$basearch/
enabled=1
gpgcheck=0

[FPT-mysql80-mysql-cluster-7.6-community]
name=MySQL cluster 7.6 community
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-cluster-7.6-community/el/\$releasever/\$basearch/
enabled=1
gpgcheck=0

[FPT-mysql-cluster-7.5-community]
name=MySQL Cluster 7.5 Community
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-cluster-7.5-community/el/7/\$basearch/
enabled=0
gpgcheck=0

[FPT-mysql-connectors-community]
name=MySQL Connectors Community
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-connectors-community/el/\$releasever/\$basearch/
enabled=1
gpgcheck=0

[FPT-mysql-tools-community]
name=MySQL Tools Community
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-tools-community/el/\$releasever/\$basearch/
enabled=1
gpgcheck=0

[FPT-mysql-tools-preview]
name=MySQL Tools Preview
baseurl=http://$IPSERVER/repository/yum-mysql/yum/mysql-tools-preview/el/7/\$basearch/
enabled=1
gpgcheck=0


" > /etc/yum.repos.d/FHCM-MySQL.repo


yum clean all
}

#PATH=/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin

#repository IP address
IPSERVER=hcm-repo.fsoft.com.vn
export IPSERVER
#Check Linux OS
platform=`uname`
if [ "$platform" != "Linux" ];then
		echo "This package must be installed on Linux Platform."
		echo "Aborting installation."
		exit 1
fi

#Giá trị Mask sẽ “che đi” một số bit trong Base Permission để tạo ra quyền truy cập thực sự vào file
umask 022


#Check quyen root
user=`id | cut -d'=' -f2 | cut -d\( -f1`
if [ $user -ne 0 ]; then
    echo "Needs root authentication to install."
    exit 1
fi

#Check differentiate between Ubuntu and other Linux platforms 
if [ -f /etc/debian_version ]; then
	#Check dung la Ubuntu
	
	echo "Đây là Ubuntu, ban da sử dụng sai bản cài đặt!"
else
	#Check khong phai la Ubuntu
	#Con lai la Centos/Redhat
	yumSETFuction
	echo "Đã trỏ repo về Local Repository Centos"
fi
