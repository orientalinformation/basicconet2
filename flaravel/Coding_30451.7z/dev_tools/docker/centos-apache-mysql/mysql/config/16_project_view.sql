/*
  Project name: EMS
  Author: FPT
  Created date: 06/19/2020
  Modified date: 10/09/2020
  Version: 0.0.2
*/

set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

-- 処理履歴
DROP VIEW IF EXISTS department_name1 CASCADE;
CREATE VIEW department_name1 AS
SELECT DISTINCT
    department_list.department_name AS department_name
FROM
    (SELECT 
        e.organization_code AS organization_code,
            SUBSTRING_INDEX(SUBSTRING_INDEX(e.formal_organization_name, '　', 2), '　', -(1)) AS department_name
    FROM
        employee e
    WHERE
        (e.hierarchy > 1)
    ORDER BY e.organization_code) department_list;

DROP VIEW IF EXISTS department_name2 CASCADE;
CREATE VIEW department_name2 AS
SELECT DISTINCT
    department_list.department_name AS department_name
FROM
    (SELECT 
        e.organization_code AS organization_code,
            SUBSTRING_INDEX(SUBSTRING_INDEX(e.formal_organization_name, '　', 3), '　', -(1)) AS department_name
    FROM
        employee e
    WHERE
        (e.hierarchy = 3) UNION SELECT 
        e.organization_code AS organization_code,
            SUBSTRING_INDEX(SUBSTRING_INDEX(e.formal_organization_name, '　', 4), '　', -(2)) AS department_name
    FROM
        employee e
    WHERE
        (e.hierarchy > 3)
    ORDER BY organization_code) department_list;

DROP VIEW IF EXISTS department_name3 CASCADE;

CREATE VIEW department_name3 AS
SELECT DISTINCT department_name
FROM (
    SELECT
        e.organization_code,
        SUBSTRING_INDEX(SUBSTRING_INDEX(e.formal_organization_name, '　', 2), '　', -1) AS department_name
    FROM employee e
    WHERE e.hierarchy > 1
    UNION
    SELECT
        e.organization_code,
        SUBSTRING_INDEX(SUBSTRING_INDEX(e.formal_organization_name, '　', 3), '　', -2) AS department_name
    FROM employee e
    WHERE e.hierarchy = 3
    UNION
    SELECT
        e.organization_code,
        SUBSTRING_INDEX(SUBSTRING_INDEX(e.formal_organization_name, '　', 4), '　', -3) AS department_name
    FROM employee e
    WHERE e.hierarchy > 3
    ORDER BY organization_code ASC
) AS department_list;
