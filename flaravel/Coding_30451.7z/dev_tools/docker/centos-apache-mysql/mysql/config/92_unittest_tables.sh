#!/bin/sh

mysql -u root --password="${MYSQL_ROOT_PASSWORD}" -e " \
ALTER SCHEMA \`${MYSQL_DATABASE}\` DEFAULT CHARACTER SET utf8mb4 DEFAULT COLLATE utf8mb4_general_ci; \
"

mysql -u root --password="${MYSQL_ROOT_PASSWORD}" -e " \
use \`${MYSQL_DATABASE}_test\`; \
source /docker-entrypoint-initdb.d/01_cornet_tables.sql; \
source /docker-entrypoint-initdb.d/02_cornet_initial_data.sql; \
source /docker-entrypoint-initdb.d/11_project_tables.sql; \
source /docker-entrypoint-initdb.d/12_project_initial_data.sql; \
source /docker-entrypoint-initdb.d/13_project_initial_data.sql; \
source /docker-entrypoint-initdb.d/14_project_initial_data.sql; \
"
