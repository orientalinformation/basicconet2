set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

CREATE TABLE `cw_session_containers` (
	`id` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_general_ci',
	`data` MEDIUMTEXT NOT NULL,
	`expires` INT(11) NULL DEFAULT NULL,
	PRIMARY KEY (`id`),
	INDEX `expires` (`expires`)
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

CREATE TABLE `mw_session_containers` (
	`id` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_general_ci',
	`data` MEDIUMTEXT NOT NULL,
	`expires` INT(11) NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

CREATE TABLE `sw_session_containers` (
	`id` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_general_ci',
	`data` MEDIUMTEXT NOT NULL,
	`expires` INT(11) NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

CREATE TABLE `approval_master` (
	`system_function_id` VARCHAR(10) NOT NULL COMMENT '機能ID',
	`name` VARCHAR(32) NOT NULL COMMENT '機能名',
	`admin` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '管理者',
	`normal` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '一般',
	PRIMARY KEY (`system_function_id`)
)
COMMENT='認可'
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

CREATE TABLE `batch_execution_history` (
        `id` INT(11) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT COMMENT 'id',
        `batch_id` VARCHAR(10) NULL DEFAULT NULL COMMENT 'バッチID',
        `execution_datetime` DATETIME NULL DEFAULT NULL COMMENT '処理日時',
        `execution_type` VARCHAR(2) NOT NULL COMMENT '処理区分',
        `error_message` TEXT NULL COMMENT 'エラーメッセージ',
        `created_user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT '登録ユーザUID',
        `created` DATETIME NULL DEFAULT NULL COMMENT '登録日時',
        `created_token` VARCHAR(32) NULL DEFAULT NULL COMMENT '登録トークン',
        `modified_user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT '更新ユーザUID',
        `modified` DATETIME NULL DEFAULT NULL COMMENT '更新日時',
        `modified_token` VARCHAR(32) NULL DEFAULT NULL COMMENT '更新トークン',
        PRIMARY KEY (`id`),
        INDEX `batch_id` (`batch_id`),
        INDEX `execution_type` (`execution_type`)
)
COMMENT='バッチ処理履歴'
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1
;

CREATE TABLE `login_history` (
        `id` INT(11) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT COMMENT 'id',
        `login_datetime` DATETIME NOT NULL COMMENT 'ログイン履歴日時',
        `login_history_type` VARCHAR(2) NOT NULL COMMENT 'ログイン履歴区分',
        `user_id` VARCHAR(255) NULL DEFAULT NULL COMMENT 'ユーザID（ログイン時入力値）',
        `ip_address` VARCHAR(15) NULL DEFAULT NULL COMMENT 'IPアドレス',
        `user_agent` TEXT NULL COMMENT 'ユーザエージェント',
        `screen_type` VARCHAR(2) NOT NULL COMMENT '画面区分',
        `created_user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT '登録ユーザUID',
        `created` DATETIME NULL DEFAULT NULL COMMENT '登録日時',
        `created_token` VARCHAR(32) NULL DEFAULT NULL COMMENT '登録トークン',
        `modified_user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT '更新ユーザUID',
        `modified` DATETIME NULL DEFAULT NULL COMMENT '更新日時',
        `modified_token` VARCHAR(32) NULL DEFAULT NULL COMMENT '更新トークン',
        PRIMARY KEY (`id`),
        INDEX `user_id` (`user_id`)
)
COMMENT='ログイン履歴'
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1
;

CREATE TABLE `system_operation_log` (
        `id` INT(11) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT COMMENT 'id',
        `operation_datetime` DATETIME NOT NULL COMMENT 'システム操作日時',
        `user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT 'ユーザUID',
        `screen_id` VARCHAR(10) NULL DEFAULT NULL COMMENT '画面ID',
        `screen_type` VARCHAR(2) NOT NULL COMMENT '画面区分',
        `ip_address` VARCHAR(15) NULL DEFAULT NULL COMMENT 'IPアドレス',
        `user_agent` TEXT NULL COMMENT 'ユーザエージェント',
        `referer` VARCHAR(512) NULL DEFAULT NULL COMMENT 'リファラー',
        `url` VARCHAR(512) NULL DEFAULT NULL COMMENT 'URL',
        `created_user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT '登録ユーザUID',
        `created` DATETIME NULL DEFAULT NULL COMMENT '登録日時',
        `created_token` VARCHAR(32) NULL DEFAULT NULL COMMENT '登録トークン',
        `modified_user_uid` VARCHAR(11) NULL DEFAULT NULL COMMENT '更新ユーザUID',
        `modified` DATETIME NULL DEFAULT NULL COMMENT '更新日時',
        `modified_token` VARCHAR(32) NULL DEFAULT NULL COMMENT '更新トークン',
        PRIMARY KEY (`id`)
)
COMMENT='システム操作ログ'
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1
;

CREATE TABLE `user_agent_master` (
        `user_agent` VARCHAR(64) NOT NULL COMMENT 'ユーザエージェント',
        `type` VARCHAR(2) NULL DEFAULT NULL COMMENT 'タイプ',
        PRIMARY KEY (`user_agent`)
)
COMMENT='ユーザエージェントマスタ'
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;
