set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

INSERT INTO `user_agent_master` (`user_agent`, `type`) VALUES
('DoCoMo', '4')
,('KDDI', '4')
,('UP.Browser', '4')
,('SoftBank', '4')
,('J-PHONE', '4')
,('Vodafone', '4')
,('iPhone', '2')
,('Android', '3')
,('PCその他', '1')
;
