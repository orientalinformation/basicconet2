/*
  Project name: EMS
  Author: FPT
  Created date: 17/03/2020
  Modified date: 17/03/2020
  Version: 0.0.1
  Comment: Baseline spec 契約書種類マスタ v0.0.4
*/

set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

TRUNCATE TABLE contract_kind;
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (1, '【ICT標準① SI 202006】業務委任契約書', '1', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (2, '【ICT標準② SI 202006】ソフトウェア開発委託契約書', '2', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (3, '【ICT標準③ SI 202006】運用保守業務委託契約書', '3', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (4, '【ICT標準④ PF 202006】業務委任契約書', '4', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (5, '【ICT標準⑤DDS202012】開発・制作サービス約款', '5', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (6, '【ICT標準⑥DDS202012】保守サポート契約書', '6', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (7, 'MediaGalaxyクラウドホスティングサービス利用約款', '7', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (8, 'MediaGalaxyクラウドIaaS利用約款', '8', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (9, 'MediaGalaxy（物理）ホスティング約款', '9', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (10, 'AWSホスティングサービス約款', '10', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (11, 'ハウジングサービス利用約款', '11', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (12, 'ハウジングサービス説明書', '12', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (13, 'デジメール利用約款', '13', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (14, 'デジメールAPI利用サービス特約', '14', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (15, 'アンケートクリエーター＋（ASP 型）利用約款', '15', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (16, '「アンケートクリエーター ASP型） 」サービス説明資料', '16', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (17, 'ＳＥＳ及び準委任型個別覚書', '17', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (18, 'PROMAX NEO　向けOLA', '18', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (19, 'PROMAX DB　向けOLA', '19', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (20, 'AI審査 PF　向けOLA', '20', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (21, 'Retail Meister　向けOLA', '21', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (22, 'デジタル帳票　向けOLA', '22', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (23, 'Connecting One　小浜環境向けOLA', '23', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (24, 'Connecting One　柏環境向けOLA', '24', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (25, 'みずほウォレット(Android版)ソフトウェア保守サービス仕様', '25', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
INSERT INTO contract_kind (contract_kind_seq, contract_kind_name, display_order, created_user_uid, created, modified_user_uid, modified, created_token, modified_token) VALUES (26, '即時発行 ソフトウェア保守サービス仕様', '26', null, '1000-01-01 00:00:00', null, '1000-01-01 00:00:00', null, null);
