/*
  Project name: EMS
  Author: FPT
  Created date: 06/17/2020
  Modified date: 11/12/2020
  Version: 0.1.4
  Comment: Add script alter base on DB spec v0.1.4
*/

set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

ALTER TABLE estimate
  ADD (
    first_organization_code   VARCHAR(42) COMMENT '第一承認者（組織コード）',
    second_organization_code  VARCHAR(42) COMMENT '第二承認者（組織コード）',
    third_organization_code   VARCHAR(42) COMMENT '第三承認者（組織コード）',
    remarks                   VARCHAR(1000) COMMENT '備考'
    );


ALTER TABLE approval_root
  ADD (
    first_organization_code   VARCHAR(42) COMMENT '第一承認者（組織コード）',
    second_organization_code  VARCHAR(42) COMMENT '第二承認者（組織コード）',
    third_organization_code  VARCHAR(42) COMMENT '第三承認者（組織コード）'
    );

/*
  Alter for DB spec v0.0.13
*/
ALTER TABLE estimate_sub
  MODIFY quantity DECIMAL
;

ALTER TABLE estimate_detail
  MODIFY quantity DECIMAL
;

ALTER TABLE employee
  MODIFY estimate_division_code VARCHAR(6) NOT NULL
;

/*
  Alter for DB spec v0.0.15
*/
ALTER TABLE estimate
  MODIFY application_date DATETIME,
  MODIFY total_amount BIGINT,
  ADD correct_original_estimate_id VARCHAR(15) COMMENT '訂正元見積書ID'
;

ALTER TABLE estimate_main
  MODIFY amount BIGINT
;

ALTER TABLE estimate_sub
  MODIFY amount BIGINT
;

ALTER TABLE estimate_detail
  MODIFY amount BIGINT
;

/*
  Alter for DB spec v0.0.16
*/
ALTER TABLE manage_information
  MODIFY amount BIGINT,
  MODIFY man_hours BIGINT,
  MODIFY final_client VARCHAR(60)
;

/*
  Alter for DB spec v0.0.17
*/
ALTER TABLE estimate_sub
  MODIFY quantity DECIMAL(7,3)
;

ALTER TABLE estimate_detail
  MODIFY quantity DECIMAL(7,3)
;

/*
  Alter for DB spec v0.0.18
*/
ALTER TABLE estimate
  MODIFY estimate_id BIGINT NOT NULL AUTO_INCREMENT,
  MODIFY system_manage_id BIGINT,
  MODIFY approval_root_id BIGINT
;

ALTER TABLE estimate_main
  MODIFY estimate_main_id BIGINT NOT NULL AUTO_INCREMENT,
  MODIFY estimate_id BIGINT NOT NULL
;

ALTER TABLE estimate_sub
  MODIFY estimate_sub_id BIGINT NOT NULL AUTO_INCREMENT,
  MODIFY estimate_id BIGINT NOT NULL,
  MODIFY estimate_main_id BIGINT NOT NULL
;

ALTER TABLE estimate_detail
  MODIFY estimate_detail_id BIGINT NOT NULL AUTO_INCREMENT,
  MODIFY estimate_id BIGINT NOT NULL,
  MODIFY estimate_main_id BIGINT NOT NULL,
  MODIFY estimate_sub_id BIGINT NOT NULL
;

ALTER TABLE estimate_comment
  MODIFY estimate_comment_id BIGINT NOT NULL AUTO_INCREMENT,
  MODIFY estimate_id BIGINT NOT NULL,
  MODIFY estimate_main_id BIGINT NOT NULL,
  MODIFY estimate_sub_id BIGINT NOT NULL,
  MODIFY estimate_detail_id BIGINT
;

ALTER TABLE manage_information
  MODIFY system_manage_id BIGINT NOT NULL AUTO_INCREMENT
;

ALTER TABLE attached_file_information
  MODIFY attached_file_information_id BIGINT NOT NULL AUTO_INCREMENT,
  MODIFY system_manage_id BIGINT NOT NULL
;

ALTER TABLE approval_history
  MODIFY estimate_id BIGINT NOT NULL
;

ALTER TABLE approval_root
  MODIFY approval_root_id BIGINT NOT NULL AUTO_INCREMENT
;

ALTER TABLE process_history
  MODIFY process_history_seq BIGINT NOT NULL AUTO_INCREMENT
;

/*
  Alter for DB spec v0.0.19
*/
ALTER TABLE manage_information
  MODIFY man_hours DECIMAL(10,2) COMMENT '工数'
;

/*
  Alter for DB follow ticket #28351
*/
ALTER TABLE estimate_detail
  MODIFY unit VARCHAR(5) COMMENT '単位'
;

/*
  Alter for DB spec v0.1.1
*/
DROP TABLE IF EXISTS index_id CASCADE;
CREATE TABLE index_id
(
  index_code        VARCHAR(6) COMMENT '採番CD',
  yy_mm             VARCHAR(4) COMMENT '年月',
  counter           BIGINT COMMENT 'シーケンス番号',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_index_id PRIMARY KEY (index_code, yy_mm)
)
  COMMENT ='見積番号採番用のカウンタを保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

/*
  Alter for DB spec v0.1.2
*/
ALTER TABLE estimate
  ADD (
    head_part_code VARCHAR(42) COMMENT '本部コード'
  );

/*
  Drop VIEW for DB follow ticket #29075
*/
DROP VIEW IF EXISTS department_name4 CASCADE;

/*
  Alter for DB spec v0.1.3
*/
ALTER TABLE manage_information
  ADD (
    update_company_name VARCHAR(40) COMMENT '最終更新者会社名',
    update_department_name1 VARCHAR(150) COMMENT '最終更新者事業部名',
    update_department_name2 VARCHAR(150) COMMENT '最終更新者者部署名',
    update_employee_no VARCHAR(7) COMMENT '最終更新者社員番号',
    update_employee_family_name VARCHAR(40) COMMENT '最終更新者(姓)',
    update_employee_first_name VARCHAR(40) COMMENT '最終更新者(名)'
  );

/*
  Alter for DB spec v0.1.4
*/
ALTER TABLE estimate_sub
  MODIFY quantity DECIMAL(10,3),
  MODIFY unit_cost DECIMAL(11,1)
;

/*
  Alter for DB spec v0.1.4
*/
ALTER TABLE estimate_detail
  MODIFY quantity DECIMAL(10,3),
  MODIFY unit_cost DECIMAL(11,1)
;

/*
  Alter for DB spec v0.1.5
*/
ALTER TABLE estimate
  ADD data_kind       VARCHAR(1) COMMENT 'データ種別',
  ADD origin_data_seq BIGINT COMMENT '発生元seq'
;

ALTER TABLE code_value
  MODIFY division VARCHAR(20) COMMENT '分類',
  MODIFY value VARCHAR(1000) COMMENT '値'
;

ALTER TABLE process_history
  ADD process_date  VARCHAR(8) COMMENT '処理日',
  ADD process_count INT COMMENT '回目'
;

CREATE TABLE process_history_info (
  process_history_info_seq  BIGINT  NOT NULL  AUTO_INCREMENT,
  process_history_seq       BIGINT  NOT NULL  COMMENT '処理履歴SEQ',
  line_number               INT   COMMENT '行数',
  record_info               VARCHAR(100)   COMMENT 'レコード情報',
  item_name                 VARCHAR(100)   COMMENT '項目名',
  error_info                VARCHAR(1000)   COMMENT 'エラー情報',
  created_user_uid          VARCHAR(15)   COMMENT '新規登録者ID',
  created                   DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid         VARCHAR(15)   COMMENT '最終更新者ID',
  modified                  DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token             VARCHAR(32)   COMMENT '登録トークン',
  modified_token            VARCHAR(32)   COMMENT '更新トークン',
  CONSTRAINT pkc_process_history_info PRIMARY KEY (process_history_info_seq, process_history_seq)
)
  COMMENT ='画面、バッチの処理履歴を登録するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

/*
  Alter for DB spec v0.1.6
*/
ALTER TABLE process_history
  ADD process_start_date DATETIME DEFAULT '1000-01-01 00:00:00' COMMENT '処理開始日時',
  ADD process_end_date DATETIME DEFAULT '1000-01-01 00:00:00' COMMENT '処理終了日時'
;

/*
  Alter for DB spec v0.1.7
*/
ALTER TABLE estimate
  ADD payment_terms VARCHAR(20) COMMENT '御支払条件'
;

-- 見積書（契約書）
DROP TABLE IF EXISTS estimate_contract CASCADE;

CREATE TABLE estimate_contract
(
  estimate_contract_id BIGINT   NOT NULL AUTO_INCREMENT,
  estimate_id          BIGINT   NOT NULL COMMENT '見積書ID',
  contract_id          BIGINT   NOT NULL COMMENT '契約書ID',
  display_order        SMALLINT          DEFAULT '1' COMMENT '表示順',
  created_user_uid     VARCHAR(15) COMMENT '新規登録者ID',
  created              DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid    VARCHAR(15) COMMENT '最終更新者ID',
  modified             DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token        VARCHAR(32) COMMENT '登録トークン',
  modified_token       VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_contract PRIMARY KEY (estimate_contract_id)
)
  COMMENT ='見積の契約書を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 契約書マスタ
DROP TABLE IF EXISTS contract CASCADE;

CREATE TABLE contract
(
  contract_id            BIGINT     NOT NULL AUTO_INCREMENT,
  contract_category_code VARCHAR(2) NOT NULL COMMENT '契約書カテゴリーCD',
  contract_kind_seq      BIGINT     NOT NULL COMMENT '契約書種類seq',
  contract_file_name     VARCHAR(1000) COMMENT 'ファイル名',
  release_date           VARCHAR(8) COMMENT 'リリース日',
  display_order          SMALLINT            DEFAULT '1' COMMENT '表示順',
  display_status         VARCHAR(1) COMMENT '表示ステータス',
  created_user_uid       VARCHAR(15) COMMENT '新規登録者ID',
  created                DATETIME   NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid      VARCHAR(15) COMMENT '最終更新者ID',
  modified               DATETIME   NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token          VARCHAR(32) COMMENT '登録トークン',
  modified_token         VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_contract PRIMARY KEY (contract_id)
)
  COMMENT ='契約書・約款を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

/*
  Alter for DB spec v0.1.8
*/

-- 契約書種類マスタ
DROP TABLE IF EXISTS contract_kind CASCADE;

CREATE TABLE contract_kind
(
  contract_kind_seq  BIGINT      NOT NULL AUTO_INCREMENT,
  contract_kind_name VARCHAR(50) NOT NULL COMMENT '契約書種類名',
  display_order      SMALLINT             DEFAULT '1' COMMENT '表示順',
  created_user_uid   VARCHAR(15) COMMENT '新規登録者ID',
  created            DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid  VARCHAR(15) COMMENT '最終更新者ID',
  modified           DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token      VARCHAR(32) COMMENT '登録トークン',
  modified_token     VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_contract_kind PRIMARY KEY (contract_kind_seq)
)
  COMMENT ='契約書・約款の種類を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;
