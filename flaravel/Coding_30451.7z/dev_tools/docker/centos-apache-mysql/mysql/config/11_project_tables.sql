/*
  Project name: EMS
  Author: FPT
  Created date: 06/01/2020
  Modified date: 11/12/2020
  Version: 0.1.3
*/

set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

-- 社員マスタ
DROP TABLE IF EXISTS employee CASCADE;

CREATE TABLE employee
(
  employee_seq                BIGINT   NOT NULL AUTO_INCREMENT,
  employee_no                 VARCHAR(7) COMMENT '社員番号',
  add_post_type               VARCHAR(3) COMMENT '兼務区分',
  employee_name               VARCHAR(82) COMMENT '氏名',
  employee_family_name        VARCHAR(40) COMMENT '姓',
  employee_first_name         VARCHAR(40) COMMENT '名',
  employee_name_kana          VARCHAR(82) COMMENT 'カナ氏名',
  employee_family_name_kana   VARCHAR(40) COMMENT 'カナ姓',
  employee_first_name_kana    VARCHAR(40) COMMENT 'カナ名',
  bc_company_code             VARCHAR(6) COMMENT '会社コード',
  organization_code           VARCHAR(42) COMMENT '組織コード',
  hierarchy                   VARCHAR(1) COMMENT '階層',
  formal_organization_name    VARCHAR(1062) COMMENT '正式組織名',
  company_name                VARCHAR(40) COMMENT '会社名',
  head_part_code              VARCHAR(42) COMMENT '本部コード',
  head_part_name              VARCHAR(264) COMMENT '本部名',
  s_low_rank                  VARCHAR(200) COMMENT '組織名（最下位所属名称）',
  upper_organization_code     VARCHAR(42) COMMENT '上位組織コード',
  upper_hierarchy             VARCHAR(1) COMMENT '上位階層',
  functional_duty_type        VARCHAR(1) COMMENT '本務区分',
  head_post_code              VARCHAR(4) COMMENT '管理職コード',
  head_post_name              VARCHAR(150) COMMENT '管理職名',
  post_code                   VARCHAR(4) COMMENT '役職コード',
  post_name                   VARCHAR(150) COMMENT '役職名',
  pro_code                    VARCHAR(4) COMMENT '専門職コード',
  pro_name                    VARCHAR(150) COMMENT '専門職名',
  priority_family_name        VARCHAR(100) COMMENT 'Ｔｅｌｓｅａｒｃｈ優先名',
  tel_disp_family_name        VARCHAR(142) COMMENT 'Ｔｅｌｓｅａｒｃｈ表示姓',
  priority_family_name_kana   VARCHAR(100) COMMENT 'Ｔｅｌｓｅａｒｃｈ優先表示カナ',
  priority_family_name_romaji VARCHAR(100) COMMENT 'Ｔｅｌｓｅａｒｃｈ優先表示ローマ字',
  mail_address                VARCHAR(100) COMMENT 'メールアドレス',
  estimate_division_code      VARCHAR(6) NOT NULL  COMMENT '見積部門コード',
  created_user_uid            VARCHAR(15) COMMENT '新規登録者ID',
  created                     DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid           VARCHAR(15) COMMENT '最終更新者ID',
  modified                    DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token               VARCHAR(32) COMMENT '登録トークン',
  modified_token              VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_employee PRIMARY KEY (employee_seq)
)
  COMMENT ='社員を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- 得意先マスタ
DROP TABLE IF EXISTS customer CASCADE;

CREATE TABLE customer
(
  customer_code     CHAR(6) COMMENT '得意先代表コード',
  customer_name     VARCHAR(60) COMMENT '得意先名',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_customer PRIMARY KEY (customer_code)
)
  COMMENT ='得意先を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- コード値マスタ
DROP TABLE IF EXISTS code_value CASCADE;

CREATE TABLE code_value
(
  code_value_master_seq BIGINT   NOT NULL AUTO_INCREMENT,
  division              VARCHAR(20) COMMENT '分類',
  division_name         VARCHAR(256) COMMENT '分類名',
  code                  VARCHAR(16) COMMENT 'コード',
  value                 VARCHAR(1000) COMMENT '値',
  sort                  TEXT(2) COMMENT '表示順',
  default_status        VARCHAR(1) COMMENT '初期ステータス',
  created_user_uid      VARCHAR(15) COMMENT '新規登録者ID',
  created               DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid     VARCHAR(15) COMMENT '最終更新者ID',
  modified              DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token         VARCHAR(32) COMMENT '登録トークン',
  modified_token        VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_code_value PRIMARY KEY (code_value_master_seq)
)
  COMMENT ='コード値を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- 採番マスタ
DROP TABLE IF EXISTS index_id CASCADE;

CREATE TABLE index_id
(
  index_code        VARCHAR(6) COMMENT '採番CD',
  yy_mm             VARCHAR(4) COMMENT '年月',
  counter           BIGINT COMMENT 'シーケンス番号',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_index_id PRIMARY KEY (index_code, yy_mm)
)
  COMMENT ='見積番号採番用のカウンタを保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 見積書
DROP TABLE IF EXISTS estimate CASCADE;

CREATE TABLE estimate
(
  estimate_id                          BIGINT NOT NULL AUTO_INCREMENT COMMENT '見積書ID',
  system_manage_id                     BIGINT COMMENT '管理情報ID',
  approval_root_id                     BIGINT COMMENT '承認ルートID',
  estimate_no                          VARCHAR(19) COMMENT '見積書番号',
  estimate_no_division                 VARCHAR(6) COMMENT '見積書番号(部門CD）',
  estimate_no_ym                       VARCHAR(4) COMMENT '見積書番号(年月)',
  estimate_no_division_seq             VARCHAR(4) COMMENT '見積書番号（部署毎の連番）',
  estimate_no_branch_num               VARCHAR(2) COMMENT '見積書番号（枝番）',
  head_part_code                       VARCHAR(42) COMMENT '本部コード',
  create_company_name                  VARCHAR(40) COMMENT '作成者会社名',
  create_department_name1              VARCHAR(150) COMMENT '作成者事業部名',
  create_department_name2              VARCHAR(150) COMMENT '作成者部署名',
  employee_no                          VARCHAR(7) COMMENT '社員番号',
  create_employee_family_name          VARCHAR(40) COMMENT '作成者(姓)',
  create_employee_first_name           VARCHAR(40) COMMENT '作成者(名)',
  application_date                     DATETIME COMMENT '申請日',
  printing_flag                        TINYINT COMMENT '印字有無',
  address                              VARCHAR(100) COMMENT '住所',
  phone_number                         VARCHAR(20) COMMENT '電話番号',
  fax_no                               VARCHAR(20) COMMENT 'FAX番号',
  title                                VARCHAR(256) COMMENT '見積書タイトル',
  issue_date                           VARCHAR(8) COMMENT '発行日',
  destination1                         VARCHAR(31) COMMENT '宛先１',
  destination2                         VARCHAR(31) COMMENT '宛先２',
  destination3                         VARCHAR(31) COMMENT '宛先３',
  subject1                             VARCHAR(26) COMMENT '件名１',
  subject2                             VARCHAR(26) COMMENT '件名２',
  delivery_date                        VARCHAR(20) COMMENT '納入日',
  delivery_location                    VARCHAR(20) COMMENT '納入場所',
  payment_terms                        VARCHAR(20) COMMENT '御支払条件',
  expiration_date                      VARCHAR(20) COMMENT '見積有効期限',
  tax_signage                          VARCHAR(3) COMMENT '消費税表記',
  proviso                              VARCHAR(30) COMMENT '但し書き',
  total_amount                         BIGINT COMMENT '合計金額',
  status                               VARCHAR(2) COMMENT 'ステータス',
  estimate_contract                    TEXT COMMENT '見積条件',
  first_approval_employee_no           VARCHAR(7) COMMENT '第一承認者（社員番号）',
  first_organization_code              VARCHAR(42) COMMENT '第一承認者（組織コード）',
  first_approval_employee_family_name  VARCHAR(40) COMMENT '第一承認者（姓)',
  first_approval_employee_first_name   VARCHAR(40) COMMENT '第一承認者（名)',
  first_approval_department_name       VARCHAR(150) COMMENT '第一承認者（部署名）',
  first_approval_post_name             VARCHAR(150) COMMENT '第一承認者（役職）',
  first_approval_comment               VARCHAR(1000) COMMENT '第一承認者（承認コメント/差戻し理由）',
  first_approval_state                 CHAR(1) COMMENT '第一承認者（ステータス）',
  first_approval_date                  DATETIME COMMENT '第一承認者（承認日時）',
  second_approval_employee_no          VARCHAR(7) COMMENT '第二承認者（社員番号）',
  second_organization_code             VARCHAR(42) COMMENT '第二承認者（組織コード）',
  second_approval_employee_family_name VARCHAR(40) COMMENT '第二承認者（姓)',
  second_approval_employee_first_name  VARCHAR(40) COMMENT '第二承認者（名)',
  second_approval_department_name      VARCHAR(150) COMMENT '第二承認者（部署名）',
  second_approval_post_name            VARCHAR(150) COMMENT '第二承認者（役職）',
  second_approval_comment              VARCHAR(1000) COMMENT '第二承認者（承認コメント/差戻し理由）',
  second_approval_state                CHAR(1) COMMENT '第二承認者（ステータス）',
  second_approval_date                 DATETIME COMMENT '第二承認者（承認日時）',
  third_approval_employee_no           VARCHAR(7) COMMENT '第三承認者（社員番号）',
  third_organization_code              VARCHAR(42) COMMENT '第三承認者（組織コード）',
  third_approval_employee_family_name  VARCHAR(40) COMMENT '第三承認者（姓)',
  third_approval_employee_first_name   VARCHAR(40) COMMENT '第三承認者（名)',
  third_approval_department_name       VARCHAR(150) COMMENT '第三承認者（部署名）',
  third_approval_post_name             VARCHAR(150) COMMENT '第三承認者（役職）',
  third_approval_comment               VARCHAR(1000) COMMENT '第三承認者（承認コメント/差戻し理由）',
  third_approval_state                 CHAR(1) COMMENT '第三承認者（ステータス）',
  third_approval_date                  DATETIME COMMENT '第三承認者（承認日時）',
  remarks                              VARCHAR(1000) COMMENT '備考',
  correct_original_estimate_id         VARCHAR(15) COMMENT '訂正元見積書ID',
  data_kind                            VARCHAR(1) COMMENT 'データ種別',
  origin_data_seq                      BIGINT COMMENT '発生元seq',
  created_user_uid                     VARCHAR(15) COMMENT '新規登録者ID',
  created                              DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid                    VARCHAR(15) COMMENT '最終更新者ID',
  modified                             DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token                        VARCHAR(32) COMMENT '登録トークン',
  modified_token                       VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate PRIMARY KEY (estimate_id)
)
  COMMENT ='見積のヘッダー情報を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 明細書（大項目）
DROP TABLE IF EXISTS estimate_main CASCADE;

CREATE TABLE estimate_main
(
  estimate_main_id  BIGINT NOT NULL AUTO_INCREMENT COMMENT '明細書（大項目）ID',
  estimate_id       BIGINT NOT NULL COMMENT '見積書ID',
  item_name         VARCHAR(32) COMMENT '大項目名',
  amount            BIGINT COMMENT '合計金額',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_main PRIMARY KEY (estimate_main_id)
)
  COMMENT ='見積の明細（大項目）を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 明細書（中項目）
DROP TABLE IF EXISTS estimate_sub CASCADE;

CREATE TABLE estimate_sub
(
  estimate_sub_id   BIGINT NOT NULL AUTO_INCREMENT COMMENT '明細書（中項目）ID',
  estimate_id       BIGINT NOT NULL COMMENT '見積書ID',
  estimate_main_id  BIGINT NOT NULL COMMENT '明細書（大項目）ID',
  item_name         VARCHAR(32) COMMENT '中項目名',
  quantity          DECIMAL(10,3) COMMENT '数量',
  unit              VARCHAR(32) COMMENT '単位',
  unit_cost         DECIMAL(11,1) COMMENT '単価',
  amount            BIGINT COMMENT '金額',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_sub PRIMARY KEY (estimate_sub_id)
)
  COMMENT ='見積の明細（中項目）を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 明細書（小項目）
DROP TABLE IF EXISTS estimate_detail CASCADE;

CREATE TABLE estimate_detail
(
  estimate_detail_id BIGINT NOT NULL AUTO_INCREMENT COMMENT '明細書（小項目）ID',
  estimate_id        BIGINT NOT NULL COMMENT '見積書ID',
  estimate_main_id   BIGINT NOT NULL COMMENT '明細書（大項目）ID',
  estimate_sub_id    BIGINT NOT NULL COMMENT '明細書（中項目）ID',
  item_name          VARCHAR(32) COMMENT '項目名',
  quantity           DECIMAL(10,3) COMMENT '数量',
  unit               VARCHAR(5) COMMENT '単位',
  unit_cost          DECIMAL(11,1) COMMENT '単価',
  amount             BIGINT COMMENT '金額',
  created_user_uid   VARCHAR(15) COMMENT '新規登録者ID',
  created            DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid  VARCHAR(15) COMMENT '最終更新者ID',
  modified           DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token      VARCHAR(32) COMMENT '登録トークン',
  modified_token     VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_detail PRIMARY KEY (estimate_detail_id)
)
  COMMENT ='見積の明細（小項目）を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 明細書（コメント）
DROP TABLE IF EXISTS estimate_comment CASCADE;

CREATE TABLE estimate_comment
(
  estimate_comment_id BIGINT NOT NULL AUTO_INCREMENT COMMENT '明細書（コメント）ID',
  estimate_id         BIGINT NOT NULL COMMENT '見積書ID',
  estimate_main_id    BIGINT NOT NULL COMMENT '明細書（大項目）ID',
  estimate_sub_id     BIGINT NOT NULL COMMENT '明細書（中項目）ID',
  estimate_detail_id  BIGINT COMMENT '明細書（小項目）ID',
  comment             VARCHAR(32) COMMENT 'コメント',
  display_order       SMALLINT             DEFAULT '1' COMMENT '表示順',
  created_user_uid    VARCHAR(15) COMMENT '新規登録者ID',
  created             DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid   VARCHAR(15) COMMENT '最終更新者ID',
  modified            DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token       VARCHAR(32) COMMENT '登録トークン',
  modified_token      VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_comment PRIMARY KEY (estimate_comment_id)
)
  COMMENT ='見積の明細（コメント）を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 管理情報
DROP TABLE IF EXISTS manage_information CASCADE;

CREATE TABLE manage_information
(
  system_manage_id          BIGINT NOT NULL AUTO_INCREMENT COMMENT '管理情報ID',
  inquiry_date              VARCHAR(8) COMMENT '引合日',
  proposition_name          VARCHAR(100) COMMENT '案件名',
  proposition_details       VARCHAR(1000) COMMENT '案件詳細',
  solution                  VARCHAR(256) COMMENT 'ソリューション',
  built_environment         VARCHAR(20) COMMENT '構築環境',
  amount                    BIGINT COMMENT '金額',
  man_hours                 BIGINT COMMENT '工数',
  order_plan_date           VARCHAR(8) COMMENT '受注予定日',
  delivery_plan_date        VARCHAR(8) COMMENT '納品予定日',
  requester_company_name    VARCHAR(50) COMMENT '依頼元（会社名）',
  requester_department_name VARCHAR(50) COMMENT '依頼元（事業部名）',
  requester_division_name   VARCHAR(50) COMMENT '依頼元（部門名）',
  requester_charge_name1    VARCHAR(50) COMMENT '依頼元（担当者名１）',
  requester_charge_name2    VARCHAR(50) COMMENT '依頼元（担当者名２）',
  final_client              VARCHAR(60) COMMENT '最終クライアント',
  structure_division        VARCHAR(50) COMMENT '体制（自担当部門）',
  structure_cooperation1    VARCHAR(50) COMMENT '体制（協働部門１）',
  structure_cooperation2    VARCHAR(50) COMMENT '体制（協働部門２）',
  structure_cooperation3    VARCHAR(50) COMMENT '体制（協働部門３）',
  case_type                 VARCHAR(10) COMMENT '案件種類',
  cycle                     VARCHAR(2) COMMENT '周期',
  start_month               VARCHAR(2) COMMENT '開始月',
  accuracy                  VARCHAR(1) COMMENT '確度',
  progress                  VARCHAR(10) COMMENT '進捗度',
  adopt_estimate_no         VARCHAR(19) COMMENT '採用見積書番号',
  request_documents_text    VARCHAR(1000) COMMENT '要求資料テキスト',
  estimate_rationale_text   VARCHAR(1000) COMMENT '見積根拠テキスト',
  review_record_text        VARCHAR(1000) COMMENT 'レビュー記録テキスト',
  comment                   VARCHAR(1000) COMMENT 'コメント',
  update_company_name       VARCHAR(40) COMMENT '最終更新者会社名',
  update_department_name1   VARCHAR(150) COMMENT '最終更新者事業部名',
  update_department_name2   VARCHAR(150) COMMENT '最終更新者者部署名',
  update_employee_no          VARCHAR(7) COMMENT '最終更新者社員番号',
  update_employee_family_name VARCHAR(40) COMMENT '最終更新者(姓)',
  update_employee_first_name  VARCHAR(40) COMMENT '最終更新者(名)',
  created_user_uid          VARCHAR(15) COMMENT '新規登録者ID',
  created                   DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid         VARCHAR(15) COMMENT '最終更新者ID',
  modified                  DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token             VARCHAR(32) COMMENT '登録トークン',
  modified_token            VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_manage_information PRIMARY KEY (system_manage_id)
)
  COMMENT ='見積の管理情報を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 添付ファイル情報
DROP TABLE IF EXISTS attached_file_information CASCADE;

CREATE TABLE attached_file_information
(
  attached_file_information_id BIGINT NOT NULL AUTO_INCREMENT COMMENT '添付ファイル情報ID',
  system_manage_id             BIGINT NOT NULL COMMENT '管理情報ID',
  classification               CHAR(1) COMMENT '分類',
  file_information             VARCHAR(1000) COMMENT 'ファイル情報',
  display_order                SMALLINT             DEFAULT '1' COMMENT '表示順',
  created_user_uid             VARCHAR(15) COMMENT '新規登録者ID',
  created                      DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid            VARCHAR(15) COMMENT '最終更新者ID',
  modified                     DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token                VARCHAR(32) COMMENT '登録トークン',
  modified_token               VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_attached_file_information PRIMARY KEY (attached_file_information_id)
)
  COMMENT ='見積に添付されたファイル情報を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 承認ログ
DROP TABLE IF EXISTS approval_history CASCADE;

CREATE TABLE approval_history
(
  approval_history_seq          BIGINT NOT NULL AUTO_INCREMENT,
  estimate_id                   BIGINT NOT NULL COMMENT '見積書ID',
  approval_employee_no          VARCHAR(7) COMMENT '承認者（社員番号）',
  approval_employee_family_name VARCHAR(40) COMMENT '承認者（姓)',
  approval_employee_first_name  VARCHAR(40) COMMENT '承認者（名)',
  approval_department_name      VARCHAR(150) COMMENT '承認者（部署名）',
  approval_post_name            VARCHAR(150) COMMENT '承認者（役職）',
  approval_comment              VARCHAR(1000) COMMENT '承認者（承認コメント/差戻し理由）',
  approval_state                CHAR(1) COMMENT '承認者（ステータス）',
  approval_date                 DATETIME COMMENT '承認者（承認日時）',
  created_user_uid              VARCHAR(15) COMMENT '新規登録者ID',
  created                       DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid             VARCHAR(15) COMMENT '最終更新者ID',
  modified                      DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token                 VARCHAR(32) COMMENT '登録トークン',
  modified_token                VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_approval_history PRIMARY KEY (approval_history_seq)
)
  COMMENT ='承認履歴を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- 宛先
DROP TABLE IF EXISTS destination CASCADE;

CREATE TABLE destination
(
  destination_company_seq BIGINT   NOT NULL AUTO_INCREMENT,
  employee_no             VARCHAR(7) COMMENT '社員番号',
  destination_company_1   VARCHAR(31) COMMENT '宛先１',
  destination_company_2   VARCHAR(31) COMMENT '宛先２',
  destination_company_3   VARCHAR(31) COMMENT '宛先３',
  created_user_uid        VARCHAR(15) COMMENT '新規登録者ID',
  created                 DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid       VARCHAR(15) COMMENT '最終更新者ID',
  modified                DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token           VARCHAR(32) COMMENT '登録トークン',
  modified_token          VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_destination PRIMARY KEY (destination_company_seq)
)
  COMMENT ='宛先を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- 承認ルート
DROP TABLE IF EXISTS approval_root CASCADE;

CREATE TABLE approval_root
(
  approval_root_id            BIGINT NOT NULL AUTO_INCREMENT COMMENT '承認ルートID',
  employee_no                 VARCHAR(7) COMMENT '社員番号',
  first_approval_employee_no  VARCHAR(7) COMMENT '第一承認者（社員番号）',
  first_organization_code     VARCHAR(42) COMMENT '第一承認者（組織コード）',
  first_department_name       VARCHAR(150) COMMENT '第一承認者（部署名）',
  first_post_name             VARCHAR(150) COMMENT '第一承認者（役職）',
  second_approval_employee_no VARCHAR(7) COMMENT '第二承認者（社員番号）',
  second_organization_code    VARCHAR(42) COMMENT '第二承認者（組織コード）',
  second_department_name      VARCHAR(150) COMMENT '第二承認者（部署名）',
  second_post_name            VARCHAR(150) COMMENT '第二承認者（役職）',
  third_approval_employee_no  VARCHAR(7) COMMENT '第三承認者（社員番号）',
  third_organization_code     VARCHAR(42) COMMENT '第三承認者（組織コード）',
  third_department_name       VARCHAR(150) COMMENT '第三承認者（部署名）',
  third_post_name             VARCHAR(150) COMMENT '第三承認者（役職）',
  remarks                     VARCHAR(1000) COMMENT '備考',
  created_user_uid            VARCHAR(15) COMMENT '新規登録者ID',
  created                     DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid           VARCHAR(15) COMMENT '最終更新者ID',
  modified                    DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token               VARCHAR(32) COMMENT '登録トークン',
  modified_token              VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_approval_root PRIMARY KEY (approval_root_id)
)
  COMMENT ='承認ルートを管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- プロフィール
DROP TABLE IF EXISTS profile CASCADE;

CREATE TABLE profile
(
  profile_seq       BIGINT   NOT NULL AUTO_INCREMENT,
  employee_no       VARCHAR(7) COMMENT '社員番号',
  address           VARCHAR(100) COMMENT '住所',
  telephone_no      VARCHAR(20) COMMENT '電話番号',
  fax_no            VARCHAR(20) COMMENT 'FAX番号',
  display_order     SMALLINT          DEFAULT '1' COMMENT '表示順',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_profile PRIMARY KEY (profile_seq)
)
  COMMENT ='プロフィールを管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- ユーザ権限管理
DROP TABLE IF EXISTS user_authority CASCADE;

CREATE TABLE user_authority
(
  user_authority_seq  BIGINT   NOT NULL AUTO_INCREMENT,
  employee_no         VARCHAR(7) COMMENT '社員番号',
  user_authority_type CHAR(1) COMMENT 'ユーザ権限区分',
  created_user_uid    VARCHAR(15) COMMENT '新規登録者ID',
  created             DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid   VARCHAR(15) COMMENT '最終更新者ID',
  modified            DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token       VARCHAR(32) COMMENT '登録トークン',
  modified_token      VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_user_authority PRIMARY KEY (user_authority_seq)
)
  COMMENT ='ユーザ権限を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- 住所マスタ
DROP TABLE IF EXISTS address CASCADE;

CREATE TABLE address
(
  address_seq       BIGINT   NOT NULL AUTO_INCREMENT,
  address           VARCHAR(100) COMMENT '住所',
  created_user_uid  VARCHAR(15) COMMENT '新規登録者ID',
  created           DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid VARCHAR(15) COMMENT '最終更新者ID',
  modified          DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token     VARCHAR(32) COMMENT '登録トークン',
  modified_token    VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_address PRIMARY KEY (address_seq)
)
  COMMENT ='住所を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
;

-- 処理履歴
DROP TABLE IF EXISTS process_history CASCADE;

CREATE TABLE process_history
(
  process_history_seq BIGINT NOT NULL AUTO_INCREMENT COMMENT '処理履歴SEQ',
  process_id          VARCHAR(100) COMMENT '対象処理ID',
  file_name           VARCHAR(1000) COMMENT '対象ファイル',
  status              VARCHAR(1) COMMENT '処理ステータス',
  process_date        VARCHAR(8) COMMENT '処理日',
  process_start_date  DATETIME DEFAULT '1000-01-01 00:00:00' COMMENT '処理開始日時',
  process_end_date    DATETIME DEFAULT '1000-01-01 00:00:00' COMMENT '処理終了日時',
  process_count       INT COMMENT '回目',
  created_user_uid    VARCHAR(15) COMMENT '新規登録者ID',
  created             DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid   VARCHAR(15) COMMENT '最終更新者ID',
  modified            DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token       VARCHAR(32) COMMENT '登録トークン',
  modified_token      VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_process_history PRIMARY KEY (process_history_seq)
)
  COMMENT ='画面、バッチの処理履歴を登録するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 見積部門変換
DROP TABLE IF EXISTS estimate_division_convert CASCADE;

CREATE TABLE estimate_division_convert
(
  head_part_code         VARCHAR(6) NOT NULL COMMENT '本部コード',
  division_code          VARCHAR(6) NOT NULL COMMENT '部コード',
  estimate_division_code VARCHAR(6) COMMENT '見積部門コード',
  head_part_name         VARCHAR(200) COMMENT '本部名',
  division_name          VARCHAR(200) COMMENT '部名',
  created_user_uid       VARCHAR(15) COMMENT '新規登録者ID',
  created                DATETIME   NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid      VARCHAR(15) COMMENT '最終更新者ID',
  modified               DATETIME   NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token          VARCHAR(32) COMMENT '登録トークン',
  modified_token         VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_division_convert PRIMARY KEY (head_part_code, division_code)
)
  COMMENT ='組織コードと見積部門コードを変換するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;


-- 処理履歴情報
DROP TABLE IF EXISTS process_history_info CASCADE;

CREATE TABLE process_history_info (
  process_history_info_seq  BIGINT  NOT NULL  AUTO_INCREMENT,
  process_history_seq       BIGINT  NOT NULL  COMMENT '処理履歴SEQ',
  line_number               INT   COMMENT '行数',
  record_info               VARCHAR(100)   COMMENT 'レコード情報',
  item_name                 VARCHAR(100)   COMMENT '項目名',
  error_info                VARCHAR(1000)   COMMENT 'エラー情報',
  created_user_uid          VARCHAR(15)   COMMENT '新規登録者ID',
  created                   DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid         VARCHAR(15)   COMMENT '最終更新者ID',
  modified                  DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token             VARCHAR(32)   COMMENT '登録トークン',
  modified_token            VARCHAR(32)   COMMENT '更新トークン',
  CONSTRAINT pkc_process_history_info PRIMARY KEY (process_history_info_seq, process_history_seq)
)
  COMMENT ='画面、バッチの処理履歴を登録するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 見積書（契約書）
DROP TABLE IF EXISTS estimate_contract CASCADE;

CREATE TABLE estimate_contract
(
  estimate_contract_id BIGINT   NOT NULL AUTO_INCREMENT,
  estimate_id          BIGINT   NOT NULL COMMENT '見積書ID',
  contract_id          BIGINT   NOT NULL COMMENT '契約書ID',
  display_order        SMALLINT          DEFAULT '1' COMMENT '表示順',
  created_user_uid     VARCHAR(15) COMMENT '新規登録者ID',
  created              DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid    VARCHAR(15) COMMENT '最終更新者ID',
  modified             DATETIME NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token        VARCHAR(32) COMMENT '登録トークン',
  modified_token       VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_estimate_contract PRIMARY KEY (estimate_contract_id)
)
  COMMENT ='見積の契約書を保持するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 契約書マスタ
DROP TABLE IF EXISTS contract CASCADE;

CREATE TABLE contract
(
  contract_id            BIGINT     NOT NULL AUTO_INCREMENT,
  contract_category_code VARCHAR(2) NOT NULL COMMENT '契約書カテゴリーCD',
  contract_kind_seq      BIGINT     NOT NULL COMMENT '契約書種類seq',
  contract_file_name     VARCHAR(1000) COMMENT 'ファイル名',
  release_date           VARCHAR(8) COMMENT 'リリース日',
  display_order          SMALLINT            DEFAULT '1' COMMENT '表示順',
  display_status         VARCHAR(1) COMMENT '表示ステータス',
  created_user_uid       VARCHAR(15) COMMENT '新規登録者ID',
  created                DATETIME   NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid      VARCHAR(15) COMMENT '最終更新者ID',
  modified               DATETIME   NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token          VARCHAR(32) COMMENT '登録トークン',
  modified_token         VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_contract PRIMARY KEY (contract_id)
)
  COMMENT ='契約書・約款を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;

-- 契約書種類マスタ
DROP TABLE IF EXISTS contract_kind CASCADE;

CREATE TABLE contract_kind
(
  contract_kind_seq  BIGINT      NOT NULL AUTO_INCREMENT,
  contract_kind_name VARCHAR(50) NOT NULL COMMENT '契約書種類名',
  display_order      SMALLINT             DEFAULT '1' COMMENT '表示順',
  created_user_uid   VARCHAR(15) COMMENT '新規登録者ID',
  created            DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '新規登録日時',
  modified_user_uid  VARCHAR(15) COMMENT '最終更新者ID',
  modified           DATETIME    NOT NULL DEFAULT '1000-01-01 00:00:00' COMMENT '最終更新日時',
  created_token      VARCHAR(32) COMMENT '登録トークン',
  modified_token     VARCHAR(32) COMMENT '更新トークン',
  CONSTRAINT pkc_contract_kind PRIMARY KEY (contract_kind_seq)
)
  COMMENT ='契約書・約款の種類を管理するテーブル'
  COLLATE = 'utf8mb4_general_ci'
  ENGINE = InnoDB
;
