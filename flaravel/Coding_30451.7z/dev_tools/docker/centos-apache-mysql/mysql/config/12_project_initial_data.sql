/*
  Project name: EMS
  Author: FPT
  Created date: 06/01/2020
  Modified date: 06/11/2020
  Version: 0.0.11
*/

set character_set_client = utf8mb4;
set character_set_connection = utf8mb4;
set character_set_database = utf8mb4;
set character_set_results = utf8mb4;
set collation_connection = utf8mb4_general_ci;
set collation_database = utf8mb4_general_ci;

truncate table approval_master;
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('EW01_001','システムエラー画面',1,1);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('EW01_002','セッションタイムアウト画面',1,1);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('EW01_003','2重ログイン検知画面',1,1);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('EW01_004','不正URL画面',1,1);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('EW01_005','メンテナンス画面',1,1);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('EW01_006','予期せぬエラー画面',1,1);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('Login', 'ログイン', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW10_010', 'メインメニュー', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_010', '見積書入力・閲覧・承認画面', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_020', '見積書検索', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_030', '宛先登録', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_040', 'プロフィール設定', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_050', '承認ルート設定', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_060', '承認待ちリスト', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_070', 'マスタアップロード画面', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_080', '権限付与画面', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW30_020', '宛先一覧（PopUp/ToolTip）', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW30_030', 'プロフィール一覧（PopUp/ToolTip）', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW30_040', '得意先検索（PopUp/ToolTip）', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW30_050', 'ユーザー検索（PopUp/ToolTip）', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW40_010', '見積アップロード', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW40_020', '取込検索', 1, 0);
INSERT INTO approval_master (system_function_id,name,admin,normal) VALUES('MW20_090', '契約書・約款登録画面', 1, 0);
